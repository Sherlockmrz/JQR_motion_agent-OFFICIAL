#ifndef RGB_CONTROLLER_NODE_HPP_
#define RGB_CONTROLLER_NODE_HPP_

#include <memory>
#include <string>
#include <vector>
#include <chrono>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/u_int8_multi_array.hpp"

// MODBUS 库头文件
#include <modbus/modbus.h>

/**
 * @class RGBControllerNode
 * @brief ROS2 节点，通过话题控制 RGB 灯（MODBUS-RTU 协议）
 * 订阅 rgb_control 话题接收控制指令，发布 rgb_state 话题推送真实硬件状态（10秒/次）
 */
class RGBControllerNode
{
public:
  /**
   * @brief 构造函数
   * 初始化 MODBUS 通信、订阅控制话题、创建状态发布器
   */
  //RGBControllerNode();

  /**
   * @brief 析构函数
   * 关闭 MODBUS 连接、释放资源
   */
  //~RGBControllerNode() override;
    // 构造函数：接受父节点指针，用于创建 ROS 实体和读取参数
  explicit RGBControllerNode(rclcpp::Node* parent);
  ~RGBControllerNode();

  // 禁止拷贝
  RGBControllerNode(const RGBControllerNode&) = delete;
  RGBControllerNode& operator=(const RGBControllerNode&) = delete;

private:
  
  // ------------------------------ MODBUS 相关成员 ------------------------------
  modbus_t *modbus_ctx_;        ///< MODBUS 通信上下文
  std::string serial_port_;     ///< 串口设备路径（如 /dev/ttyUSB0）
  int slave_id_;                ///< MODBUS 从站ID（模块ID）
  int baudrate_;                ///< 串口波特率

  // ------------------------------ 设备状态缓存（实时同步硬件） ------------------------------
  bool current_switch_;         ///< 当前开关状态（true=开启）
  uint8_t current_mode_;        ///< 当前工作模式（0-5）
  uint8_t current_speed_;       ///< 当前呼吸/闪烁速度档位（0-6）
  uint8_t current_brightness_;  ///< 当前亮度值（0-255）
  uint8_t current_color_;       ///< 当前颜色代码（0-8）

  // ------------------------------ ROS2 话题相关 ------------------------------
  rclcpp::Subscription<std_msgs::msg::UInt8MultiArray>::SharedPtr control_sub_;  ///< 控制话题订阅器
  rclcpp::Publisher<std_msgs::msg::UInt8MultiArray>::SharedPtr state_pub_;       ///< 状态话题发布器
  rclcpp::TimerBase::SharedPtr state_timer_;                                     ///< 状态发布定时器（10秒/次）

  // 父节点指针（仅用于创建 ROS 实体，不负责生命周期）
  rclcpp::Node* parent_;
  rclcpp::Logger rgb_logger_;

  rclcpp::CallbackGroup::SharedPtr rgb_callback_group_;  // 新增
  // ------------------------------ 核心回调函数 ------------------------------
  /**
   * @brief 控制话题回调函数
   * 处理 rgb_control 话题的控制指令，解析并执行 MODBUS 指令
   */
  void control_callback(const std_msgs::msg::UInt8MultiArray::SharedPtr msg);

  /**
   * @brief 状态发布定时器回调（10秒/次）
   * 先读取硬件真实状态，再发布 rgb_state 话题
   */
  void state_publish_callback();

  // ------------------------------ MODBUS 通信工具函数 ------------------------------
  /**
   * @brief 发送 MODBUS 0x05 功能码指令（单线圈控制）
   */
  bool send_modbus_05_cmd(uint16_t addr, uint8_t brightness);

  /**
   * @brief 发送 MODBUS 0x06 功能码指令（单寄存器写入）
   */
  bool send_modbus_06_cmd(uint16_t reg_addr, uint16_t value);

  /**
   * @brief 读取 MODBUS 寄存器，获取硬件真实状态（核心新增函数）
   * @return true=读取成功，false=失败
   */
  bool read_hardware_state();

  // ------------------------------ 辅助工具函数 ------------------------------
  /**
   * @brief 亮度值裁剪（限制在0-255范围内）
   */
  uint8_t clamp_brightness(int value);

  /**
   * @brief 速度档位转秒数
   */
  float get_speed_seconds(uint8_t speed);
};

#endif  // RGB_CONTROLLER_NODE_HPP_
