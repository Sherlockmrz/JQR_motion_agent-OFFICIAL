#include "rgb_controller/rgb_controller_node.hpp"
#include <algorithm>
#include <cstring>
#include <stdexcept>

using namespace std::chrono_literals;

namespace {
const std::string KRgbControllerVersion = "1.0.0";
}

// 构造函数实现
//RGBControllerNode::RGBControllerNode() : Node("rgb_controller_node")
RGBControllerNode::RGBControllerNode(rclcpp::Node* parent)
    : parent_(parent),  // 保存父节点指针
    rgb_logger_(rclcpp::get_logger("rgb_controller_node"))
{
  // 1. 声明并获取配置参数
  parent_->declare_parameter<std::string>("serial_port", "/dev/ttyUSB0");
  parent_->declare_parameter<int>("baudrate", 9600);
  parent_->declare_parameter<int>("slave_id", 1);
  parent_->declare_parameter<int>("timeout_ms", 1000);

  RCLCPP_INFO(rgb_logger_, "Rgb Controller Version: %s", KRgbControllerVersion.c_str());

  serial_port_ = parent_->get_parameter("serial_port").as_string();
  baudrate_ = parent_->get_parameter("baudrate").as_int();
  slave_id_ = parent_->get_parameter("slave_id").as_int();
  int timeout = parent_->get_parameter("timeout_ms").as_int();

  // 2. 初始化 MODBUS 上下文（RTU 模式）
  modbus_ctx_ = modbus_new_rtu(serial_port_.c_str(), baudrate_, 'N', 8, 1);
  if (!modbus_ctx_)
  {
    RCLCPP_FATAL(rgb_logger_, "MODBUS 上下文创建失败: %s", modbus_strerror(errno));
    rclcpp::shutdown();
    return;
  }

  // 配置 MODBUS 参数
  modbus_set_slave(modbus_ctx_, slave_id_);
  modbus_set_response_timeout(modbus_ctx_, timeout / 1000, (timeout % 1000) * 1000);

  // 连接串口
  if (modbus_connect(modbus_ctx_) == -1)
  {
    RCLCPP_FATAL(rgb_logger_, "串口连接失败: %s", modbus_strerror(errno));
    modbus_free(modbus_ctx_);
    rclcpp::shutdown();
    return;
  }

  // 3. 初始化设备状态（默认值，首次发布时会读取硬件覆盖）
  current_switch_ = false;
  current_mode_ = 0;
  current_speed_ = 3;  // 默认2.5s
  current_brightness_ = 255;
  current_color_ = 6;  // 默认白色

  rgb_callback_group_ = parent_->create_callback_group(
        rclcpp::CallbackGroupType::MutuallyExclusive);
  rclcpp::SubscriptionOptions rgb_sub_options;
  rgb_sub_options.callback_group = rgb_callback_group_;

  // 4. 创建 ROS2 话题订阅器（rgb_control）
  control_sub_ = parent_->create_subscription<std_msgs::msg::UInt8MultiArray>(
    "rgb_control",
    10,  // 队列大小
    std::bind(&RGBControllerNode::control_callback, this, std::placeholders::_1),
    rgb_sub_options);

  // 5. 创建 ROS2 话题发布器（rgb_state）
  state_pub_ = parent_->create_publisher<std_msgs::msg::UInt8MultiArray>(
    "rgb_state",
    10);  // 队列大小

  // 6. 创建状态发布定时器（核心修改：10秒/次，替换原来的100ms）
  state_timer_ = parent_->create_wall_timer(
    3s,  // 10秒触发一次
    std::bind(&RGBControllerNode::state_publish_callback, this),
  rgb_callback_group_);

  RCLCPP_INFO(rgb_logger_, "RGB控制器（实时读取硬件版）启动成功！");
  RCLCPP_INFO(rgb_logger_, "串口: %s, 波特率: %d, 从站ID: %d", 
    serial_port_.c_str(), baudrate_, slave_id_);
  RCLCPP_INFO(rgb_logger_, "订阅话题: /rgb_control, 发布话题: /rgb_state（10秒/次）");
}

// 析构函数实现
// RGBControllerNode::~RGBControllerNode()
// {
//   if (modbus_ctx_)
//   {
//     modbus_close(modbus_ctx_);
//     modbus_free(modbus_ctx_);
//   }
//   RCLCPP_INFO(rgb_logger_, "RGB控制器已关闭");
// }
RGBControllerNode::~RGBControllerNode()
{
    // 取消定时器，避免析构后回调被触发
    if (state_timer_) {
        state_timer_->cancel();
    }
    if (modbus_ctx_) {
        modbus_close(modbus_ctx_);
        modbus_free(modbus_ctx_);
        modbus_ctx_ = nullptr;
    }
    RCLCPP_INFO(rgb_logger_, "RGB控制器已关闭");
}

// 控制话题回调函数（核心逻辑，无修改）
void RGBControllerNode::control_callback(const std_msgs::msg::UInt8MultiArray::SharedPtr msg)
{
  // 校验输入数据长度（至少6个元素）
  if (msg->data.size() < 6)
  {
    RCLCPP_ERROR(rgb_logger_, "控制指令格式错误！需至少6个参数，当前: %zu", msg->data.size());
    return;
  }

  // 解析控制指令（按指定格式）
  uint8_t rgb_switch = msg->data[0];        // 0=关闭，1=开启
  uint8_t rgb_mode = msg->data[1];          // 0-5模式
  uint8_t rgb_speed = msg->data[2];         // 0-6速度档
  uint8_t is_incremental = msg->data[3];    // 0=绝对调节，1=增量调节
  uint8_t brightness_set = msg->data[4];    // 亮度值（0-255）
  uint8_t color = msg->data[5];             // 颜色代码（0-8）

  // 打印接收到的指令
  RCLCPP_INFO(rgb_logger_, "收到控制指令：开关=%d, 模式=%d, 速度=%d, 增量调节=%d, 亮度=%d, 颜色=%d",
    rgb_switch, rgb_mode, rgb_speed, is_incremental, brightness_set, color);

  // 1. 参数合法性校验
  if (rgb_switch > 1)
  {
    RCLCPP_ERROR(rgb_logger_, "开关参数错误！仅支持0（关闭）/1（开启），当前: %d", rgb_switch);
    return;
  }
  if (rgb_mode > 5)
  {
    RCLCPP_ERROR(rgb_logger_, "模式参数错误！仅支持0-5，当前: %d", rgb_mode);
    return;
  }
  if (rgb_speed > 6)
  {
    RCLCPP_ERROR(rgb_logger_, "速度参数错误！仅支持0-6，当前: %d", rgb_speed);
    return;
  }
  if (is_incremental > 1)
  {
    RCLCPP_ERROR(rgb_logger_, "增量调节参数错误！仅支持0（绝对）/1（增量），当前: %d", is_incremental);
    return;
  }
  if (color > 9)
  {
    RCLCPP_ERROR(rgb_logger_, "颜色参数错误！仅支持0-8，当前: %d", color);
    return;
  }

  // 2. 处理开关状态
  if (rgb_switch != static_cast<uint8_t>(current_switch_))
  {
    current_switch_ = (rgb_switch == 1);
    if (!current_switch_)
    {
      // 关闭灯光：发送 MODBUS 0x05 关闭指令
      if (!send_modbus_05_cmd(0x00F0, 0xFF))
      {
        RCLCPP_ERROR(rgb_logger_, "关闭灯光失败");
        return;
      }
      RCLCPP_INFO(rgb_logger_, "灯光已关闭");
      return;  // 关闭后无需处理其他参数
    }
    else
    {
      RCLCPP_INFO(rgb_logger_, "灯光已开启");
    }
  }

  // 3. 仅在开启状态下处理其他参数
  if (current_switch_)
  {
    // 3.1 处理模式和速度（寄存器0x0004：高字节=模式，低字节=速度）
    if (rgb_mode != current_mode_ || rgb_speed != current_speed_)
    {
      current_mode_ = rgb_mode;
      current_speed_ = rgb_speed;
      uint16_t mode_speed = (current_mode_ << 8) | current_speed_;
      
      if (!send_modbus_06_cmd(0x0004, mode_speed))
      {
        RCLCPP_ERROR(rgb_logger_, "设置模式/速度失败");
        return;
      }
      RCLCPP_INFO(rgb_logger_, "模式=%d, 速度=%d（%fs/次）", 
        current_mode_, current_speed_, get_speed_seconds(current_speed_));
    }

    // 3.2 处理亮度调节（修复后：按当前颜色写入对应通道）
    if (brightness_set != 0)
    {
      uint8_t new_bright = current_brightness_;
      if (is_incremental == 1)
      {
        new_bright = clamp_brightness(static_cast<int>(current_brightness_) + static_cast<int>(brightness_set));
      }
      else
      {
        new_bright = clamp_brightness(static_cast<int>(brightness_set));
      }

      //if (new_bright != current_brightness_)
      if (true)
      {
        current_brightness_ = new_bright;
        // 仅模式0/1/2生效，按当前颜色写入对应通道
        if (current_mode_ <= 2)
        {
          bool write_ok = true;
          // 先关闭所有通道，避免残留
          send_modbus_06_cmd(0x0005, (0x00 << 8) | 0);
          send_modbus_06_cmd(0x0006, (0x00 << 8) | 0);
          send_modbus_06_cmd(0x0007, (0x00 << 8) | 0);
          send_modbus_06_cmd(0x0008, (0x00 << 8) | 0);
          send_modbus_06_cmd(0x0009, (0x00 << 8) | 0);

          // 按当前颜色写入亮度
          switch (current_color_)
          {
            case 0: write_ok = send_modbus_06_cmd(0x0005, (0x01 << 8) | current_brightness_); break;
            case 1: write_ok = send_modbus_06_cmd(0x0006, (0x01 << 8) | current_brightness_); break;
            case 2: write_ok = send_modbus_06_cmd(0x0007, (0x01 << 8) | current_brightness_); break;
            case 3: write_ok = send_modbus_06_cmd(0x0005, (0x01 << 8) | current_brightness_) &&
                              send_modbus_06_cmd(0x0006, (0x01 << 8) | current_brightness_); break;
            case 4: write_ok = send_modbus_06_cmd(0x0006, (0x01 << 8) | current_brightness_) &&
                              send_modbus_06_cmd(0x0007, (0x01 << 8) | current_brightness_); break;
            case 5: write_ok = send_modbus_06_cmd(0x0005, (0x01 << 8) | current_brightness_) &&
                              send_modbus_06_cmd(0x0007, (0x01 << 8) | current_brightness_); break;
            case 6: write_ok = send_modbus_06_cmd(0x0005, (0x01 << 8) | current_brightness_) &&
                              send_modbus_06_cmd(0x0006, (0x01 << 8) | current_brightness_) &&
                              send_modbus_06_cmd(0x0007, (0x01 << 8) | current_brightness_); break;
            case 7: write_ok = send_modbus_06_cmd(0x0008, (0x01 << 8) | current_brightness_); break;
            case 8: write_ok = send_modbus_06_cmd(0x0009, (0x01 << 8) | current_brightness_); break;
            default: write_ok = false; break;
          }

          if (!write_ok)
          {
            RCLCPP_ERROR(rgb_logger_, "设置亮度失败（颜色代码%d）", current_color_);
            return;
          }
        }
        RCLCPP_INFO(rgb_logger_, "亮度已设置为 %d（颜色代码%d）", current_brightness_, current_color_);
      }
    }


    // 3.3 处理颜色（仅模式0/1/2生效，新增：切换颜色时先关闭所有通道）

    //if (current_mode_ <= 2 && color != current_color_)
    if (current_mode_ <= 2)
    {
      // 1. 切换颜色前，先关闭所有RGB/WW/CW通道
      send_modbus_06_cmd(0x0005, (0x00 << 8) | 0); // R关闭
      send_modbus_06_cmd(0x0006, (0x00 << 8) | 0); // G关闭
      send_modbus_06_cmd(0x0007, (0x00 << 8) | 0); // B关闭
      send_modbus_06_cmd(0x0008, (0x00 << 8) | 0); // WW关闭
      send_modbus_06_cmd(0x0009, (0x00 << 8) | 0); // CW关闭

      // 2. 更新颜色缓存
      current_color_ = color;

      // 3. 发送颜色激活指令（0x05）
      uint16_t color_addr = 0x0000 + current_color_;  // 常亮模式地址
      if (current_mode_ == 1) color_addr = 0x0030 + current_color_;  // 呼吸模式
      if (current_mode_ == 2) color_addr = 0x0040 + current_color_;  // 闪烁模式
      if (!send_modbus_05_cmd(color_addr, current_brightness_))
      {
        RCLCPP_ERROR(rgb_logger_, "激活颜色失败（代码%d）", current_color_);
        return;
      }

      // 4. 核心修复：给目标颜色通道写入当前亮度值（开关=1，亮度=current_brightness_）
      bool write_bright_ok = true;
      switch (current_color_)
      {
        case 0: // 红 → 写入R通道
          write_bright_ok = send_modbus_06_cmd(0x0005, (0x01 << 8) | current_brightness_);
          break;
        case 1: // 绿 → 写入G通道
          write_bright_ok = send_modbus_06_cmd(0x0006, (0x01 << 8) | current_brightness_);
          break;
        case 2: // 蓝 → 写入B通道
          write_bright_ok = send_modbus_06_cmd(0x0007, (0x01 << 8) | current_brightness_);
          break;
        case 3: // 黄 → 写入R+G通道
          write_bright_ok = send_modbus_06_cmd(0x0005, (0x01 << 8) | current_brightness_) &&
                            send_modbus_06_cmd(0x0006, (0x01 << 8) | current_brightness_);
          break;
        case 4: // 青 → 写入G+B通道
          write_bright_ok = send_modbus_06_cmd(0x0006, (0x01 << 8) | current_brightness_) &&
                            send_modbus_06_cmd(0x0007, (0x01 << 8) | current_brightness_);
          break;
        case 5: // 紫 → 写入R+B通道
          write_bright_ok = send_modbus_06_cmd(0x0005, (0x01 << 8) | current_brightness_) &&
                            send_modbus_06_cmd(0x0007, (0x01 << 8) | current_brightness_);
          break;
        case 6: // 白 → 写入R+G+B通道
          write_bright_ok = send_modbus_06_cmd(0x0005, (0x01 << 8) | current_brightness_) &&
                            send_modbus_06_cmd(0x0006, (0x01 << 8) | current_brightness_) &&
                            send_modbus_06_cmd(0x0007, (0x01 << 8) | current_brightness_);
          break;
        case 7: // 暖白 → 写入WW通道
          write_bright_ok = send_modbus_06_cmd(0x0008, (0x01 << 8) | current_brightness_);
          break;
        case 8: // 冷白 → 写入CW通道
          write_bright_ok = send_modbus_06_cmd(0x0009, (0x01 << 8) | current_brightness_);
          break;
        default:
          write_bright_ok = false;
          break;
      }

      if (!write_bright_ok)
      {
        RCLCPP_ERROR(rgb_logger_, "给颜色%d写入亮度失败", current_color_);
        return;
      }

      RCLCPP_INFO(rgb_logger_, "颜色已设置为代码%d，亮度=%d", current_color_, current_brightness_);
    }

    //3.4 处理多色循环模式（模式3-5）→ 新增亮度调节功能
    if (current_mode_ >= 3)
    {
      // 提示用户：循环模式忽略颜色参数，避免误解
      if (color != 0)
      {
        RCLCPP_WARN(rgb_logger_, "模式%d为7色循环模式，不支持设置单一颜色，已忽略颜色参数%d",
          current_mode_, color);
      }

      // 第一步：激活多色循环模式（原有逻辑，不变）
      uint16_t cycle_addr = 0x00A0;  // 3=7色常亮循环
      if (current_mode_ == 4) cycle_addr = 0x00B0;  // 4=7色呼吸循环
      if (current_mode_ == 5) cycle_addr = 0x00C0;  // 5=7色闪烁循环
      if (!send_modbus_05_cmd(cycle_addr, 0xFF))
      {
        RCLCPP_ERROR(rgb_logger_, "激活多色循环模式失败（模式%d）", current_mode_);
        return;
      }

      // 第二步：核心新增→循环模式下的亮度调节逻辑
      if (brightness_set != 0)
      {
        // 计算新亮度（支持绝对调节/增量调节，和单色模式逻辑一致）
        uint8_t new_bright = current_brightness_;
        if (is_incremental == 1)
        {
          // 增量调节：当前亮度 ± 设定值（自动限制0-255）
          new_bright = clamp_brightness(static_cast<int>(current_brightness_) + static_cast<int>(brightness_set));
        }
        else
        {
          // 绝对调节：直接设为设定值
          new_bright = clamp_brightness(static_cast<int>(brightness_set));
        }

        // 亮度未变化则无需写入
        if (new_bright != current_brightness_)
        {
          current_brightness_ = new_bright;
          // 循环模式：给RGB三个通道写入相同亮度（开关=1，亮度=新值）
          // 硬件会取该值作为全局循环亮度，所有循环颜色共用
          bool write_ok = send_modbus_06_cmd(0x0005, (0x01 << 8) | current_brightness_) &&
                          send_modbus_06_cmd(0x0006, (0x01 << 8) | current_brightness_) &&
                          send_modbus_06_cmd(0x0007, (0x01 << 8) | current_brightness_);
          
          if (write_ok)
          {
            RCLCPP_INFO(rgb_logger_, "循环模式%d亮度已设置为 %d", current_mode_, current_brightness_);
          }
          else
          {
            RCLCPP_ERROR(rgb_logger_, "循环模式%d设置亮度失败", current_mode_);
            return;
          }
        }
      }

      // 打印循环模式激活成功日志（含速度信息）
      RCLCPP_INFO(rgb_logger_, "激活7色循环模式%d，速度=%d（%fs/次）",
        current_mode_, current_speed_, get_speed_seconds(current_speed_));
    }


  }
}

// 状态发布回调函数（核心修改：10秒/次 + 先读取硬件真实状态）
void RGBControllerNode::state_publish_callback()
{
  //RCLCPP_INFO(rgb_logger_, "开始读取硬件真实状态...");
  
  // 第一步：读取硬件真实状态（失败时打印警告，沿用缓存状态）
  bool read_success = read_hardware_state();
  if (read_success)
  {
    //RCLCPP_INFO(rgb_logger_, "硬件状态读取成功！当前状态：开关=%d, 模式=%d, 速度=%d, 亮度=%d, 颜色=%d",
    // static_cast<uint8_t>(current_switch_), current_mode_, current_speed_, current_brightness_, current_color_);
  }
  else
  {
    RCLCPP_WARN(rgb_logger_, "硬件状态读取失败，发布缓存状态");
  }

  // 第二步：构造状态消息（UInt8MultiArray）
  std_msgs::msg::UInt8MultiArray state_msg;
  state_msg.data.resize(6);  // 确保长度为6

  // 填充真实状态数据
  state_msg.data[0] = static_cast<uint8_t>(current_switch_);  // 开关状态
  state_msg.data[1] = current_mode_;                          // 当前模式
  state_msg.data[2] = current_speed_;                         // 当前速度
  state_msg.data[3] = 0;                                      // 预留位（增量调节状态，无则填0）
  state_msg.data[4] = current_brightness_;                    // 当前亮度
  state_msg.data[5] = current_color_;                         // 当前颜色代码

  // 第三步：发布状态话题（10秒/次）
  state_pub_->publish(state_msg);
  //RCLCPP_INFO(rgb_logger_, "已发布硬件真实状态到 /rgb_state 话题（10秒/次）");
}


bool RGBControllerNode::read_hardware_state()
{
  // 寄存器说明：
  // 0x0004: 模式(高8位) + 速度(低8位) → reg_data[0]
  // 0x0005: R通道（高8位=开关，低8位=亮度）→ reg_data[1]
  // 0x0006: G通道（高8位=开关，低8位=亮度）→ reg_data[2]
  // 0x0007: B通道（高8位=开关，低8位=亮度）→ reg_data[3]
  // 0x0008: WW通道（暖白）→ reg_data[4]
  // 0x0009: CW通道（冷白）→ reg_data[5]
  uint16_t reg_data[6] = {0};  

  // 读取 0x0004 开始的6个寄存器
  int ret = modbus_read_registers(modbus_ctx_, 0x0004, 6, reg_data);
  if (ret != 6)
  {
    RCLCPP_ERROR(rgb_logger_, "读取硬件寄存器失败: %s（实际读取 %d 个寄存器，期望6个）", 
      modbus_strerror(errno), ret);
    return false;
  }

  // 1. 解析模式和速度（0x0004）
  current_mode_ = (reg_data[0] >> 8) & 0xFF;    
  current_speed_ = reg_data[0] & 0xFF;          

  // 2. 解析开关状态（任一通道开启则视为灯光开启）
  bool r_on = (reg_data[1] >> 8) & 0x01;        
  bool g_on = (reg_data[2] >> 8) & 0x01;        
  bool b_on = (reg_data[3] >> 8) & 0x01;        
  bool ww_on = (reg_data[4] >> 8) & 0x01;       
  bool cw_on = (reg_data[5] >> 8) & 0x01;       
  current_switch_ = (r_on || g_on || b_on || ww_on || cw_on);

  // 3. 解析颜色代码（兼容任意亮度）
  uint8_t r = reg_data[1] & 0xFF;  
  uint8_t g = reg_data[2] & 0xFF;  
  uint8_t b = reg_data[3] & 0xFF;  
  uint8_t ww = reg_data[4] & 0xFF; 
  uint8_t cw = reg_data[5] & 0xFF; 

  if (current_mode_ <= 2)
  {
    if (r > 0 && g == 0 && b == 0) current_color_ = 0;    // 红
    else if (g > 0 && r == 0 && b == 0) current_color_ = 1;  // 绿
    else if (b > 0 && r == 0 && g == 0) current_color_ = 2;  // 蓝
    else if (r > 0 && g > 0 && b == 0) current_color_ = 3;  // 黄
    else if (g > 0 && b > 0 && r == 0) current_color_ = 4;  // 青
    else if (r > 0 && b > 0 && g == 0) current_color_ = 5;  // 紫
    else if (r > 0 && g > 0 && b > 0) current_color_ = 6;  // 白
    else if (ww > 0) current_color_ = 7;  // 暖白
    else if (cw > 0) current_color_ = 8;  // 冷白
    else current_color_ = 6;  // 默认白色
  }
  else
  {
    current_color_ = 0;  // 多色循环模式，颜色代码无意义
  }

  // 4. 核心修复：根据当前颜色代码，读取对应通道的亮度值
  switch (current_color_)
  {
    case 0: current_brightness_ = reg_data[1] & 0xFF; break;  // 红 → 读R通道（0x0005）
    case 1: current_brightness_ = reg_data[2] & 0xFF; break;  // 绿 → 读G通道（0x0006）
    case 2: current_brightness_ = reg_data[3] & 0xFF; break;  // 蓝 → 读B通道（0x0007）
    case 3: current_brightness_ = reg_data[1] & 0xFF; break;  // 黄 → 读R/G（取其一即可，值相同）
    case 4: current_brightness_ = reg_data[2] & 0xFF; break;  // 青 → 读G/B（取其一即可，值相同）
    case 5: current_brightness_ = reg_data[1] & 0xFF; break;  // 紫 → 读R/B（取其一即可，值相同）
    case 6: current_brightness_ = reg_data[1] & 0xFF; break;  // 白 → 读R/G/B（取其一即可，值相同）
    case 7: current_brightness_ = reg_data[4] & 0xFF; break;  // 暖白 → 读WW通道（0x0008）
    case 8: current_brightness_ = reg_data[5] & 0xFF; break;  // 冷白 → 读CW通道（0x0009）
    default: current_brightness_ = 0; break;
  }

  // 打印调试信息（验证用）
  // RCLCPP_INFO(rgb_logger_, 
  //   "寄存器原始值：0x0004=%d, 0x0005=%d, 0x0006=%d, 0x0007=%d, 0x0008=%d, 0x0009=%d",
  //   reg_data[0], reg_data[1], reg_data[2], reg_data[3], reg_data[4], reg_data[5]);
  // RCLCPP_INFO(rgb_logger_, 
  //   "解析结果：颜色代码=%d, 对应通道亮度=%d",
  //   current_color_, current_brightness_);

  return true;
}


// 发送 MODBUS 0x05 功能码指令（无修改）
bool RGBControllerNode::send_modbus_05_cmd(uint16_t addr, uint8_t brightness)
{
  uint8_t tx_data[6] = {
    static_cast<uint8_t>(slave_id_), 0x05,
    static_cast<uint8_t>((addr >> 8) & 0xFF), static_cast<uint8_t>(addr & 0xFF),
    brightness, 0x00
  };

  // 发送原始RTU数据
  if (modbus_send_raw_request(modbus_ctx_, tx_data, 6) == -1)
  {
    RCLCPP_ERROR(rgb_logger_, "MODBUS 0x05指令发送失败: %s", modbus_strerror(errno));
    return false;
  }

  // 接收响应
  uint8_t rx_data[8] = {0};
  int rx_len = modbus_receive(modbus_ctx_, rx_data);
  if (rx_len == -1)
  {
    RCLCPP_ERROR(rgb_logger_, "MODBUS 0x05指令接收失败: %s", modbus_strerror(errno));
    return false;
  }

  // 验证响应有效性
  return (rx_len >= 6) && (memcmp(tx_data, rx_data, 6) == 0);
}

// 发送 MODBUS 0x06 功能码指令（无修改）
bool RGBControllerNode::send_modbus_06_cmd(uint16_t reg_addr, uint16_t value)
{
  if (modbus_write_register(modbus_ctx_, reg_addr, value) == -1)
  {
    RCLCPP_ERROR(rgb_logger_, "MODBUS 0x06指令写入寄存器0x%04X失败: %s", 
      reg_addr, modbus_strerror(errno));
    return false;
  }
  return true;
}

// 亮度值裁剪（无修改）
uint8_t RGBControllerNode::clamp_brightness(int value)
{
  return static_cast<uint8_t>(std::max(0, std::min(255, value)));
}

// 速度档位转秒数（无修改）
float RGBControllerNode::get_speed_seconds(uint8_t speed)
{
  const float speeds[] = {0.25, 0.5, 1.0, 2.5, 3.5, 5.0, 10.0};
  return speeds[std::min(speed, static_cast<uint8_t>(6))];
}

// 主函数（无修改）
// int main(int argc, char *argv[])
// {
//   rclcpp::init(argc, argv);
//   rclcpp::spin(std::make_shared<RGBControllerNode>());
//   rclcpp::shutdown();
//   return 0;
// }
