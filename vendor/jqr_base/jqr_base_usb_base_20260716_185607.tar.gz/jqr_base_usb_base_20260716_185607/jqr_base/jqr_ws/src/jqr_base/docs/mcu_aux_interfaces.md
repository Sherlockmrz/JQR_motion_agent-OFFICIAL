# MCU 新增 ROS 2 接口说明

本文说明 `jqr_base_node` 集成 MCU 新 SDK 后提供的故障清除、药盒控制和机器
状态灯接口。所有接口均为 ROS 2 Service，调用链如下：

```text
ROS 2 Client -> jqr_base_node -> JQR USB SDK -> USB CDC -> MCU
```

## 1. 使用前提

```bash
source /opt/ros/foxy/setup.bash       # 实机若使用 Humble，请改为 humble
source <jqr_ws>/install/setup.bash
ros2 launch jqr_base base_launch.py
```

确认节点和服务已经注册：

```bash
ros2 node list
ros2 service list | grep -E 'clear_fault|medicine_box|status_light'
```

服务调用返回成功只表示命令已经被 MCU 接收。药盒是异步机械动作，ACK 成功后仍需
通过 `/get_medicine_box_status` 判断是否到位或进入故障状态。

## 2. 故障清除

### `/clear_fault`

- 类型：`jqr_ros_msgs/srv/ClearFault`
- 请求：`fault_mask`，需要清除的故障位掩码
- 响应：`result_number.data`，`1` 成功、`0` 失败
- `0xFFFFFFFF` 表示请求清除全部可清除故障

```bash
# 清除全部故障
ros2 service call /clear_fault jqr_ros_msgs/srv/ClearFault \
  "{fault_mask: 4294967295}"

# 清除 bit0 和 bit2
ros2 service call /clear_fault jqr_ros_msgs/srv/ClearFault \
  "{fault_mask: 5}"
```

MCU 只会清除已经满足恢复条件的故障。物理故障、急停或安全条件仍存在时，故障可能
无法清除或会再次出现。

## 3. 药盒接口

### `/set_medicine_box_command`

- 类型：`jqr_ros_msgs/srv/MedicineBoxCommand`
- `command`：`0=STOP`、`1=OPEN`、`2=CLOSE`
- `accepted`：MCU 是否返回 OK ACK
- `command_seq`：本次命令序号，用于和后续状态匹配

```bash
# 打开
ros2 service call /set_medicine_box_command \
  jqr_ros_msgs/srv/MedicineBoxCommand "{command: 1}"

# 关闭
ros2 service call /set_medicine_box_command \
  jqr_ros_msgs/srv/MedicineBoxCommand "{command: 2}"

# 停止当前动作
ros2 service call /set_medicine_box_command \
  jqr_ros_msgs/srv/MedicineBoxCommand "{command: 0}"
```

### `/get_medicine_box_status`

- 类型：`jqr_ros_msgs/srv/MedicineBoxStatus`
- `valid`：当前是否有有效且未过期的 MCU 状态
- `state`：药盒状态，见下表
- `target_command`：MCU 当前目标命令
- `command_source`：命令来源，`0=NONE`、`1=BUTTON`、`2=HOST`、`3=SAFETY`
- `io_flags`：bit0 关闭限位、bit1 按钮、bit2 编码器在线、bit3 电流有效
- `fault_flags`：药盒故障位
- `current_ma`：电机电流，单位 mA
- `angle_raw`：编码器原始值
- `last_command_seq`：最近一次命令序号
- `last_result`：最近一次动作结果

| `state` | 含义 |
|---:|---|
| 0 | UNINIT，未初始化 |
| 1 | UNKNOWN，未知 |
| 2 | CLOSED，已关闭 |
| 3 | OPENING，打开中 |
| 4 | OPEN，已打开 |
| 5 | CLOSING，关闭中 |
| 6 | STOPPED，已停止 |
| 7 | FAULT，故障 |

```bash
ros2 service call /get_medicine_box_status \
  jqr_ros_msgs/srv/MedicineBoxStatus "{}"
```

判断某次动作完成时，应同时检查：

1. `command_source == 2`；
2. `last_command_seq` 等于下发命令返回的 `command_seq`；
3. `target_command` 与下发命令一致；
4. 打开对应 `state == 4`，关闭对应 `state == 2`；
5. `state != 7` 且 `fault_flags == 0`。

旧服务 `/set_medicine_box_switch`、`/get_medicine_box_state` 保留，供已有客户端兼容；
新业务建议使用上述原生命令和详细状态接口。

## 4. 机器状态灯接口

机器状态灯只对 ROS 2 提供场景控制和状态查询两个接口，不提供 RGBW 直控接口。

### `/set_status_light_scene`

- 类型：`jqr_ros_msgs/srv/StatusLightScene`
- `scene`：业务场景
- `ambient`：`0=DAY`、`1=NIGHT`
- `restart_pattern`：是否从头重新开始呼吸/闪烁相位
- `accepted`：MCU 是否返回 OK ACK

| `scene` | 场景 |
|---:|---|
| 0 | OFF |
| 1 | WAITING |
| 2 | WORKING |
| 3 | SAFETY_ALERT |
| 4 | FAULT |
| 5 | ESTOP |
| 6 | LOW_BATTERY |
| 7 | CRITICAL_BATTERY |
| 8 | CHARGING |
| 9 | UPGRADING |
| 10 | PAIRING |

```bash
ros2 service call /set_status_light_scene \
  jqr_ros_msgs/srv/StatusLightScene \
  "{scene: 2, ambient: 0, restart_pattern: true}"
```

场景优先级由上层状态管理器仲裁，MCU 只执行最后收到的场景。USB 重连后，上层应
重新发送当前业务场景。

### `/get_status_light_state`

- 类型：`jqr_ros_msgs/srv/StatusLightState`
- `valid`：是否有有效状态
- `control_mode`：`0=OFF`、`1=RAW`、`2=SCENE`
- `scene`、`ambient`：MCU 当前执行的场景和昼夜配置
- `effect`：`0=OFF`、`1=STEADY`、`2=BLINK`、`3=BREATHE`
- `flags`：bit0 初始化完成、bit1 已收到有效控制命令
- `last_command_seq`：最近一次灯光命令序号
- `r/g/b/w_permille`：MCU 当前实际输出快照，仅用于状态诊断，不能通过 ROS 2 直控

```bash
ros2 service call /get_status_light_state \
  jqr_ros_msgs/srv/StatusLightState "{}"
```

## 5. 自动测试脚本

脚本位置：`jqr_base/scripts/mcu_aux_test.py`。构建安装后也可以通过
`ros2 run jqr_base mcu_aux_test.py` 调用。

```bash
# 检查 5 个服务是否存在，不发送控制命令
ros2 run jqr_base mcu_aux_test.py check

# 查询药盒和状态灯，默认的安全测试入口
ros2 run jqr_base mcu_aux_test.py status

# 清除指定故障
ros2 run jqr_base mcu_aux_test.py clear-fault --mask 0xffffffff

# 打开药盒，并等待匹配本次 seq 的到位状态
ros2 run jqr_base mcu_aux_test.py medicine open --wait --timeout 12

# 立即停止药盒
ros2 run jqr_base mcu_aux_test.py medicine stop

# 设置工作场景并读取状态确认
ros2 run jqr_base mcu_aux_test.py light working --ambient day --restart --verify
```

若节点位于命名空间，例如 `/robot1`：

```bash
ros2 run jqr_base mcu_aux_test.py --namespace /robot1 status
```

脚本退出码：`0` 测试通过，`2` 服务不可用或 MCU 拒绝命令，`3` 状态无效、动作故障
或等待超时。真机执行药盒和故障清除测试前，应确认机械区域安全且急停可用。
