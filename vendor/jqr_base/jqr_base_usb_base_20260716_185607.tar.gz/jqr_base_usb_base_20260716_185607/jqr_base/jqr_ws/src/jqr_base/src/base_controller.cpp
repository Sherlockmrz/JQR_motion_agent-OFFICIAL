#include "jqr_base/base_controller.hpp"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/utils.h>
#include <geometry_msgs/msg/twist.hpp>
#include <algorithm>
#include <stdexcept>
#include <cstdio>
#include <ctime>
#include <chrono>

namespace jqr_base
{

BaseController::BaseController(const rclcpp::NodeOptions & options)
: Node("base_controller", options)
{
  // Declare parameters
  this->declare_parameter<double>("odom_frequency", 50.0);
  this->declare_parameter<double>("imu_frequency", 100.0);
  this->declare_parameter<double>("us_frequency", 10.0);
  this->declare_parameter<double>("battery_level_frequency", 0.1);
  this->declare_parameter<double>("max_linear_vel", 1.2);
  this->declare_parameter<double>("max_angular_vel", 1.5708);  // 90°/s
  this->declare_parameter<std::string>("odom_frame_id", "odom");
  this->declare_parameter<std::string>("base_frame_id", "base_link");
  this->declare_parameter<std::string>("imu_frame_id", "imu_link");
  this->declare_parameter<std::string>("us_frame_id", "us_link");
  
  // Get parameters
  double odom_frequency = this->get_parameter("odom_frequency").as_double();
  double imu_frequency = this->get_parameter("imu_frequency").as_double();
  double us_frequency = this->get_parameter("us_frequency").as_double();
  double battery_level_frequency = this->get_parameter("battery_level_frequency").as_double();
  max_linear_vel_ = this->get_parameter("max_linear_vel").as_double();
  max_angular_vel_ = this->get_parameter("max_angular_vel").as_double();
  odom_frame_id_ = this->get_parameter("odom_frame_id").as_string();
  base_frame_id_ = this->get_parameter("base_frame_id").as_string();
  imu_frame_id_ = this->get_parameter("imu_frame_id").as_string();
  us_frame_id_ = this->get_parameter("us_frame_id").as_string();
  RCLCPP_INFO(this->get_logger(), "Odom frequency: %f", odom_frequency);
  RCLCPP_INFO(this->get_logger(), "imu_frequency: %f", imu_frequency);

  sdk_controller_ = std::make_unique<SdkControl>();
  if (!sdk_controller_->init()) {
    RCLCPP_FATAL(this->get_logger(), "SDK初始化失败");
    throw std::runtime_error("Failed to initialize SDK controller");
  }
  RCLCPP_INFO(this->get_logger(), "SDK初始化成功");

  //初始化激光指示灯
  // try {
  //     chip = std::make_unique<gpiod::chip>("gpiochip6");
  //     line = chip->get_line(7); // GPIO8对应物理引脚18
      
  //     gpiod::line_request config;
  //     config.request_type = gpiod::line_request::DIRECTION_OUTPUT;
  //     config.consumer = "laser_controller";
      
  //     line.request(config);
  //     // 初始状态：关闭激光（输出低电平）
  //     line.set_value(0);
  //     RCLCPP_INFO(this->get_logger(), "GPIO初始化成功");
  // }
  // catch (const std::exception& e) {
  //     RCLCPP_FATAL(this->get_logger(), "GPIO初始化失败: %s", e.what());
  //     throw;
  // }

  update_robot_state_callback_group_ = this->create_callback_group(
    rclcpp::CallbackGroupType::MutuallyExclusive);

  laser_pointer_callback_group_ = this->create_callback_group(
    rclcpp::CallbackGroupType::MutuallyExclusive);

  medicine_box_callback_group_ = this->create_callback_group(
    rclcpp::CallbackGroupType::MutuallyExclusive);
  
  screen_tilt_callback_group_ = this->create_callback_group(
    rclcpp::CallbackGroupType::MutuallyExclusive);

  robot_tilt_rise_callback_group_ = this->create_callback_group(
    rclcpp::CallbackGroupType::MutuallyExclusive);
  
  cmd_vel_callback_group_ = this->create_callback_group(
    rclcpp::CallbackGroupType::MutuallyExclusive);
    

  rclcpp::SubscriptionOptions sub_options;
  sub_options.callback_group = cmd_vel_callback_group_;


  motor_control_callback_group_= this->create_callback_group(
    rclcpp::CallbackGroupType::MutuallyExclusive);

  rclcpp::SubscriptionOptions motor_control_sub_options;
  motor_control_sub_options.callback_group = motor_control_callback_group_;

  head_motor_callback_group_ = this->create_callback_group(
    rclcpp::CallbackGroupType::MutuallyExclusive);

  clear_fault_callback_group_ = this->create_callback_group(
    rclcpp::CallbackGroupType::MutuallyExclusive);

  status_light_callback_group_ = this->create_callback_group(
    rclcpp::CallbackGroupType::MutuallyExclusive);

  rclcpp::SubscriptionOptions head_motor_sub_options;
  head_motor_sub_options.callback_group = head_motor_callback_group_;

  // Create publishers
  odom_pub_ = this->create_publisher<nav_msgs::msg::Odometry>("odom", 10);
  imu_pub_ = this->create_publisher<sensor_msgs::msg::Imu>("imu", 10);
  us_pub_front_ = this->create_publisher<sensor_msgs::msg::Range>("ultra_sonic_front", 10);
  us_pub_back_ = this->create_publisher<sensor_msgs::msg::Range>("ultra_sonic_back", 10);
  battery_level_pub_= this->create_publisher<jqr_ros_msgs::msg::BatteryLevel>("battery_level", 10);
  motor_state_pub_ = this->create_publisher<std_msgs::msg::Float32MultiArray>("robot_state_update", 10);
  head_motor_angle_feedback_pub_ = this->create_publisher<std_msgs::msg::Float32MultiArray>("head_motor_angle_feedback", 10);
  four_motor_position_feedback_pub_ = this->create_publisher<std_msgs::msg::Float32MultiArray>("four_motor_position_feedback", 10);
  stall_flag_pub_ = this->create_publisher<std_msgs::msg::UInt8>("stall_flag", 10);
  
  // Create subscribers
  cmd_vel_sub_ = this->create_subscription<geometry_msgs::msg::Twist>(
    "cmd_vel", 10,
    std::bind(&BaseController::CmdVelCallback, this, std::placeholders::_1),sub_options);


  motor_control_sub_ = this->create_subscription<std_msgs::msg::Float32MultiArray>(
    "motor_control", 10,
    std::bind(&BaseController::MotorControlCallback, this, std::placeholders::_1),motor_control_sub_options);

  head_motor_speed_control_sub_ = this->create_subscription<std_msgs::msg::Float32MultiArray>(
    "head_motor_speed_control", 10,
    std::bind(&BaseController::HeadMotorSpeedControlCallback, this, std::placeholders::_1),head_motor_sub_options);

  four_motor_position_control_sub_ = this->create_subscription<std_msgs::msg::Float32MultiArray>(
    "four_motor_position_control", 10,
    std::bind(&BaseController::FourMotorPositionControlCallback, this, std::placeholders::_1),head_motor_sub_options);
  
  // Create services
  move_mode_service_ = this->create_service<jqr_ros_msgs::srv::MoveMode>(
    "get_move_mode", 
    std::bind(&BaseController::MoveModeCallback, this, std::placeholders::_1, std::placeholders::_2));

  robot_tilt_service_ = this->create_service<jqr_ros_msgs::srv::RobotTilt>(
    "set_robot_tilt", 
    std::bind(&BaseController::RobotTiltCallback, this, std::placeholders::_1, std::placeholders::_2),rmw_qos_profile_services_default,robot_tilt_rise_callback_group_);
  
  robot_tilt_state_service_ = this->create_service<jqr_ros_msgs::srv::RobotTiltState>(
    "get_robot_tilt", 
    std::bind(&BaseController::RobotTiltStateCallback, this, std::placeholders::_1, std::placeholders::_2),rmw_qos_profile_services_default, robot_tilt_rise_callback_group_);

  robot_rise_service_ = this->create_service<jqr_ros_msgs::srv::RobotRise>(
    "set_robot_rise", 
    std::bind(&BaseController::RobotRiseCallback, this, std::placeholders::_1, std::placeholders::_2),rmw_qos_profile_services_default, robot_tilt_rise_callback_group_);
  
  robot_rise_state_service_ = this->create_service<jqr_ros_msgs::srv::RobotRiseState>(
    "get_robot_rise", 
    std::bind(&BaseController::RobotRiseStateCallback, this, std::placeholders::_1, std::placeholders::_2),rmw_qos_profile_services_default, robot_tilt_rise_callback_group_);

  screen_tilt_service_ = this->create_service<jqr_ros_msgs::srv::ScreenTilt>(
      "set_screen_tilt", 
    std::bind(&BaseController::ScreenTiltCallback, this, std::placeholders::_1, std::placeholders::_2),rmw_qos_profile_services_default, screen_tilt_callback_group_);
  
  screen_tilt_state_service_ = this->create_service<jqr_ros_msgs::srv::ScreenTiltState>(
    "get_screen_tilt", 
    std::bind(&BaseController::ScreenTiltStateCallback, this, std::placeholders::_1, std::placeholders::_2),rmw_qos_profile_services_default, screen_tilt_callback_group_);

  medicine_box_switch_service_ = this->create_service<jqr_ros_msgs::srv::MedicineBoxSwitch>(
    "set_medicine_box_switch", 
    std::bind(&BaseController::MedicineBoxSwitchCallback, this, std::placeholders::_1, std::placeholders::_2),rmw_qos_profile_services_default, medicine_box_callback_group_);
  
  medicine_box_state_service_ = this->create_service<jqr_ros_msgs::srv::MedicineBoxState>(
    "get_medicine_box_state", 
    std::bind(&BaseController::MedicineBoxStateCallback, this, std::placeholders::_1, std::placeholders::_2),rmw_qos_profile_services_default, medicine_box_callback_group_);

  medicine_box_command_service_ = this->create_service<jqr_ros_msgs::srv::MedicineBoxCommand>(
    "set_medicine_box_command",
    std::bind(&BaseController::MedicineBoxCommandCallback, this, std::placeholders::_1, std::placeholders::_2),
    rmw_qos_profile_services_default, medicine_box_callback_group_);

  medicine_box_status_service_ = this->create_service<jqr_ros_msgs::srv::MedicineBoxStatus>(
    "get_medicine_box_status",
    std::bind(&BaseController::MedicineBoxStatusCallback, this, std::placeholders::_1, std::placeholders::_2),
    rmw_qos_profile_services_default, medicine_box_callback_group_);

  laser_pointer_service_ = this->create_service<jqr_ros_msgs::srv::LaserPointer>(
    "set_laser_pointer", 
    std::bind(&BaseController::LaserPointerCallback, this, std::placeholders::_1, std::placeholders::_2),rmw_qos_profile_services_default, laser_pointer_callback_group_);
  
  laser_pointer_state_service_ = this->create_service<jqr_ros_msgs::srv::LaserPointerState>(
    "get_laser_pointer_state", 
    std::bind(&BaseController::LaserPointerStateCallback, this, std::placeholders::_1, std::placeholders::_2),rmw_qos_profile_services_default, laser_pointer_callback_group_);

  clear_fault_service_ = this->create_service<jqr_ros_msgs::srv::ClearFault>(
    "clear_fault",
    std::bind(&BaseController::ClearFaultCallback, this, std::placeholders::_1, std::placeholders::_2),
    rmw_qos_profile_services_default, clear_fault_callback_group_);

  status_light_scene_service_ = this->create_service<jqr_ros_msgs::srv::StatusLightScene>(
    "set_status_light_scene",
    std::bind(&BaseController::StatusLightSceneCallback, this, std::placeholders::_1, std::placeholders::_2),
    rmw_qos_profile_services_default, status_light_callback_group_);

  status_light_state_service_ = this->create_service<jqr_ros_msgs::srv::StatusLightState>(
    "get_status_light_state",
    std::bind(&BaseController::StatusLightStateCallback, this, std::placeholders::_1, std::placeholders::_2),
    rmw_qos_profile_services_default, status_light_callback_group_);

  update_robot_state_timer_ = this->create_wall_timer(
    std::chrono::milliseconds(100),
    std::bind(&BaseController::UpdateRobotState, this),
    update_robot_state_callback_group_);
  
  odom_timer_ = this->create_wall_timer(
    std::chrono::milliseconds(static_cast<int>(1000.0 / odom_frequency)),
    std::bind(&BaseController::OdomPublishLoop, this));
  
  imu_timer_= this->create_wall_timer(
    std::chrono::milliseconds(static_cast<int>(1000.0 / imu_frequency)),
    std::bind(&BaseController::ImuPublishLoop, this));
  
  us_timer_= this->create_wall_timer(
    std::chrono::milliseconds(static_cast<int>(1000.0 / us_frequency)),
    std::bind(&BaseController::UsPublishLoop, this));

  battery_level_timer_ = this->create_wall_timer(
    std::chrono::milliseconds(static_cast<int>(1000.0/ battery_level_frequency)),
    std::bind(&BaseController::BatteryLevelPublish, this));

  get_la_timer_ = this->create_wall_timer(
    std::chrono::milliseconds(100),  // 降低频率从500Hz到10Hz
    std::bind(&BaseController::GetVelocityDataLoop, this));

  motor_state_timer_ = this->create_wall_timer(
    std::chrono::milliseconds(static_cast<int>(1000.0/ 0.1)),
    std::bind(&BaseController::TimerMotorStatePublish, this));

  head_motor_angle_feedback_timer_ = this->create_wall_timer(
    std::chrono::milliseconds(100),
    std::bind(&BaseController::HeadMotorAngleFeedbackPublish, this));

  four_motor_position_feedback_timer_ = this->create_wall_timer(
    std::chrono::milliseconds(20),
    std::bind(&BaseController::FourMotorPositionFeedbackPublish, this));

  stall_flag_timer_ = this->create_wall_timer(
    std::chrono::seconds(3),
    std::bind(&BaseController::StallFlagPublish, this));

  // rgb_controller_ = std::make_unique<RGBControllerNode>(this);

  RCLCPP_INFO(this->get_logger(), "JQR Base Controller initialized");
}

void BaseController::GetVelocityDataLoop() {
    std::vector<HubMotorRecvData> velocityData;
    if (sdk_controller_->GetRobotVelocities(velocityData)) {
        if (!velocityData.empty()) {
            double linear_vel = velocityData[0].ActualLinearVel / 100.0;
            double angular_vel = velocityData[0].ActualAngularVel / 10.0 * DEG_TO_RAD;

            const double vel_threshold = 0.01;
            const double ang_threshold = 0.01;

            bool linear_changed = first_velocity_data_ ||
                                  fabs(linear_vel - last_linear_vel_) > vel_threshold;
            bool angular_changed = first_velocity_data_ ||
                                   fabs(angular_vel - last_angular_vel_) > ang_threshold;

            if (linear_changed || angular_changed) {
                RCLCPP_DEBUG(this->get_logger(),  // 改为DEBUG级别
                    "get form mcu - linear: %f, angular: %f",
                    linear_vel, angular_vel);

                last_linear_vel_ = linear_vel;
                last_angular_vel_ = angular_vel;
                first_velocity_data_ = false;
            }
        }
    }
}

void BaseController::UpdateRobotState(){
  // 更新机器人状态
  bool is_motor_state_updated_ = false;

  //药盒电机状态更新
  MedicineBoxStatusData medicine_status;
  if (sdk_controller_->GetMedicineBoxStatusDetail(medicine_status)) {
    std::lock_guard<std::mutex> lock(robot_state_mutex_);
    uint8_t legacy_state = robot_state_.medicine_box_state;
    switch (medicine_status.state) {
      case 2: legacy_state = 0; break;  // CLOSED
      case 3: legacy_state = 3; break;  // OPENING
      case 4: legacy_state = 1; break;  // OPEN
      case 5: legacy_state = 2; break;  // CLOSING
      default: break;                   // Keep the last compatible state.
    }
    if (robot_state_.medicine_box_state != legacy_state) {
      robot_state_.medicine_box_state = legacy_state;
      is_motor_state_updated_ = true;
    }
  }

  //机身升降
  uint8_t FuselageLiftStatus;
  if (sdk_controller_->GetFuselageLiftStatus(FuselageLiftStatus)){
    std::lock_guard<std::mutex> lock(robot_state_mutex_);
    bool new_state_ = (FuselageLiftStatus == 1);

    if (robot_state_.robot_rise_state != new_state_) {
      robot_state_.robot_rise_state = new_state_;
      is_motor_state_updated_ = true;
    }
     //RCLCPP_INFO(this->get_logger(), "robot_rise_state: %d", robot_state_.robot_rise_state);
  }

  //机身俯仰
  int32_t FuselagePitchActualPos;   
  if (sdk_controller_->GetFuselagePitchPos(FuselagePitchActualPos)){
    std::lock_guard<std::mutex> lock(robot_state_mutex_);
    double new_state_ = static_cast<double>(FuselagePitchActualPos) / 10.0;   

    if (fabs(robot_state_.robot_tilt_state - new_state_) > 0.1) {   //发生变化 
      is_motor_state_updated_ = true;
    }
    robot_state_.robot_tilt_state = new_state_;
    //RCLCPP_INFO(this->get_logger(), "robot_tilt_state: %f", robot_state_.robot_tilt_state);
  }

  //屏幕俯仰
  float ScreenTiltActualPos;
  if (sdk_controller_->GetScreenTiltPos(ScreenTiltActualPos)){
    std::lock_guard<std::mutex> lock(robot_state_mutex_);
    double new_state_ = ScreenTiltActualPos/100.0;

    if (fabs(robot_state_.screen_tilt_state - new_state_) > 0.05) {   //发生变化
      robot_state_.screen_tilt_state = new_state_;
      is_motor_state_updated_ = true;
    }
     //RCLCPP_INFO(this->get_logger(), "screen_tilt_state: %d", robot_state_.screen_tilt_state);
  }

  //头部俯仰角度 SDK返回单位0.1°，最上方为零度，范围 0 - 600
  int32_t HeadPitchAngle;
  if (sdk_controller_->GetHeadPitchAngle(HeadPitchAngle)){
    std::lock_guard<std::mutex> lock(robot_state_mutex_);
    robot_state_.head_pitch_angle = HeadPitchAngle / 10.0f;  // 0.1° -> °
    // RCLCPP_INFO(this->get_logger(), "head_pitch_angle: %f", robot_state_.head_pitch_angle);
  }

  //头部偏航角度 SDK返回单位0.1°，最右边为零度，范围 0 - 3400
  int32_t HeadYawAngle;
  if (sdk_controller_->GetHeadYawAngle(HeadYawAngle)){
    std::lock_guard<std::mutex> lock(robot_state_mutex_);
    robot_state_.head_yaw_angle = HeadYawAngle / 10.0f;  // 0.1° -> °
    // RCLCPP_INFO(this->get_logger(), "head_yaw_angle: %f", robot_state_.head_yaw_angle);
  }

  //堵转故障标志
  uint8_t StallFlag;
  if (sdk_controller_->GetStallFlag(StallFlag) &&
      stall_flag_.exchange(StallFlag) != StallFlag) {
    RCLCPP_INFO(this->get_logger(), "Stall flag changed: %d", StallFlag);
    StallFlagPublish();
  }

  //判断是否断连
  if (!sdk_controller_->GetMcuConnectStatus()){
    RCLCPP_WARN(this->get_logger(),"Connection timeout between base and MCU.");
  }

  //电池电量
  uint8_t BmsSoc;
  if(sdk_controller_->GetBmsSoc(BmsSoc)){
    std::lock_guard<std::mutex> lock(robot_state_mutex_);
    robot_state_.battery_power_state = BmsSoc;
    // RCLCPP_INFO(this->get_logger(), "GetBatteryPowerState: %d", robot_state_.battery_power_state);
  }

  
  if(is_motor_state_updated_) {
    MotorStatePublish();
  }

}

void BaseController::MotorStatePublish(){
  std_msgs::msg::Float32MultiArray motor_state;
  motor_state.data.resize(5);
  {
    std::lock_guard<std::mutex> lock(robot_state_mutex_);
    motor_state.data[0] = robot_state_.screen_tilt_state;
    motor_state.data[1] = robot_state_.robot_tilt_state;
    motor_state.data[2] = static_cast<float>(robot_state_.robot_rise_state);
    motor_state.data[3] = static_cast<float>(robot_state_.medicine_box_state);
    motor_state.data[4] = static_cast<float>(robot_state_.battery_power_state);
  }

  motor_state_pub_->publish(std::move(motor_state));
} 

void BaseController::TimerMotorStatePublish() {
    MotorStatePublish();
}


void BaseController::CmdVelCallback(const geometry_msgs::msg::Twist::SharedPtr msg)
{
  // 限制速度在最大允许范围内
  target_linear_vel_ = std::clamp(msg->linear.x, -max_linear_vel_, max_linear_vel_);
  target_angular_vel_ = std::clamp(msg->angular.z, -max_angular_vel_, max_angular_vel_);

  auto now_ms_cmd = std::chrono::duration_cast<std::chrono::milliseconds>(
      std::chrono::system_clock::now().time_since_epoch()).count();
  std::printf("[CmdVelCB] time=%lld, target_angular_vel=%.6f\n",
    static_cast<long long>(now_ms_cmd), target_angular_vel_);
  std::fflush(stdout);

  SendVelocitiesToMCU(target_linear_vel_, target_angular_vel_);
  
  RCLCPP_DEBUG(this->get_logger(), 
               "Received cmd_vel: linear=%.3f m/s, angular=%.3f rad/s", 
               target_linear_vel_, target_angular_vel_);
}

void BaseController::SendVelocitiesToMCU(double send_linear_vel, double send_angular_vel)
{
  int32_t linear_vel_int32 = static_cast<int32_t>(std::round(send_linear_vel * 100.0));
  int32_t angular_vel_int32 = static_cast<int32_t>(std::round(send_angular_vel * RAD_TO_DEG * 10.0));

  RCLCPP_DEBUG(this->get_logger(),  // 改为DEBUG级别
            "Velocity converted - linear: %d, angular: %d",
            linear_vel_int32, angular_vel_int32);

  if(sdk_controller_->SetRobotVelocities(linear_vel_int32, angular_vel_int32)){
    RCLCPP_DEBUG(this->get_logger(), "Send to MCU success");  // 改为DEBUG级别
  }

  RCLCPP_DEBUG(this->get_logger(),  // 改为DEBUG级别
               "Sending to MCU: linear=%.3f m/s, angular=%.3f rad/s",
               send_linear_vel, send_angular_vel);
}

void BaseController::OdomPublishLoop()
{
  if(first_odom_update) {
    last_odom_update_ = this->now();
    first_odom_update = false;
    return;
  } 
  auto current_time = this->now();
  double dt = (current_time - last_odom_update_).seconds();
  last_odom_update_ = current_time;

  if (dt > 0) {
    std::vector<HubMotorRecvData> velocityData;
    if (sdk_controller_->GetRobotVelocities(velocityData)) {
        if (!velocityData.empty()) {
            double linear_vel = velocityData[0].ActualLinearVel/100.0;
            double angular_vel = velocityData[0].ActualAngularVel/10.0 * DEG_TO_RAD;
            UpdateOdometry(linear_vel, angular_vel, dt);

            PublishOdometry(linear_vel, angular_vel);
        }
    } else {
        RCLCPP_ERROR(this->get_logger(), "Failed to get robot velocities from SDK");
    }
  }
}

// 更新里程计：根据线速度和角速度积分计算新的位姿
void BaseController::UpdateOdometry(double linear_vel, double angular_vel, double dt)
{
  // 使用速度积分更新位姿
  if (fabs(angular_vel) < 1e-6) {
    // 直线运动：直接积分线速度到位置
    x_ += linear_vel * cos(theta_) * dt;  
    y_ += linear_vel * sin(theta_) * dt;   
  } else {
    // 曲线运动：使用圆弧运动模型计算位置变化
    double delta_theta = angular_vel * dt;  
    theta_ += delta_theta;                
    
    // 圆弧运动模型：计算位置增量
    double v_over_w = linear_vel / angular_vel;  
    x_ += v_over_w * (sin(theta_) - sin(theta_ - delta_theta));  
    y_ += v_over_w * (cos(theta_ - delta_theta) - cos(theta_));   
  }
  
  // 规范化角度到 [-pi, pi] 范围内
  while (theta_ > M_PI) theta_ -= 2.0 * M_PI;  
  while (theta_ < -M_PI) theta_ += 2.0 * M_PI; 
}

void BaseController::PublishOdometry(double linear_vel, double angular_vel)
{
  // 发布里程计消息
  auto odom_msg = std::make_unique<nav_msgs::msg::Odometry>();
  // 设置消息头时间戳和坐标系
  odom_msg->header.stamp = this->now();
  odom_msg->header.frame_id = odom_frame_id_;
  odom_msg->child_frame_id = base_frame_id_;
  
  // 设置位置信息
  odom_msg->pose.pose.position.x = x_;
  odom_msg->pose.pose.position.y = y_;
  odom_msg->pose.pose.position.z = 0.0;
  
  // 设置姿态信息（四元数）
  tf2::Quaternion q;
  q.setRPY(0, 0, theta_);
  odom_msg->pose.pose.orientation.x = q.x();
  odom_msg->pose.pose.orientation.y = q.y();
  odom_msg->pose.pose.orientation.z = q.z();
  odom_msg->pose.pose.orientation.w = q.w();
  
  // 打印角速度和四元数转换的yaw角
  double yaw_from_q = tf2::getYaw(q);
  auto now_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
      std::chrono::system_clock::now().time_since_epoch()).count();
  std::printf("[Odom] time=%lld, angular_vel=%.6f, yaw_from_q=%.6f\n",
    static_cast<long long>(now_ms), angular_vel, yaw_from_q);
  std::fflush(stdout);
  
  // 设置速度信息
  odom_msg->twist.twist.linear.x = linear_vel;
  odom_msg->twist.twist.linear.y = 0.0;
  odom_msg->twist.twist.linear.z = 0.0;
  odom_msg->twist.twist.angular.x = 0.0;
  odom_msg->twist.twist.angular.y = 0.0;
  odom_msg->twist.twist.angular.z = angular_vel;
  
  // 发布里程计消息
  odom_pub_->publish(std::move(odom_msg));
  
}

void BaseController::ImuPublishLoop(){
  auto current_time = this->now();
  auto imu_msg = std::make_unique<sensor_msgs::msg::Imu>();
  imu_msg->header.stamp = current_time;
  imu_msg->header.frame_id = imu_frame_id_;

  std::vector<ImuRecvDataStruct> imuRecvData;

  if (sdk_controller_->GetImuData(imuRecvData)) {
    if (!imuRecvData.empty()) {
      imu_msg->linear_acceleration.x = imuRecvData[0].Accel_x * GRAVITY;
      imu_msg->linear_acceleration.y = imuRecvData[0].Accel_y * GRAVITY;
      imu_msg->linear_acceleration.z = imuRecvData[0].Accel_z * GRAVITY;

      imu_msg->angular_velocity.x = imuRecvData[0].Gyro_x * DEG_TO_RAD;
      imu_msg->angular_velocity.y = imuRecvData[0].Gyro_y * DEG_TO_RAD;
      imu_msg->angular_velocity.z = imuRecvData[0].Gyro_z * DEG_TO_RAD;

      tf2::Quaternion q;

      double roll_rad = imuRecvData[0].Euler_Roll * DEG_TO_RAD;
      double pitch_rad = imuRecvData[0].Euler_Pitch * DEG_TO_RAD;
      double yaw_rad = imuRecvData[0].heading_180 * DEG_TO_RAD;
      q.setRPY(roll_rad, pitch_rad, yaw_rad);

      imu_msg->orientation.x = q.x();
      imu_msg->orientation.y = q.y();
      imu_msg->orientation.z = q.z();
      imu_msg->orientation.w = q.w();

      imu_pub_->publish(std::move(imu_msg));
    }
  } else {
        RCLCPP_ERROR(this->get_logger(), "Failed to get robot imu_data from SDK");
  }
}

void BaseController::UsPublishLoop(){
  auto current_time = this->now();
  auto us_msg_front = std::make_unique<sensor_msgs::msg::Range>();
  auto us_msg_back = std::make_unique<sensor_msgs::msg::Range>();
  float distance_front = 0.0f;
  float distance_back = 0.0f;

  std::vector<UltrasonicRecvData> UltrasonicData;
  if (sdk_controller_->GetUltrasonicData(UltrasonicData)) {
      if (!UltrasonicData.empty()) {
          distance_front = UltrasonicData[0].FrontDistance/10000.0; //mm->m 
          distance_back = UltrasonicData[0].RearDistance/10000.0; 
      }
  } else {
      RCLCPP_ERROR(this->get_logger(), "Failed to get UltrasonicRecvDatafrom SDK");
  }

  us_msg_front->header.stamp = current_time;
  us_msg_front->header.frame_id = us_frame_id_;  
  us_msg_front->radiation_type = sensor_msgs::msg::Range::ULTRASOUND;  

  us_msg_front->field_of_view = 0.3942;      
  us_msg_front->min_range = 0.06;         
  us_msg_front->max_range = 0.6;         
  us_msg_front->range = distance_front;

  us_msg_back->header.stamp = current_time;
  us_msg_back->header.frame_id = us_frame_id_;  
  us_msg_back->radiation_type = sensor_msgs::msg::Range::ULTRASOUND;  

  us_msg_back->field_of_view = 0.3942;      
  us_msg_back->min_range = 0.06;         
  us_msg_back->max_range = 0.6;         
  us_msg_back->range = distance_back;



  us_pub_front_->publish(std::move(us_msg_front));
  us_pub_back_->publish(std::move(us_msg_back));


}



void BaseController::MoveModeCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::MoveMode::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::MoveMode::Response> response)
{

  (void)request;
  RCLCPP_INFO(this->get_logger(), "Received move mode request");

  std::vector<HubMotorRecvData> velocityData;
  if (sdk_controller_->GetRobotVelocities(velocityData)) {
    if (!velocityData.empty()) {
      double linear_vel = velocityData[0].ActualLinearVel/100.0;
      double angular_vel = velocityData[0].ActualAngularVel/10.0 * DEG_TO_RAD;

      if (fabs(angular_vel) < 1e-6) {
        if (fabs(linear_vel) < 1e-6) {
          response->move_mode = 0;  // 静止状态
        } else if(linear_vel > 0){
          response->move_mode = 1;  // 前进状态
        } else {
          response->move_mode = 2;  // 后退状态
        }
      } else {
        response->move_mode = 3;  // 旋转状态
      }

      response->linear_vel = linear_vel;
      response->result_number.data = 1;
      response->result_msg.data = "Move mode retrieved successfully";
    }
    else{
      response->result_number.data = 0;
      response->result_msg.data = "Failed to retrieve move mode";
    }
  } else {
    RCLCPP_INFO(this->get_logger(), "Failed to get robot velocities from SDK");
    response->result_number.data = 0;
    response->result_msg.data = "Failed to retrieve move mode";
  }
  return;

}

void BaseController::BatteryLevelPublish(){
  auto battert_level_msg = std::make_unique<jqr_ros_msgs::msg::BatteryLevel>();
  std::lock_guard<std::mutex> lock(robot_state_mutex_);
  battert_level_msg->battery_power_state = robot_state_.battery_power_state;
  battery_level_pub_->publish(std::move(battert_level_msg));
}

// 处理机器人倾斜角度请求的回调函数
void BaseController::RobotTiltCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::RobotTilt::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::RobotTilt::Response> response)
{
  // 记录接收到的倾斜请求信息
  RCLCPP_INFO(this->get_logger(), "Received Robot tilt request: %f, duration: %d", request->robot_tilt, request->duration);

  // 校验升降状态，若为低位则自动升高
  if (!isRobotRisen()) {

    if (!autoRiseRobot(request->duration)) {
      // 升高失败/超时，返回俯仰调节失败
      response->result_number.data = 0;
      response->result_msg.data = "Auto rise failed before tilt adjustment (timeout/MCU error)";
      RCLCPP_ERROR(this->get_logger(), "Reject tilt request: auto rise failed");
      return;
    }
  }
  
  // 合法性校验
  if (request->robot_tilt < robot_tilt_min_ || request->robot_tilt > robot_tilt_max_) {
    response->result_number.data = 0;
    response->result_msg.data = "Invalid tilt value";
    RCLCPP_WARN(this->get_logger(), "Invalid tilt value: %.2f", request->robot_tilt);
    return;
  }

  // 计算超时时间
  rclcpp::Duration timeout = (request->duration == 0) ? 
    rclcpp::Duration(5, 0) : 
    rclcpp::Duration::from_seconds(request->duration * 0.1);  

  int32_t FuselagePitchTargetPos;
  FuselagePitchTargetPos =  request->robot_tilt * 10; 

  if(sdk_controller_->SetFuselagePitchPos(FuselagePitchTargetPos)){      //机身俯仰控制-5 ，+5度
    RCLCPP_INFO(this->get_logger(), "Send to SetFuselagePitchPos success");    
  }

  // 记录开始时间并设置目标参数
  auto start_time = this->now();
  double target_robot_tilt = request->robot_tilt;
  double tolerance = 0.21; // 容差
  bool robot_tilt_achieved = false;

  rclcpp::Rate wait_rate(10); 

  // 循环检查倾斜状态直到超时或达到目标
  while ((this->now() - start_time) < timeout) {
    double current_tilt;
    {
      // 加锁获取当前机器人倾斜状态
      std::lock_guard<std::mutex> lock(robot_state_mutex_);
      current_tilt = robot_state_.robot_tilt_state;
    }
    // 检查当前倾斜状态是否达到目标（考虑容差）
    if (std::abs(current_tilt - target_robot_tilt) <= tolerance) {
      robot_tilt_achieved = true;
      break;
    }

    wait_rate.sleep();
  }

  // 根据倾斜是否成功设置响应结果
  if (robot_tilt_achieved) {
    response->result_number.data = 1;
    response->result_msg.data = "Robot tilt achieved successfully:";
    double final_tilt;
    {
      std::lock_guard<std::mutex> lock(robot_state_mutex_);
      final_tilt = robot_state_.robot_tilt_state;
    }
    RCLCPP_INFO(this->get_logger(), "Robot tilt achieved: %.2f", final_tilt);
  } else {
    double current_tilt_state;
    {
      std::lock_guard<std::mutex> lock(robot_state_mutex_);
      current_tilt_state = robot_state_.robot_tilt_state;
    }
    response->result_number.data = 2;
    response->result_msg.data = "Robot tilt timeout: current=" + std::to_string(current_tilt_state) +
                               ", target=" + std::to_string(target_robot_tilt);
    RCLCPP_WARN(this->get_logger(), "Robot tilt timeout: current=%.2f, target=%.2f",
                current_tilt_state, target_robot_tilt);
  }
  return;
 
}

void BaseController::RobotTiltStateCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::RobotTiltState::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::RobotTiltState::Response> response)
{
  (void)request;
  std::lock_guard<std::mutex> lock(robot_state_mutex_);

  // 加锁获取当前机器人倾斜状态
  response->robot_tilt_state = robot_state_.robot_tilt_state;
  response->result_number.data = 1;
  response->result_msg.data = "Robot tilt state retrieved successfully";
  RCLCPP_INFO(this->get_logger(), "Retrieved robot tilt state: %.2f", robot_state_.robot_tilt_state);
  return;
}

void BaseController::RobotRiseCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::RobotRise::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::RobotRise::Response> response)
{
  // 记录接收到的升降请求信息
  RCLCPP_INFO(this->get_logger(), "Received robot rise request: %d, duration: %d", request->robot_rise, request->duration);
  bool current_robot_rise_state;
  bool current_robot_tilt_state;
  //记录当前升降状态
  {
    std::lock_guard<std::mutex> lock(robot_state_mutex_);
    current_robot_rise_state = robot_state_.robot_rise_state;
    current_robot_tilt_state = robot_state_.robot_tilt_state;
  }
  
  // 合法性校验：检查当前状态是否允许升降
  if ( current_robot_rise_state == request->robot_rise) {
    response->result_number.data = 0;
    response->result_msg.data = "Robot rise already in the requested state";
    RCLCPP_WARN(this->get_logger(), "Robot rise already in the requested state");
    return;
  } 

  // 如果是下降，需要先将俯仰角度设置为0
  if (!request->robot_rise && current_robot_tilt_state != 0.0) {
    if (!forceTiltToZero(request->duration)) {
      response->result_number.data = 3;
      response->result_msg.data = "Failed to set tilt to zero before lowering";
      RCLCPP_ERROR(this->get_logger(), "Tilt zero failed, abort robot lowering");
      return;
    }
  }

  uint8_t TargetCmd;

  if (request->robot_rise) {
    TargetCmd = 1;
  } else {
    TargetCmd = 0;
  }

  if(sdk_controller_->FuselageLiftControl(TargetCmd)){
    RCLCPP_INFO(this->get_logger(), "Send to FuselageLiftControl success");
  }

  rclcpp::Duration timeout = (request->duration == 0) ? 
    rclcpp::Duration(5, 0) :  
    rclcpp::Duration::from_seconds(request->duration * 0.1);  

  // 记录开始时间并设置目标参数
  auto start_time = this->now();
  bool target_robot_rise = request->robot_rise;
  bool rise_achieved = false;

  rclcpp::Rate wait_rate(10); 

  while ((this->now() - start_time) < timeout) {
    bool current_rise;
    {
      // 加锁获取当前机器人升降状态
      std::lock_guard<std::mutex> lock(robot_state_mutex_);
      current_rise = robot_state_.robot_rise_state;
    }
    if (current_rise == target_robot_rise) {
      rise_achieved = true;
      break;
    }
    wait_rate.sleep();
  }

  if (rise_achieved) {
    response->result_number.data = 1;
    response->result_msg.data = "Robot rise achieved successfully";
    RCLCPP_INFO(this->get_logger(), "Robot rise achieved: %d", robot_state_.robot_rise_state);
  } else {
    response->result_number.data = 2;
    response->result_msg.data = "Robot rise timeout";
    RCLCPP_WARN(this->get_logger(), "Robot rise timeout");
  }
  return;

}

bool BaseController::forceTiltToZero(int duration) {
  RCLCPP_INFO(this->get_logger(), "Forcing robot tilt to zero...");
  
  int32_t FuselagePitchTargetPos = 0;
  if(sdk_controller_->SetFuselagePitchPos(FuselagePitchTargetPos)){      
    RCLCPP_INFO(this->get_logger(), "Send to Forcing robot tilt to zeros success");    
  } else {
    RCLCPP_ERROR(this->get_logger(), "Failed to send tilt zero command to MCU");
    return false;
  }

  rclcpp::Duration timeout = (duration == 0) ? 
      rclcpp::Duration(5, 0) : 
      rclcpp::Duration::from_seconds(duration * 0.1);
  
  auto start_time = this->now();
  const double zero_tolerance = 0.21;
  bool zero_achieved = false;
  rclcpp::Rate wait_rate(10);

  while ((this->now() - start_time) < timeout) {
      double current_tilt;
      {
          std::lock_guard<std::mutex> lock(robot_state_mutex_);
          current_tilt = robot_state_.robot_tilt_state;
      }
      if (std::abs(current_tilt - 0.0) <= zero_tolerance) {
          zero_achieved = true;
          break;
      }
      wait_rate.sleep();
  }

  if (zero_achieved) {
      RCLCPP_INFO(this->get_logger(), "Robot tilt zero achieved successfully");
      return true;
  } else {
      RCLCPP_WARN(this->get_logger(), "Robot tilt zero timeout");
      return false;
  }
}

// 检查机器人是否处于升起状态
bool BaseController::isRobotRisen() {
  std::lock_guard<std::mutex> lock(robot_state_mutex_);
  return robot_state_.robot_rise_state;
}

//自动升高机器人
bool BaseController::autoRiseRobot(int duration) {
  RCLCPP_INFO(this->get_logger(), "Robot is in low state, auto rising before tilt adjustment...");

  // 调用MCU升高指令（TargetCmd=1表示升高）
  if(!sdk_controller_->FuselageLiftControl(1)){
      RCLCPP_ERROR(this->get_logger(), "Send to FuselageLiftControl (rise) failed");
      return false;
  }

  // 计算超时时间
  rclcpp::Duration timeout = (duration == 0) ? 
      rclcpp::Duration(5, 0) : 
      rclcpp::Duration::from_seconds(duration * 0.1);

  auto start_time = this->now();
  bool rise_achieved = false;
  rclcpp::Rate wait_rate(10); 

  while ((this->now() - start_time) < timeout) {
      bool current_rise;
      {
          std::lock_guard<std::mutex> lock(robot_state_mutex_);
          current_rise = robot_state_.robot_rise_state;
      }
      if (current_rise == true) {  
          rise_achieved = true;
          break;
      }
      wait_rate.sleep();
  }

  if (rise_achieved) {
      RCLCPP_INFO(this->get_logger(), "Auto rise robot achieved successfully");
      return true;
  } else {
      RCLCPP_WARN(this->get_logger(), "Auto rise robot timeout");
      return false;
  }
}

void BaseController::RobotRiseStateCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::RobotRiseState::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::RobotRiseState::Response> response)
{
  (void)request;
  std::lock_guard<std::mutex> lock(robot_state_mutex_);

  response->robot_rise_state = robot_state_.robot_rise_state;
  response->result_number.data = 1;
  response->result_msg.data = "Robot rise state retrieved successfully";
  RCLCPP_INFO(this->get_logger(), "Retrieved robot rise state: %d", robot_state_.robot_rise_state);
  return;

}

void BaseController::ScreenTiltCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::ScreenTilt::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::ScreenTilt::Response> response)
{
  // 记录接收到的屏幕倾斜请求信息
  RCLCPP_INFO(this->get_logger(), "Received screen tilt request: %f, duration: %d", request->screen_tilt, request->duration);

   // 合法性校验：检查倾斜角度是否在允许范围内
  if (request->screen_tilt < screen_tilt_min_ || request->screen_tilt > screen_tilt_max_) {
    response->result_number.data = 0;
    response->result_msg.data = "Invalid screen tilt value";
    RCLCPP_WARN(this->get_logger(), "Invalid screen tilt value: %.2f", request->screen_tilt);
    return;
  }

  // 计算超时时间：如果duration为0则使用默认5秒
  rclcpp::Duration timeout = (request->duration == 0) ? 
    rclcpp::Duration(5, 0) :  // 默认5秒超时
    rclcpp::Duration::from_seconds(request->duration * 0.1);  
  
  // 调用MCU设置屏幕俯仰角度函数  

  float ScreenTiltTargetPos;
  ScreenTiltTargetPos = request->screen_tilt * 100.0;

  if(sdk_controller_->SetScreenTiltPos(ScreenTiltTargetPos)){
    RCLCPP_INFO(this->get_logger(), "Send to SetScreenTiltPos success");
  }


  // 记录开始时间并设置目标参数
  auto start_time = this->now();
  double target_screen_tilt = request->screen_tilt;
  double tolerance = 0.1; // 容差
  bool screen_tilt_achieved = false;
  rclcpp::Rate wait_rate(10); 

  while((this->now() - start_time) < timeout){
    double current_screen_tilt;
    {
      // 加锁获取当前屏幕倾斜角度
      std::lock_guard<std::mutex> lock(robot_state_mutex_);
      current_screen_tilt = robot_state_.screen_tilt_state;
    }
    if (fabs(current_screen_tilt - target_screen_tilt) <= tolerance) {
      screen_tilt_achieved = true;
      break;
    }
    wait_rate.sleep();
  }

  if (screen_tilt_achieved) {
    response->result_number.data = 1;
    response->result_msg.data = "Screen tilt achieved successfully";
    RCLCPP_INFO(this->get_logger(), "Screen tilt achieved: %.2f", robot_state_.screen_tilt_state);
  } else {
    response->result_number.data = 2;
    response->result_msg.data = "Screen tilt timeout: current=" + std::to_string(robot_state_.screen_tilt_state) + 
                               ", target=" + std::to_string(target_screen_tilt);
    RCLCPP_WARN(this->get_logger(), "Screen tilt timeout: current=%.2f, target=%.2f", 
                robot_state_.screen_tilt_state, target_screen_tilt);
  }
  return;
}

void BaseController::ScreenTiltStateCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::ScreenTiltState::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::ScreenTiltState::Response> response)
{
  (void)request;
  std::lock_guard<std::mutex> lock(robot_state_mutex_);
  //robot_state_ = GetRobotState();  //从mcu获取机器人最新状态   
  response->screen_tilt_state = robot_state_.screen_tilt_state;
  response->result_number.data = 1;
  response->result_msg.data = "Screen tilt state retrieved successfully";
  RCLCPP_INFO(this->get_logger(), "Retrieved screen tilt state: %.2f", robot_state_.screen_tilt_state);
  return;
}

void BaseController::MedicineBoxSwitchCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxSwitch::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxSwitch::Response> response)
{
  const uint8_t command = request->medicine_box_switch ? 1 : 2;
  uint8_t command_seq = 0;
  RCLCPP_INFO(this->get_logger(), "Medicine box request: command=%u, speed_stage=%u",
              command, request->speed_stage);

  if (!sdk_controller_->SetMedicineBoxCommand(command, command_seq)) {
    response->result_number.data = 0;
    response->result_msg.data = "Medicine box command was rejected, timed out, or failed to send";
    return;
  }

  const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(12);
  rclcpp::Rate wait_rate(10);
  while (rclcpp::ok() && std::chrono::steady_clock::now() < deadline) {
    MedicineBoxStatusData status;
    if (sdk_controller_->GetMedicineBoxStatusDetail(status) &&
        status.command_source == 2 && status.last_cmd_seq == command_seq &&
        status.target_cmd == command) {
      if (status.state == 7) {
        response->result_number.data = 0;
        response->result_msg.data = "Medicine box entered fault state, flags=" +
                                    std::to_string(status.fault_flags);
        return;
      }
      const bool complete = request->medicine_box_switch ? status.state == 4
                                                         : status.state == 2;
      if (complete) {
        response->result_number.data = 1;
        response->result_msg.data = "Medicine box switch achieved successfully";
        return;
      }
    }
    wait_rate.sleep();
  }

  response->result_number.data = 2;
  response->result_msg.data = "Medicine box switch timed out waiting for MCU completion status";
}

void BaseController::MedicineBoxStateCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxState::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxState::Response> response)
{
  (void)request;
  MedicineBoxStatusData status;
  if (!sdk_controller_->GetMedicineBoxStatusDetail(status)) {
    response->result_number.data = 0;
    response->result_msg.data = "No current medicine box status is available";
    return;
  }
  response->medicine_box_switch_state = status.state == 4;
  response->result_number.data = 1;
  response->result_msg.data = "Medicine box state retrieved successfully";
}

void BaseController::MedicineBoxCommandCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxCommand::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxCommand::Response> response)
{
  response->accepted = sdk_controller_->SetMedicineBoxCommand(request->command,
                                                               response->command_seq);
  response->message = response->accepted ? "Medicine box command acknowledged by MCU"
                                         : "Invalid command or MCU did not acknowledge it";
}

void BaseController::MedicineBoxStatusCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxStatus::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxStatus::Response> response)
{
  (void)request;
  MedicineBoxStatusData status;
  response->valid = sdk_controller_->GetMedicineBoxStatusDetail(status);
  if (!response->valid) {
    response->message = "No current medicine box status is available";
    return;
  }
  response->uptime_ms = status.uptime_ms;
  response->state = status.state;
  response->target_command = status.target_cmd;
  response->command_source = status.command_source;
  response->io_flags = status.io_flags;
  response->fault_flags = status.fault_flags;
  response->current_ma = status.current_mA;
  response->angle_raw = status.angle_raw;
  response->last_command_seq = status.last_cmd_seq;
  response->last_result = status.last_result;
  response->message = "Medicine box status retrieved successfully";
}


void BaseController::LaserPointerCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::LaserPointer::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::LaserPointer::Response> response)
{
  // 记录接收到的药盒开关请求信息
  RCLCPP_INFO(this->get_logger(), "Received LaserPointer request: %d", request->laser_pointer);

  try {
    if (request->laser_pointer) {
        // 点亮激光灯（输出低电平）
        line.set_value(1);
        RCLCPP_INFO(this->get_logger(), "激光灯已点亮");
            {
        // 加锁获取当前机器人倾斜状态
        std::lock_guard<std::mutex> lock(robot_state_mutex_);
        robot_state_.laser_pointer_state = true;
    }
        
    } else {
        // 熄灭激光灯（输出高电平）
        line.set_value(0);
        RCLCPP_INFO(this->get_logger(), "激光灯已熄灭");
        std::lock_guard<std::mutex> lock(robot_state_mutex_);
        robot_state_.laser_pointer_state = false;
    }
    
    response->result_number.data = 1;
    response->result_msg.data ="laser_pointer control was successful";
    
  } catch (const std::exception& e) {
    RCLCPP_ERROR(this->get_logger(), "激光控制失败: %s", e.what());
    response->result_number.data = 0;
    response->result_msg.data ="laser_pointer control failed";
  }
}


void BaseController::LaserPointerStateCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::LaserPointerState::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::LaserPointerState::Response> response)
{
  (void)request;
  std::lock_guard<std::mutex> lock(robot_state_mutex_);
  //robot_state_ = GetRobotState();  //从mcu获取机器人最新状态   
  response->laser_pointer_state = robot_state_.laser_pointer_state;
  response->result_number.data = 1;
  response->result_msg.data = "laser pointer state retrieved successfully";
  RCLCPP_INFO(this->get_logger(), "Retrieved laser pointer state : %d", robot_state_.laser_pointer_state);
  return;
}


void BaseController::MotorControlCallback(const std_msgs::msg::Float32MultiArray::SharedPtr msg){
  RCLCPP_INFO(this->get_logger(), "MotorControlCallback");

  // 检查消息数据长度是否正确
  if (msg->data.size() < 5) {
      RCLCPP_ERROR(this->get_logger(), "Motor control message has insufficient data: expected 5, got %zu", msg->data.size());
      return;
  }

  // 提取各个控制参数
  float set_screen_tilt_angle = msg->data[0];     // 屏幕俯仰角度
  float set_robot_tilt_angle = msg->data[1];       // 机身俯仰角度
  float set_robot_rise_control = msg->data[2];      // 机身升降控制 (0.0=降下, 1.0=升起)
  float set_medicine_box_switch = msg->data[3]; // 药盒电机控制 (0.0=关, 1.0=开)
  float set_medicine_box_speed = msg->data[4];   // 药盒电机控制速度 (0.0=慢档, 1.0=快档)

  // 打印接收到的数据用于调试
  RCLCPP_INFO(this->get_logger(),
      "Control params: set_screen_tilt_angle=%.2f, set_robot_tilt_angle=%.2f, set_robot_rise_control=%.1f, set_medicine_box_switch=%.1f, set_medicine_box_speed=%.1f",
      set_screen_tilt_angle, set_robot_tilt_angle, set_robot_rise_control,
      set_medicine_box_switch, set_medicine_box_speed);

  //当前只响应药盒电机
  uint8_t TargetCmd;
  uint8_t SpeedGear;
  const float EPSILON = 1e-6f;
  if (fabs(set_medicine_box_switch) < EPSILON) {
    TargetCmd = 0;
  } else {
    TargetCmd = 1;
  }

  if (fabs(set_medicine_box_speed) < EPSILON) {
    SpeedGear = 0;
  } else {
    SpeedGear = 1;
  }

  bool robot_state_change = false;

  {
    std::lock_guard<std::mutex> lock(robot_state_mutex_);

    if (TargetCmd) {   //收到打开
      switch (robot_state_.medicine_box_state) {
        case 0:
          RCLCPP_INFO(this->get_logger(), "当前药盒处于关闭状态，收到打开药盒指令");
          robot_state_.medicine_box_state = 3;
          robot_state_change = true;
          //更新检查药盒电机超时时间，5秒超时
          motor_control_start_time_.medicine_operation_start_time = std::chrono::steady_clock::now();
          break;
        case 1:
          RCLCPP_WARN(this->get_logger(), "当前药盒已处于打开状态，请不要重复发指令");
          break;
        case 2:
          RCLCPP_INFO(this->get_logger(), "当前药盒处于关闭过程中，正在切换为打开药盒");
          robot_state_.medicine_box_state = 3;
          robot_state_change = true;
          motor_control_start_time_.medicine_operation_start_time = std::chrono::steady_clock::now();
          //更新检查药盒电机超时时间，5秒超时
          break;
        case 3:
          RCLCPP_WARN(this->get_logger(), "当前药盒处于打开过程中，请不要重复发指令");
          break;
      }
    }else {
      switch (robot_state_.medicine_box_state) {
        case 0:
          RCLCPP_WARN(this->get_logger(), "当前药盒已处于关闭状态，请不要重复发指令");
          break;
        case 1:
          RCLCPP_INFO(this->get_logger(), "当前药盒处于打开状态，收到关闭药盒指令");
          robot_state_.medicine_box_state = 2;
          robot_state_change = true;
          motor_control_start_time_.medicine_operation_start_time = std::chrono::steady_clock::now();
          //更新检查药盒电机超时时间，5秒超时
          break;
        case 2:
          RCLCPP_WARN(this->get_logger(), "当前药盒处于打开关闭中，请不要重复发指令");
          break;
        case 3:
          RCLCPP_INFO(this->get_logger(), "当前药盒处于打开过程中，正在切换为关闭药盒");
          robot_state_.medicine_box_state = 2;
          robot_state_change = true;
          motor_control_start_time_.medicine_operation_start_time = std::chrono::steady_clock::now();
          //更新检查药盒电机超时时间，5秒超时
          break;
      }
    }

    /* 药盒控制 */ /* TargetCmd = 0 是关闭药盒 TargetCmd = 1 是打开药盒 */ /* SpeedGear = 0 是低速档 SpeedGear = 1 是高速档 */
    if(sdk_controller_->SetMedicineBoxSwitch(TargetCmd, SpeedGear)){
      RCLCPP_INFO(this->get_logger(), "Send to SetMedicineBoxSwitch success,TargetCmd=%d,SpeedGear=%d",TargetCmd,SpeedGear);
    }  

  }

  if (robot_state_change) {
    MotorStatePublish();
  }
}

void BaseController::HeadMotorAngleFeedbackPublish(){
  std_msgs::msg::Float32MultiArray head_angle_msg;
  head_angle_msg.data.resize(2);
  {
    std::lock_guard<std::mutex> lock(robot_state_mutex_);
    // robot_state_中存储的是度，转换为弧度发布
    // pitch: 最上方为零度，范围 0-60°(暂定)
    // yaw: 最右边为零度，范围 0-334°(暂定)
    head_angle_msg.data[0] = robot_state_.head_pitch_angle * DEG_TO_RAD;
    head_angle_msg.data[1] = robot_state_.head_yaw_angle * DEG_TO_RAD;
  }
  auto now_ms_fb = std::chrono::duration_cast<std::chrono::milliseconds>(
      std::chrono::system_clock::now().time_since_epoch()).count();
  std::printf("[HeadAngleFB] time=%lld, yaw=%.6f\n",
    static_cast<long long>(now_ms_fb), head_angle_msg.data[1]);
  std::fflush(stdout);
  head_motor_angle_feedback_pub_->publish(std::move(head_angle_msg));
}

void BaseController::StallFlagPublish(){
  std_msgs::msg::UInt8 stall_msg;
  stall_msg.data = stall_flag_.load();
  stall_flag_pub_->publish(std::move(stall_msg));
}

void BaseController::HeadMotorSpeedControlCallback(const std_msgs::msg::Float32MultiArray::SharedPtr msg){
  if (msg->data.size() < 2) {
    RCLCPP_ERROR(this->get_logger(), "Head motor speed control message has insufficient data: expected 2, got %zu", msg->data.size());
    return;
  }

  // pitch速度：单位 rad/s，向下为正，向上为负
  float head_pitch_speed = msg->data[0];
  // yaw速度：单位 rad/s，逆时针为正，顺时针为负
  float head_yaw_speed = msg->data[1];

  auto now_ms_cb = std::chrono::duration_cast<std::chrono::milliseconds>(
      std::chrono::system_clock::now().time_since_epoch()).count();
  std::printf("[HeadSpeedCB] time=%lld, yaw_speed=%.6f\n",
    static_cast<long long>(now_ms_cb), head_yaw_speed);
  std::fflush(stdout);

  if(sdk_controller_->SetHeadPitchSpeed(head_pitch_speed)){
    RCLCPP_DEBUG(this->get_logger(), "Set head pitch speed: %.3f rad/s", head_pitch_speed);
  }

  if(sdk_controller_->SetHeadYawSpeed(head_yaw_speed)){
    RCLCPP_DEBUG(this->get_logger(), "Set head yaw speed: %.3f rad/s", head_yaw_speed);
  }
}

void BaseController::FourMotorPositionControlCallback(const std_msgs::msg::Float32MultiArray::SharedPtr msg){
  if (msg->data.size() < 4) {
    RCLCPP_ERROR(this->get_logger(), "four_motor_position_control message has insufficient data: expected 4, got %zu", msg->data.size());
    return;
  }

  // 输入单位为弧度，SDK接口单位为°角度
  // data[0] 脖子旋转 neck_yaw   -> SetNeckRollTargetPos (-170° ~ 170°) 注：SDK中 NeckRoll 表示 旋转
  // data[1] 脖子摇摆 neck_roll  -> SetNeckYawTargetPos  (-30° ~ 30°)  注：SDK中 NeckYaw 表示 摇摆
  // data[2] 脖子俯仰 neck_pitch -> SetNeckPitchTargetPos (-30° ~ 30°)
  // data[3] 头部俯仰 head_pitch -> SetHeadPitchTargetPos (-25° ~ 25°)
  float neck_yaw_deg   = msg->data[0] * RAD_TO_DEG;
  float neck_roll_deg  = msg->data[1] * RAD_TO_DEG;
  float neck_pitch_deg = msg->data[2] * RAD_TO_DEG;
  float head_pitch_deg = msg->data[3] * RAD_TO_DEG;

  sdk_controller_->SetNeckRollTargetPos(neck_yaw_deg);
  sdk_controller_->SetNeckYawTargetPos(neck_roll_deg);
  sdk_controller_->SetNeckPitchTargetPos(neck_pitch_deg);
  sdk_controller_->SetHeadPitchTargetPos(head_pitch_deg);

  RCLCPP_DEBUG(this->get_logger(),
    "four_motor_position_control: neck_yaw=%.3f neck_roll=%.3f neck_pitch=%.3f head_pitch=%.3f (deg)",
    neck_yaw_deg, neck_roll_deg, neck_pitch_deg, head_pitch_deg);
}

void BaseController::FourMotorPositionFeedbackPublish(){
  float head_pitch_deg = 0.0f;
  float neck_pitch_deg = 0.0f;
  float neck_yaw_deg   = 0.0f;  // SDK NeckYaw = 摇摆 = doc neck_roll
  float neck_roll_deg  = 0.0f;  // SDK NeckRoll = 旋转 = doc neck_yaw

  sdk_controller_->GetHeadPitchTargetPos(head_pitch_deg);
  sdk_controller_->GetNeckPitchTargetPos(neck_pitch_deg);
  sdk_controller_->GetNeckYawTargetPos(neck_yaw_deg);
  sdk_controller_->GetNeckRollTargetPos(neck_roll_deg);

  std_msgs::msg::Float32MultiArray fb_msg;
  fb_msg.data.resize(4);
  fb_msg.data[0] = neck_roll_deg  * DEG_TO_RAD;  // doc neck_yaw (旋转)
  fb_msg.data[1] = neck_yaw_deg   * DEG_TO_RAD;  // doc neck_roll (摇摆)
  fb_msg.data[2] = neck_pitch_deg * DEG_TO_RAD;
  fb_msg.data[3] = head_pitch_deg * DEG_TO_RAD;

  four_motor_position_feedback_pub_->publish(std::move(fb_msg));
}

void BaseController::ClearFaultCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::ClearFault::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::ClearFault::Response> response)
{
  RCLCPP_INFO(
    this->get_logger(), "Clear fault requested, mask=0x%08X",
    static_cast<unsigned int>(request->fault_mask));

  if (sdk_controller_->ClearFault(request->fault_mask)) {
    response->result_number.data = 1;
    response->result_msg.data = "Fault clear command acknowledged by MCU";
    RCLCPP_INFO(
      this->get_logger(), "Fault clear succeeded, mask=0x%08X",
      static_cast<unsigned int>(request->fault_mask));
    return;
  }

  response->result_number.data = 0;
  response->result_msg.data = "Fault clear command was rejected, timed out, or failed to send";
  RCLCPP_ERROR(
    this->get_logger(), "Fault clear failed, mask=0x%08X",
    static_cast<unsigned int>(request->fault_mask));
}

void BaseController::StatusLightSceneCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::StatusLightScene::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::StatusLightScene::Response> response)
{
  response->accepted = sdk_controller_->SetStatusLightScene(
    request->scene, request->ambient, request->restart_pattern);
  response->message = response->accepted ? "Status light scene acknowledged by MCU"
                                         : "Invalid scene/ambient or MCU did not acknowledge it";
}

void BaseController::StatusLightStateCallback(
  const std::shared_ptr<jqr_ros_msgs::srv::StatusLightState::Request> request,
  std::shared_ptr<jqr_ros_msgs::srv::StatusLightState::Response> response)
{
  (void)request;
  StatusLightData status;
  response->valid = sdk_controller_->GetStatusLightStatus(status);
  if (!response->valid) {
    response->message = "No current status light state is available";
    return;
  }
  response->uptime_ms = status.uptime_ms;
  response->last_command_seq = status.last_cmd_seq;
  response->control_mode = status.control_mode;
  response->scene = status.scene;
  response->ambient = status.ambient;
  response->effect = status.effect;
  response->flags = status.flags;
  response->r_permille = status.r_permille;
  response->g_permille = status.g_permille;
  response->b_permille = status.b_permille;
  response->w_permille = status.w_permille;
  response->message = "Status light state retrieved successfully";
}

}  // namespace jqr_base

// #include "rclcpp_components/register_node_macro.hpp"
// RCLCPP_COMPONENTS_REGISTER_NODE(jqr_base::BaseController)
