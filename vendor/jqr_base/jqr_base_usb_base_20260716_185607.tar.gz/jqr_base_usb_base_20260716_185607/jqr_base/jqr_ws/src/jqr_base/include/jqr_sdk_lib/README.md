# JQR SDK USB串口实现

> 底层通信演进：EtherNet/IP → USB CDC-ACM 自定义协议(0xAA 0x55, 2026-05) →
> 厂商正式 **JQR USB SDK**(`JQR_USB_SDK_CPP` v0.3.0-comm-alpha,
> 0xFA 0xFA 帧 + CRC8 + mod_id/msg_id, 2026-06)。
>
> 厂商 SDK 源码已**直接替换**原有 SDK，扁平放在本目录 `include/`(头) 与 `src/`(实现)，
> 不再有独立 `new_sdk/` 子目录。桥接实现见 `include/SdkController.cpp`，
> 编译脚本 `include/build_sdk_so.sh`。旧自定义协议文件
> (`MotorDataRefresh.cpp` / `ProtocolFrame.*` / `UsbSerialPort.*`) 已删除。

## 1. 设计边界

`libSdkController_aarch64.so` 是 jbase 的硬件抽象层，jbase 通过
`target_link_libraries(jqr_base_node libSdkController_aarch64.so)` 链接消费。

**重构铁律**：上层 jbase 的代码、CMakeLists、`#include` 路径、链接方式、
`SdkController.h` 公开接口签名全部不动；只替换 `.so` 内部实现。本次切换严格遵守：
`SdkController.h` 采用 PIMPL(私有成员为不透明 `Impl*`)，34 个公开符号的
mangled name 与旧 `.so` 逐一 `nm -DC` 比对一致，`MotorDataRefresh.h` 数据结构
二进制布局(pack(1)、字段顺序、类型)不变。

## 2. 协议覆盖范围

厂商 SDK(v0.3.0-comm-alpha)经桥接后，已**真实接通**：

| 能力 | 桥接接口 | 厂商 SDK 来源 |
|------|----------|---------------|
| 底盘整机速度 | `SetRobotVelocities` / `GetRobotVelocities` | Wheel(mm/s + mdeg/s) |
| 头部 4 轴位置目标+反馈 | `Set/GetNeck*`、`Set/GetHeadPitchTargetPos` | Head 4 轴 float° |
| IMU | `GetImuData` | Sensor/0x82(11×float32) |
| 锂电池 SOC | `GetBmsSoc` | MOD_BMS/0x81 |
| 系统使能/版本/连接状态 | `init`(自动使能) / `GetMcuConnectStatus` | System |
| 硬件急停自愈 | 桥接内部监控线程(无公开接口) | SystemStatus.estop/system_enable |

### 硬件急停恢复

厂商硬件急停按钮按下后，MCU 失能(`system_enable=0`、`estop=1`)并对运动命令返回
`ACK_DISABLED`。恢复需要：人工先按硬件复位键(MCU 清 `estop=0`，但 `system_enable`
仍为 0，**不会自动恢复**)，随后上位机**再发一次 `SetSystemEnable(true)`**。

桥接层在 `init()` 启动一个内部监控线程(放在 PIMPL 里，不新增任何公开符号)，
以 100ms 周期轮询 MCU 上报的 `SystemStatus`，识别“急停已物理复位(estop=0)但系统
仍未使能(system_enable=0)”这一边沿，自动补发 `SetSystemEnable(true)` 完成恢复。
业务层(base_controller)无需感知，零改动。

新协议**尚未定义**、桥接层以桩函数处理(set 返回 false、get 返回 0 + 一次性 WARN)：
药盒、机身升降、机身俯仰、屏幕俯仰、超声波、头部堵转标志、Demo3 头部速度控制
(`SetHeadPitchSpeed`/`SetHeadYawSpeed`)。待厂商补 Aux/Sensor 子协议后再接入。

### 单位与映射要点

- 底盘：旧 linear 0.01m/s → mm/s ×10；旧 angular 0.1deg/s → mdeg/s ×100。
- 底盘速度缓存沿用厂商默认 `wheel_target_cache_expire_ms=100`(死手保护)：
  上游持续发布 `/cmd_vel`，base 每帧转发刷新；上游停发超 100ms 则 MCU 停车。
- 头部 4 轴(按协议方向语义)：`HeadPitch→axis0`、`NeckPitch→axis1`、
  `NeckYaw(摇摆)→axis2 neck_swing`、`NeckRoll(旋转)→axis3 head_horizontal`。
  真机部署后必须逐轴校验转动方向，确认映射无错位。

## 3. 代码结构

```
jqr_sdk_lib/
├── include/
│   ├── SdkController.h        # 公开接口(PIMPL，签名与旧 .so 一致)
│   ├── SdkController.cpp      # 桥接实现：旧接口 → 厂商 SDK
│   ├── MotorDataRefresh.h     # 上层共享的 pack(1) 数据结构(无通信类)
│   ├── build_sdk_so.sh        # 独立编译 .so 的脚本
│   ├── JqrSdkController.h     # 厂商 SDK 门面
│   ├── JqrSdkConfig.h / JqrCommTypes.h / JqrProtocol.h
│   ├── JqrSerialPort.h / JqrThreadUtil.h / JqrUsbDataRefresh.h
│   └── JqrSdkVersion.h
├── src/                       # 厂商 SDK 实现
│   ├── JqrSdkController.cpp / JqrProtocol.cpp / JqrSerialPort.cpp
│   ├── JqrThreadUtil.cpp / JqrUsbDataRefresh.cpp
└── lib/sdk_lib/
    └── libSdkController_aarch64.so   # 出货动态库
```

| 层 | 职责 |
|----|------|
| 厂商 SDK(`Jqr*`) | USB CDC 组帧/拆帧、ACK 匹配、状态缓存、目标缓存、周期兜底、重连、统计 |
| 桥接(`SdkController`) | 把旧 34 个公开方法映射到 `jqr::JqrSdkController`，做单位换算与值域 clamp |

## 4. 编译

S100(aarch64)上单独构建动态库——直接用脚本即可：

```bash
cd <jqr_sdk_lib>/include
./build_sdk_so.sh        # 本机架构编译，产物覆盖 ../lib/sdk_lib/
```

交叉编译(在 x86_64 开发机出 aarch64 库)：

```bash
cd <jqr_sdk_lib>/include
aarch64-linux-gnu-g++ -std=c++17 -O2 -fPIC -shared -Wall -I"$PWD" \
  SdkController.cpp \
  ../src/JqrProtocol.cpp ../src/JqrSerialPort.cpp ../src/JqrThreadUtil.cpp \
  ../src/JqrUsbDataRefresh.cpp ../src/JqrSdkController.cpp \
  -lpthread -o ../lib/sdk_lib/libSdkController_aarch64.so
```

随后 jbase 正常 `colcon build`，无需改动其它任何东西。出库后建议核对 ABI：

```bash
aarch64-linux-gnu-nm -DC ../lib/sdk_lib/libSdkController_aarch64.so \
  | grep ' T .*SdkControl::' | wc -l    # 应为 35
```

## 5. 运行

设备路径默认 `/dev/ttyACM0`，USB 接入后 `cdc-acm` 内核模块自动创建。
可用环境变量覆盖：

```bash
export JQR_USB_DEVICE=/dev/ttyACM1   # 设备节点
export JQR_BAUDRATE=115200           # 波特率
ros2 run jqr_base jqr_base_node
```

## 6. 无 MCU 时的验证方法

用 Android 手机 + Termux Python 模拟 MCU。完整链路：

```
ROS2节点 → /dev/ttyACM0 ← socat → TCP:5678 ← adb forward → USB → 手机Termux Python
```

**S100 端**：

```bash
sudo apt install -y android-tools-adb socat
sudo adb forward tcp:5678 tcp:5678
sudo socat PTY,link=/dev/ttyACM0,raw,echo=0,mode=666 TCP:127.0.0.1:5678
```

MCU 模拟器需按厂商协议(0xFA 0xFA + CRC8)组帧应答，并回带**可识别的非零 payload**
(如递增字节/魔数)，便于在 ROS 端验证数据真实流通，而非占位回环。

## 7. 真实 MCU 接入

USB 线直接接 S100，内核创建 `/dev/ttyACM0`，节点直接启动。
多个 CDC-ACM 设备并存时用 `JQR_USB_DEVICE` 指定，或配 udev 稳定命名：

```
# /etc/udev/rules.d/99-jqr-mcu.rules
SUBSYSTEM=="tty", ATTRS{idVendor}=="<VID>", ATTRS{idProduct}=="<PID>", SYMLINK+="ttyJQR"
```

然后 `export JQR_USB_DEVICE=/dev/ttyJQR`。
