#pragma once

#include <array>
#include <atomic>
#include <condition_variable>
#include <deque>
#include <functional>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "JqrCommTypes.h"
#include "JqrProtocol.h"
#include "JqrSdkConfig.h"
#include "JqrSerialPort.h"

namespace jqr {

/**
 * @brief SDK 内部 USB CDC 数据刷新和调度核心。
 *
 * 该类对应旧 EIP SDK 中的 MotorDataRefresh 思路，但针对 USB CDC 做了高响应目标下发：
 *
 * - 业务线程调用 setHeadTarget/setWheelXXX 时只更新“最新目标缓存”，不直接写串口。
 * - TX 线程被唤醒后统一写 USB，保证串口写入口集中，减少多线程并发写导致的乱序风险。
 * - 新目标内容发送前递增 wire_seq；周期补发同一目标复用 wire_seq，便于 MCU 区分
 *   “新目标”和“保活补发”。
 * - RX 线程异步接收 ACK 和状态帧，周期目标 ACK 会缓存到 last_*_target_ack_。
 * - Watchdog 线程检测状态超时和串口错误，并按配置自动重连。
 *
 * 业务层通常不直接使用该类，而是通过 JqrSdkController 调用。
 */
class JqrUsbDataRefresh {
public:
    /** 原始协议帧回调类型；回调运行在 RX 线程中。 */
    using FrameCallback = std::function<void(const JqrFrame&)>;

    /** @brief 构造一个未启动的数据刷新对象。 */
    JqrUsbDataRefresh() = default;

    /** @brief 析构时自动 stop，确保后台线程和串口资源被释放。 */
    ~JqrUsbDataRefresh();

    /**
     * @brief 启动 USB CDC 通信。
     *
     * 函数会保存配置、按需申请内存锁定、打开串口，并启动 RX/TX/Watchdog 线程。
     * 如果对象已经运行，直接返回 true。
     *
     * @param cfg SDK 配置。
     * @return true 启动成功；false 串口打开失败。
     */
    bool start(const JqrSdkConfig& cfg);

    /**
     * @brief 停止通信线程并关闭串口。
     *
     * 函数会设置 running_ 为 false，唤醒 TX 条件变量，等待所有后台线程退出，并关闭串口。
     * 可以重复调用。
     */
    void stop();

    /**
     * @brief 判断后台线程是否处于运行状态。
     *
     * @return true start 成功且尚未 stop；false 未启动或已停止。
     */
    bool isRunning() const { return running_.load(); }

    /**
     * @brief 判断 MCU 在线状态。
     *
     * 在线状态由系统状态帧和 Watchdog 维护，不等价于串口 fd 是否打开。
     *
     * @return true MCU 最近有有效状态上报；false 未收到状态、状态超时或串口异常。
     */
    bool isOnline() const { return mcu_online_.load(); }

    /**
     * @brief 设置原始帧回调。
     *
     * @param cb 回调函数；传入空回调可取消。
     */
    void setFrameCallback(FrameCallback cb);

    /**
     * @brief 发送系统心跳。
     *
     * wait_ack 为 true 时通过普通命令队列发送并等待 ACK；false 时直接由 TX 线程语境写出，
     * 用于 txLoop 周期保活。
     *
     * @param wait_ack 是否等待 MCU ACK。
     * @return true 发送成功且如果等待 ACK 则 ACK 为 OK；false 发送失败或等待超时。
     */
    bool sendHeartbeat(bool wait_ack = true);

    /**
     * @brief 同步设置系统使能状态。
     *
     * @param enable true 使能，false 失能。
     * @return true MCU ACK 为 OK；false 发送失败、超时或 ACK 错误。
     */
    bool setSystemEnable(bool enable);

    /**
     * @brief 同步清除故障。
     *
     * @param mask 需要清除的故障位掩码。
     * @return true MCU ACK 为 OK；false 发送失败、超时或 ACK 错误。
     */
    bool clearFault(uint32_t mask = 0xFFFFFFFFu);

    /**
     * @brief 查询 MCU 版本。
     *
     * @param out 输出版本信息。
     * @return true 收到版本上报并成功解码；false 发送失败或等待超时。
     */
    bool getVersion(JqrVersion& out);

    /**
     * @brief 更新头部四轴目标缓存。
     *
     * 该接口不直接等待 ACK，只更新缓存并唤醒 TX 线程。新目标会尽快发送，后续按配置周期
     * 补发。实际接收情况通过 getLastHeadTargetAck 查询。
     *
     * @param hp head_pitch 目标角度，单位 deg。
     * @param np neck_pitch 目标角度，单位 deg。
     * @param ns neck_swing 目标角度，单位 deg。
     * @param head_horizontal 头部水平目标角度，单位 deg。
     * @param speed_limit 四轴共用速度限制，单位 deg/s。
     * @return true 目标已写入 SDK 缓存。
     */
    bool setHeadTarget(float hp, float np, float ns, float head_horizontal,
                       float speed_limit = 30.0f);

    /**
     * @brief 更新头部单轴目标，其他三个轴保持最近缓存目标。
     *
     * 如果缓存尚未初始化，函数会先用最近一次 HeadStatus 反馈角度填充四轴目标，确保只控
     * 一个轴时不会把其他轴写成 0。尚未收到 HeadStatus 时返回 false。
     *
     * @param axis 要更新的头部轴。
     * @param target_deg 单轴目标角度，单位 deg。
     * @param speed_limit 四轴共用速度限制，单位 deg/s。
     * @return true 目标已写入 SDK 缓存；false 轴号非法或没有可用反馈初始化缓存。
     */
    bool setHeadAxisTarget(HeadAxis axis, float target_deg, float speed_limit = 30.0f);

    /**
     * @brief 立即发送 Head STOP，并停止 SDK 继续补发头部位置目标。
     *
     * 该接口不等待同步 ACK，MCU ACK 由 RX 线程异步缓存。
     *
     * @return true STOP 帧已进入发送队列；false SDK 未运行或组帧失败。
     */
    bool clearHeadTarget();

    /**
     * @brief 立即发送 Head STOP，并停止 SDK 继续补发头部位置目标。
     *
     * @return true STOP 帧已进入发送队列；false SDK 未运行或组帧失败。
     */
    bool stopHead();

    /**
     * @brief 更新轮组底盘速度目标缓存。
     *
     * @param linear_mm_s 线速度，单位 mm/s。
     * @param angular_mdeg_s 角速度，单位 mdeg/s。
     * @return true 目标已写入 SDK 缓存。
     */
    bool setChassisVelocity(int32_t linear_mm_s, int32_t angular_mdeg_s);

    /**
     * @brief 停止轮组输出并同步等待 STOP 目标 ACK。
     *
     * 函数会清除轮组周期目标缓存，然后发送 STOP 模式目标。该接口优先用于安全停止，
     * 因此采用同步等待 ACK。
     *
     * @return true MCU ACK 为 OK；false 发送失败、超时或 ACK 错误。
     */
    bool stopWheel();

    /**
     * @brief 同步下发药盒 STOP/OPEN/CLOSE 命令。
     * @note 返回 true 仅表示 MCU 接受命令，动作结果需读取 MedicineStatus。
     */
    bool setMedicineCommand(MedicineCommand command);

    /**
     * @brief 同步下发药盒命令，并返回本次命令序号。
     * @param command STOP/OPEN/CLOSE。
     * @param seq_out 输出本次命令seq；参数非法时输出0。
     * @note 动作结果应使用MedicineStatus.last_cmd_seq与seq_out匹配确认。
     */
    bool setMedicineCommand(MedicineCommand command, uint8_t& seq_out);

    /** @brief 同步下发产品状态灯场景，MCU 本地执行呼吸/闪烁波形。 */
    bool setLightScene(LightScene scene,
                       LightAmbient ambient,
                       bool restart_pattern = false);

    /** @brief 同步下发 RGBW 千分比直控命令，仅用于产测和标定。 */
    bool setLightRgbw(uint16_t r_permille,
                      uint16_t g_permille,
                      uint16_t b_permille,
                      uint16_t w_permille);

    /**
     * @brief 获取系统状态缓存。
     *
     * @param out 输出系统状态。
     * @return true 已收到过系统状态；false 尚无缓存。
     */
    bool getSystemStatus(JqrSystemStatus& out) const;

    /**
     * @brief 获取轮组状态缓存。
     *
     * @param out 输出轮组状态。
     * @return true 已收到过轮组状态；false 尚无缓存。
     */
    bool getWheelStatus(JqrWheelStatus& out) const;

    /**
     * @brief 获取头部状态缓存。
     *
     * @param out 输出头部状态。
     * @return true 已收到过头部状态；false 尚无缓存。
     */
    bool getHeadStatus(JqrHeadStatus& out) const;

    /**
     * @brief 获取传感器原始状态缓存。
     *
     * @param out 输出传感器原始状态。
     * @return true 已收到过传感器状态；false 尚无缓存。
     */
    bool getSensorStatusRaw(JqrSensorStatusRaw& out) const;

    /**
     * @brief 获取最近一次 IMU 专用上报缓存。
     *
     * @param out 输出 IMU 数据，结构字段与 Sensor/0x82 payload 一致。
     * @return true 已收到过 IMU 上报；false 尚无缓存。
     */
    bool getImuData(ImuRecvDataStruct& out) const;

    /**
     * @brief 获取锂电池 BMS 状态缓存。
     * @param out 输出 BMS 状态。
     * @return true 已收到过 BMS 状态；false 尚无缓存。
     */
    bool getBmsStatus(JqrBmsStatus& out) const;

    /** @brief 获取最近一次药盒状态缓存。 */
    bool getMedicineStatus(JqrMedicineStatus& out) const;

    /** @brief 获取最近一次状态灯执行状态缓存。 */
    bool getLightStatus(JqrLightStatus& out) const;

    /**
     * @brief 获取最近一次轮组目标异步 ACK。
     *
     * @param out 输出 ACK 状态。
     * @return true 已收到过轮组目标 ACK；false 尚未收到。
     */
    bool getLastWheelTargetAck(TargetAckStatus& out) const;

    /**
     * @brief 获取最近一次头部目标异步 ACK。
     *
     * @param out 输出 ACK 状态。
     * @return true 已收到过头部目标 ACK；false 尚未收到。
     */
    bool getLastHeadTargetAck(TargetAckStatus& out) const;

    /**
     * @brief 获取运行统计快照。
     *
     * @return SDK 统计结构体拷贝。
     */
    JqrSdkRuntimeStats getStats() const;

private:
    /** 头部最新目标缓存，业务线程写入，TX 线程读取并发送。 */
    struct HeadTargetCache {
        /** 业务层每次更新目标时递增，用于标记缓存内容变化。 */
        uint32_t cache_version = 0;
        /** TX 线程最近一次成功取走的新内容版本。 */
        uint32_t sent_version = 0;
        /** 协议线上 seq，新目标递增，周期补发保持不变。 */
        uint8_t wire_seq = 0;
        /** true 表示缓存中有需要周期下发的有效目标。 */
        bool valid = false;
        /** true 表示 target_deg 已经用反馈或完整目标初始化，可安全做单轴更新。 */
        bool initialized = false;
        /** 四轴目标角度，顺序为 head_pitch、neck_pitch、neck_swing、head_horizontal。 */
        std::array<float, 4> target_deg{{0, 0, 0, 0}};
        /** 四轴共用速度限制，单位 deg/s。 */
        float speed_limit = 30.0f;
        /** 业务层最近更新该目标的本地时间戳，单位 ms。 */
        uint32_t update_ms = 0;
    };

    /** 轮组最新目标缓存，业务层只使用底盘线速度/角速度模式。 */
    struct WheelTargetCache {
        /** 业务层每次更新目标时递增，用于标记缓存内容变化。 */
        uint32_t cache_version = 0;
        /** TX 线程最近一次成功取走的新内容版本。 */
        uint32_t sent_version = 0;
        /** 协议线上 seq，新目标递增，周期补发保持不变。 */
        uint8_t wire_seq = 0;
        /** true 表示缓存中有需要周期下发的有效目标。 */
        bool valid = false;
        /** 轮组控制模式。 */
        WheelMode mode = WheelMode::STOP;
        /** 是否使能轮组输出。 */
        bool enable = false;
        /** 扩展标志位，当前默认 0。 */
        uint8_t flags = 0;
        /** 底盘线速度，单位 mm/s。 */
        int32_t linear_mm_s = 0;
        /** 底盘角速度，单位 mdeg/s。 */
        int32_t angular_mdeg_s = 0;
        /** 协议兼容保留字段；SDK 业务接口固定为 0。 */
        int16_t left_rpm = 0;
        /** 协议兼容保留字段；SDK 业务接口固定为 0。 */
        int16_t right_rpm = 0;
        /** 业务层最近更新该目标的本地时间戳，单位 ms。 */
        uint32_t update_ms = 0;
    };

    /** TX 普通命令队列元素，用于需要排队发送或等待 ACK 的非周期命令。 */
    struct TxCommand {
        /** @brief 构造空命令，便于作为 dequeue 输出参数。 */
        TxCommand() = default;

        /**
         * @brief 构造一条待发送命令。
         *
         * @param mod 模块 ID。
         * @param msg 消息 ID。
         * @param p payload 字节。
         */
        TxCommand(uint8_t mod, uint8_t msg, const std::vector<uint8_t>& p)
            : mod_id(mod), msg_id(msg), payload(p) {}

        /** 模块 ID。 */
        uint8_t mod_id = 0;
        /** 消息 ID。 */
        uint8_t msg_id = 0;
        /** 已打包好的业务 payload，不含协议帧头帧尾。 */
        std::vector<uint8_t> payload;
    };

    JqrSdkConfig cfg_;

    mutable std::mutex cache_mtx_;
    JqrSystemStatus system_status_;
    JqrWheelStatus wheel_status_;
    JqrHeadStatus head_status_;
    JqrSensorStatusRaw sensor_status_;
    ImuRecvDataStruct imu_data_;
    JqrBmsStatus bms_status_;
    JqrMedicineStatus medicine_status_;
    JqrLightStatus light_status_;
    JqrVersion version_;
    TargetAckStatus last_wheel_target_ack_;
    TargetAckStatus last_head_target_ack_;
    bool has_system_status_ = false;
    bool has_wheel_status_ = false;
    bool has_head_status_ = false;
    bool has_sensor_status_ = false;
    bool has_imu_data_ = false;
    bool has_bms_status_ = false;
    bool has_medicine_status_ = false;
    bool has_light_status_ = false;
    bool has_version_ = false;

    HeadTargetCache head_target_;
    WheelTargetCache wheel_target_;

    mutable std::mutex stats_mtx_;
    JqrSdkRuntimeStats stats_;

    std::atomic<bool> running_{false};
    std::atomic<bool> mcu_online_{false};
    std::atomic<bool> serial_need_reopen_{false};

    mutable std::mutex serial_mtx_;
    JqrSerialPort serial_;
    JqrProtocolParser parser_;

    std::thread rx_thread_;
    std::thread tx_thread_;
    std::thread watchdog_thread_;

    std::mutex tx_cv_mtx_;
    std::condition_variable tx_cv_;

    std::mutex tx_queue_mtx_;
    std::deque<TxCommand> tx_queue_;

    mutable std::mutex cb_mtx_;
    FrameCallback frame_cb_;

    std::mutex tx_mtx_;
    uint8_t seq_ = 1;

    std::mutex ack_mtx_;
    std::condition_variable ack_cv_;
    bool waiting_ack_ = false;
    bool ack_matched_ = false;
    uint8_t pending_seq_ = 0;
    uint8_t pending_mod_ = 0;
    uint8_t pending_msg_ = 0;
    JqrAck pending_ack_;

    std::mutex version_mtx_;
    std::condition_variable version_cv_;

    /**
     * @brief 生成普通同步命令使用的非零 seq。
     *
     * @return 1..255 循环的序号。
     */
    uint8_t nextSeq();

    /**
     * @brief 将给定 seq 递增到下一个非零值。
     *
     * 周期目标各自维护独立 wire_seq，避免与普通命令 seq 相互干扰。
     *
     * @param s 当前 seq。
     * @return 下一个非零 seq。
     */
    static uint8_t nextNonZeroSeq(uint8_t s);

    /**
     * @brief 在 serial_mtx_ 已加锁的前提下打开串口并重置解析器。
     *
     * @return true 打开成功；false 打开失败。
     */
    bool openSerialLocked();

    /**
     * @brief 由 TX 线程语境写出一帧协议帧。
     *
     * 所有串口写都集中经过该函数，便于统计和错误处理。函数内部会加 serial_mtx_。
     *
     * @param mod_id 模块 ID。
     * @param msg_id 消息 ID。
     * @param payload 业务 payload。
     * @return true 写入成功；false 组帧失败、串口未打开或写入失败。
     */
    bool writeFrameFromTxThread(uint8_t mod_id, uint8_t msg_id, const std::vector<uint8_t>& payload);

    /**
     * @brief 将一条普通命令放入 TX 队列并唤醒发送线程。
     *
     * @param mod_id 模块 ID。
     * @param msg_id 消息 ID。
     * @param payload 业务 payload。
     * @return true 入队成功；false SDK 未运行或 payload 无法组帧。
     */
    bool queueRawFrame(uint8_t mod_id, uint8_t msg_id, const std::vector<uint8_t>& payload);

    /**
     * @brief 从 TX 队列取出一条普通命令。
     *
     * @param out 输出命令。
     * @return true 成功取出；false 队列为空。
     */
    bool dequeueTxCommand(TxCommand& out);

    /**
     * @brief 在 cache_mtx_ 已加锁时，用最近一次 HeadStatus 初始化头部目标缓存。
     *
     * @param now_ms 当前本地时间，单位 ms。
     * @return true 初始化成功；false 尚未收到过 HeadStatus。
     */
    bool initHeadTargetFromFeedbackLocked(uint32_t now_ms);

    /** @brief 清除药盒状态有效标志，防止断线或重连后读取旧缓存。 */
    void invalidateMedicineStatusCache();

    /** @brief 清除状态灯状态有效标志，防止重连后读取旧缓存。 */
    void invalidateLightStatusCache();

    /**
     * @brief 发送普通命令并同步等待匹配 ACK。
     *
     * 匹配条件为 seq、req_mod、req_msg 完全一致。同一时刻只允许一条同步等待命令，
     * 避免 ACK 等待状态互相覆盖。
     *
     * @param mod_id 模块 ID。
     * @param msg_id 消息 ID。
     * @param payload 业务 payload，payload[0] 应为 seq。
     * @param seq 命令序号。
     * @param ack_out 可选输出 ACK。
     * @param timeout_ms 等待超时时间，单位 ms。
     * @return true ACK 为 OK；false 发送失败、等待超时或 ACK 非 OK。
     */
    bool sendCommandWaitAck(uint8_t mod_id, uint8_t msg_id,
                            const std::vector<uint8_t>& payload,
                            uint8_t seq,
                            JqrAck* ack_out,
                            int timeout_ms = 1000);

    /** @brief RX 线程入口，持续读取串口字节并交给协议解析器。 */
    void rxLoop();

    /** @brief TX 线程入口，负责普通队列、目标新内容、周期补发和心跳发送。 */
    void txLoop();

    /** @brief Watchdog 线程入口，负责状态超时检测和自动重连。 */
    void watchdogLoop();

    /** @brief 按周期补发头部最新目标，保留给明确周期发送路径使用。 */
    void sendPeriodicHeadTarget();

    /** @brief 按周期补发轮组最新目标，保留给明确周期发送路径使用。 */
    void sendPeriodicWheelTarget();

    /** @brief 处理 TX 普通命令队列，逐条写入 USB。 */
    void processQueuedTxCommands();

    /**
     * @brief 处理一帧已解析协议帧。
     *
     * 该函数更新 ACK 匹配状态、状态缓存、版本缓存、在线状态、统计信息，并在最后触发
     * 用户注册的帧回调。
     *
     * @param frame 已通过 CRC 和帧尾校验的协议帧。
     */
    void handleFrame(const JqrFrame& frame);

    /**
     * @brief 判断目标缓存是否因业务层长时间未刷新而过期。
     *
     * @param target_update_ms 目标最近更新时间，单位 ms。
     * @param now_ms 当前本地时间，单位 ms。
     * @param expire_ms 缓存过期时间，单位 ms；0 表示永不过期。
     * @return true 已过期；false 未过期或配置为永不过期。
     */
    static bool isTargetCacheExpired(uint32_t target_update_ms, uint32_t now_ms, uint32_t expire_ms);

    /** @brief 获取头部目标缓存过期时间，兼容旧全局配置覆盖。 */
    uint32_t headTargetCacheExpireMs() const;

    /** @brief 获取底盘目标缓存过期时间，兼容旧全局配置覆盖。 */
    uint32_t wheelTargetCacheExpireMs() const;

    /**
     * @brief 获取 SDK 本地单调毫秒计时。
     *
     * @return 从首次调用起算的毫秒数。
     */
    static uint32_t localMs();

    /**
     * @brief 判断从 last 到 now 是否已经经过 period。
     *
     * 使用 uint32_t 差值，天然兼容计数回绕。
     *
     * @param now 当前时间，单位 ms。
     * @param last 上次时间，单位 ms。
     * @param period 周期，单位 ms。
     * @return true 已到期；false 未到期。
     */
    static bool elapsed(uint32_t now, uint32_t last, uint32_t period);

    /**
     * @brief 计算两个本地毫秒时间戳差值。
     *
     * @param now 当前时间，单位 ms。
     * @param last 过去时间，单位 ms。
     * @return now - last 的 uint32_t 差值，兼容计数回绕。
     */
    static uint32_t diffMs(uint32_t now, uint32_t last);
};

} // namespace jqr
