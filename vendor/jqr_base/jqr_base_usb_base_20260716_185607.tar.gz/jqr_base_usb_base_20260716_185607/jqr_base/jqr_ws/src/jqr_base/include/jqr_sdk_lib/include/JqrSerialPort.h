#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace jqr {

/**
 * @brief Linux USB CDC ACM 串口封装。
 *
 * MCU 通过 USB CDC 暴露为 /dev/ttyACM0 这类设备节点。SDK 使用 POSIX termios
 * 按原始串口模式收发字节，不直接依赖 libusb。该类只负责字节读写，不解析协议帧。
 */
class JqrSerialPort {
public:
    /** @brief 构造一个未打开的串口对象。 */
    JqrSerialPort() = default;

    /**
     * @brief 析构时自动关闭串口。
     *
     * 如果串口已经关闭，该函数无额外影响。
     */
    ~JqrSerialPort();

    /**
     * @brief 打开并配置 USB CDC 设备节点。
     *
     * 函数会先关闭已有 fd，再以 O_NONBLOCK 打开设备，配置 raw 模式、8N1、关闭硬件流控，
     * 并拉高 DTR/RTS，模拟 pyserial 的常见行为，减少 CDC 设备刚打开时首帧不稳定问题。
     *
     * @param device 设备节点路径，例如 /dev/ttyACM0。
     * @param baudrate 波特率，不支持的值会回退为 115200。
     * @return true 打开和配置成功；false 打开或 termios 配置失败，可用 lastError 查看原因。
     */
    bool open(const std::string& device, int baudrate = 115200);

    /**
     * @brief 关闭当前串口 fd。
     *
     * 可重复调用。关闭后 readSome 会返回 -1，writeAll 会返回 false。
     */
    void close();

    /**
     * @brief 判断串口 fd 是否处于打开状态。
     *
     * @return true fd 有效；false fd 未打开或已经关闭。
     */
    bool isOpen() const;

    /**
     * @brief 非阻塞读取一段字节。
     *
     * @param buffer 输出缓冲区。
     * @param max_len 最多读取字节数。
     * @return >0 实际读取字节数；0 当前无数据；-1 参数错误、fd 无效或系统 read 失败。
     */
    int readSome(uint8_t* buffer, size_t max_len);

    /**
     * @brief 尽量写完整段字节。
     *
     * 函数会循环处理短写；遇到 EAGAIN/EWOULDBLOCK 会短暂 sleep 后重试。成功写完后调用
     * tcdrain，确保数据进入驱动发送队列。
     *
     * @param data 待发送字节首地址。
     * @param len 待发送字节长度。
     * @return true 已写完整段数据；false fd 无效、参数为空或系统 write 失败。
     */
    bool writeAll(const uint8_t* data, size_t len);

    /**
     * @brief vector 形式的写完整段字节便捷接口。
     *
     * @param data 待发送字节数组。
     * @return true 已写完整段数据；false 写入失败。
     */
    bool writeAll(const std::vector<uint8_t>& data) {
        return writeAll(data.data(), data.size());
    }

    /**
     * @brief 获取最近一次串口错误描述。
     *
     * @return 错误字符串；如果近期没有错误，可能为空或保留上一次错误。
     */
    std::string lastError() const { return last_error_; }

private:
    /** POSIX 文件描述符，-1 表示未打开。 */
    int fd_ = -1;
    /** 最近一次 open/configure/read/write 失败原因。 */
    std::string last_error_;

    /**
     * @brief 配置 termios 参数。
     *
     * @param baudrate 目标波特率。
     * @return true 配置成功；false tcgetattr 或 tcsetattr 失败。
     */
    bool configure(int baudrate);
};

} // namespace jqr
