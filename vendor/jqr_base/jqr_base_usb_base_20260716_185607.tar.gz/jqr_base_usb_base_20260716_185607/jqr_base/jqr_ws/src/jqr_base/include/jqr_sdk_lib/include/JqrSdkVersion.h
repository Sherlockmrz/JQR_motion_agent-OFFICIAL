#pragma once

namespace jqr {

/** JQR USB SDK 版本号。 */
static constexpr int JQR_USB_SDK_VERSION_MAJOR = 0;
static constexpr int JQR_USB_SDK_VERSION_MINOR = 3;
static constexpr int JQR_USB_SDK_VERSION_PATCH = 0;

/**
 * 当前版本定位：通信联调 alpha 版。
 * 已完成 USB CDC 协议、异步 ACK、目标缓存、周期兜底、测试 Demo；
 * 尚未代表真实底盘/头部电机闭环控制已完成量产验证。
 */
static constexpr const char* JQR_USB_SDK_VERSION_STRING = "0.3.0-comm-alpha.1";

} // namespace jqr
