#pragma once

#include <array>
#include <cstdint>

namespace jqr {

/**
 * @brief JQR USB CDC 协议模块 ID。
 *
 * Host -> MCU 和 MCU -> Host 使用同一套 mod_id/msg_id。模块 ID 用于区分系统、
 * 轮组、头部、辅助设备、传感器和灯光等功能域。
 */
constexpr uint8_t MOD_SYSTEM = 0x01;
constexpr uint8_t MOD_WHEEL  = 0x02;
constexpr uint8_t MOD_HEAD   = 0x03;
constexpr uint8_t MOD_AUX    = 0x04;
constexpr uint8_t MOD_SENSOR = 0x05;
constexpr uint8_t MOD_LIGHT  = 0x06;
constexpr uint8_t MOD_BMS    = 0x07;

/** 系统保活命令，payload 为 seq。 */
constexpr uint8_t MSG_HEARTBEAT     = 0x01;
/** 系统使能/失能命令，payload 为 seq + enable。 */
constexpr uint8_t MSG_SYSTEM_ENABLE = 0x02;
/** 清故障命令，payload 为 seq + fault_mask。 */
constexpr uint8_t MSG_CLEAR_FAULT   = 0x03;
/** 查询版本命令，MCU 通过 MSG_VERSION_RPT 返回。 */
constexpr uint8_t MSG_GET_VERSION   = 0x05;

/** MCU 对需要确认的命令返回的统一 ACK 消息。 */
constexpr uint8_t MSG_ACK           = 0x7F;
/** MCU 周期上报的系统状态。 */
constexpr uint8_t MSG_SYSTEM_STATUS = 0x81;
/** MCU 返回的协议和固件版本信息。 */
constexpr uint8_t MSG_VERSION_RPT   = 0x82;

/** 轮组运动目标命令。 */
constexpr uint8_t MSG_WHEEL_TARGET  = 0x01;
/** MCU 周期上报的轮组状态。 */
constexpr uint8_t MSG_WHEEL_STATUS  = 0x81;

/** 头部四轴 float 位置目标命令。 */
constexpr uint8_t MSG_HEAD_TARGET_FLOAT = 0x01;
/** 头部回零命令预留 ID，当前 SDK 未暴露业务接口。 */
constexpr uint8_t MSG_HEAD_HOME         = 0x03;
/** MCU 周期上报的头部四轴 float 状态。 */
constexpr uint8_t MSG_HEAD_STATUS_FLOAT = 0x81;

/** 药盒一次性控制命令，payload 为 seq + command + speed_gear(固定0)。 */
constexpr uint8_t MSG_MEDICINE_COMMAND = 0x01;
/** MCU 周期上报的药盒状态。 */
constexpr uint8_t MSG_MEDICINE_STATUS  = 0x81;

/** RGBW 四通道产测/标定直控命令。 */
constexpr uint8_t MSG_LIGHT_SET_RGBW  = 0x01;
/** 产品状态灯场景命令。 */
constexpr uint8_t MSG_LIGHT_SET_SCENE = 0x02;
/** MCU 周期上报的状态灯执行状态。 */
constexpr uint8_t MSG_LIGHT_STATUS    = 0x81;

/** MCU 周期上报的传感器原始状态。 */
constexpr uint8_t MSG_SENSOR_STATUS = 0x81;
/** MCU 周期上报的 IMU 姿态和 6 轴数据。 */
constexpr uint8_t MSG_IMU_REPORT    = 0x82;

/** MCU 周期上报的锂电池 BMS 状态。 */
constexpr uint8_t MSG_BMS_STATUS    = 0x81;

/**
 * @brief MCU ACK 状态码。
 *
 * SDK 中同步接口会把 OK 作为 true，其余状态作为 false。周期目标 ACK 是异步缓存，
 * 业务层需要读取 TargetAckStatus::status 并结合 ackStatusToString 判断原因。
 */
enum class AckStatus : uint8_t {
    OK = 0x00,           /** 命令已被 MCU 接收。 */
    CRC_ERROR = 0x01,    /** 帧 CRC 校验失败。 */
    LEN_ERROR = 0x02,    /** payload 长度不符合协议。 */
    UNSUPPORTED = 0x03,  /** 当前模块或消息不支持。 */
    BUSY = 0x04,         /** MCU 忙，暂时无法处理。 */
    PARAM_ERROR = 0x05,  /** 参数越界或组合非法。 */
    STATE_ERROR = 0x06,  /** 当前状态不允许执行该命令。 */
    TIMEOUT = 0x07,      /** 命令等待或执行超时。 */
    FAULT_LOCKED = 0x08, /** 故障锁定，需清故障或人工处理。 */
    DISABLED = 0x09,     /** 系统未使能，拒绝运动类命令。 */
};

/** 轮组目标控制模式。 */
enum class WheelMode : uint8_t {
    STOP = 0,       /** 停止输出。 */
    CHASSIS = 1,    /** 底盘线速度/角速度模式。 */
    DIRECT_RPM = 2, /** 协议兼容保留，业务层不再暴露左右轮 RPM 控制。 */
};

/** 头部目标控制模式。 */
enum class HeadMode : uint8_t {
    STOP = 0,     /** 停止或无目标。 */
    POSITION = 1, /** 位置目标模式。 */
    SPEED = 2,    /** 速度目标模式，当前 SDK 未暴露业务接口。 */
    HOME = 3,     /** 回零模式，当前 SDK 未暴露业务接口。 */
};

/** 头部四轴顺序，必须与协议 target_deg[4] 顺序保持一致。 */
enum class HeadAxis : uint8_t {
    HEAD_PITCH = 0,      /** axis0：头部俯仰，水平朝前为 0 度，向下为正。 */
    NECK_PITCH = 1,      /** axis1：脖子俯仰，水平朝前为 0 度，向下为正。 */
    NECK_SWING = 2,      /** axis2：脖子摇摆，垂直为 0 度，向左为正。 */
    HEAD_HORIZONTAL = 3, /** axis3：头部水平，居中朝前为 0 度，逆时针为正。 */
};

/** 药盒开关命令。 */
enum class MedicineCommand : uint8_t {
    STOP = 0,
    OPEN = 1,
    CLOSE = 2,
};

/** 药盒控制状态，与主MCU jqr_medicine_state_t 保持一致。 */
enum class MedicineState : uint8_t {
    UNINIT = 0,
    UNKNOWN = 1,
    CLOSED = 2,
    OPENING = 3,
    OPEN = 4,
    CLOSING = 5,
    STOPPED = 6,
    FAULT = 7,
};

/** 命令来源，便于业务层区分本地按钮和上位机操作。 */
enum class MedicineCommandSource : uint8_t {
    NONE = 0,
    BUTTON = 1,
    HOST = 2,
    SAFETY = 3,
};

/** 最近一次药盒动作结果，与主MCU jqr_medicine_result_t 保持一致。 */
enum class MedicineResult : uint8_t {
    NONE = 0,
    OK = 1,
    I2C = 2,
    OVERCURRENT = 3,
    TIMEOUT = 4,
    STALL = 5,
    STOPPED = 6,
    INIT = 7,
    ADC = 8,
};

/** 状态灯业务场景；场景仲裁由 S100-p 完成，MCU 只执行选中的场景。 */
enum class LightScene : uint8_t {
    OFF = 0,
    WAITING = 1,
    WORKING = 2,
    SAFETY_ALERT = 3,
    FAULT = 4,
    ESTOP = 5,
    LOW_BATTERY = 6,
    CRITICAL_BATTERY = 7,
    CHARGING = 8,
    UPGRADING = 9,
    PAIRING = 10,
};

enum class LightAmbient : uint8_t {
    DAY = 0,
    NIGHT = 1,
};

enum class LightControlMode : uint8_t {
    OFF = 0,
    RAW = 1,
    SCENE = 2,
};

enum class LightEffect : uint8_t {
    OFF = 0,
    STEADY = 1,
    BLINK = 2,
    BREATHE = 3,
};

constexpr uint8_t LIGHT_SCENE_FLAG_RESTART_PATTERN = 1u << 0;

/**
 * @brief MCU ACK 解码结果。
 *
 * ACK 中的 seq、req_mod、req_msg 用于精确匹配被确认的命令，避免多条命令同时存在时
 * 误把别的命令 ACK 当成本次结果。
 */
struct JqrAck {
    /** MCU 回显的命令序号。 */
    uint8_t seq = 0;
    /** 被确认命令的模块 ID。 */
    uint8_t req_mod = 0;
    /** 被确认命令的消息 ID。 */
    uint8_t req_msg = 0;
    /** ACK 状态码，取值见 AckStatus。 */
    uint8_t status = 0;
    /** MCU 返回的扩展错误详情，含义由具体模块定义。 */
    uint16_t detail = 0;
};

/** MCU 协议版本、固件版本和构建信息。 */
struct JqrVersion {
    /** 协议主版本。 */
    uint8_t protocol_major = 0;
    /** 协议次版本。 */
    uint8_t protocol_minor = 0;
    /** 固件主版本。 */
    uint8_t firmware_major = 0;
    /** 固件次版本。 */
    uint8_t firmware_minor = 0;
    /** 固件补丁版本。 */
    uint8_t firmware_patch = 0;
    /** 板卡类型，由 MCU 侧定义。 */
    uint8_t board_type = 0;
    /** 固件构建时间戳，由 MCU 侧打包。 */
    uint32_t build_timestamp = 0;
    /** 短 git hash，便于现场确认固件来源。 */
    uint32_t git_hash_short = 0;
};

/** MCU 周期上报的系统状态缓存。 */
struct JqrSystemStatus {
    /** MCU 启动后运行时间，单位 ms。 */
    uint32_t uptime_ms = 0;
    /** 系统使能状态，0 表示未使能，非 0 表示已使能。 */
    uint8_t system_enable = 0;
    /** 急停状态，0 表示未触发，非 0 表示触发。 */
    uint8_t estop = 0;
    /** 碰撞或防撞状态，0 表示未触发，非 0 表示触发。 */
    uint8_t bump = 0;
    /** 系统故障位图，具体 bit 含义由 MCU 侧定义。 */
    uint32_t fault_bitmap = 0;
    /** MCU 认为 USB 上位机在线的状态。 */
    uint8_t usb_online = 0;
    /** 当前工作模式，由 MCU 侧定义。 */
    uint8_t work_mode = 0;

    /** SDK 本地收到该状态的时间戳，单位 ms，用于业务层判断数据新鲜度。 */
    uint32_t update_ms_local = 0;
};

/** MCU 周期上报的轮组状态缓存。 */
struct JqrWheelStatus {
    /** 当前底盘线速度估计，单位 mm/s。 */
    int32_t linear_mm_s = 0;
    /** 当前底盘角速度估计，单位 mdeg/s。 */
    int32_t angular_mdeg_s = 0;
    /** 左轮当前转速，单位 rpm；业务层通常只需要 linear_mm_s/angular_mdeg_s。 */
    int16_t left_rpm = 0;
    /** 右轮当前转速，单位 rpm；业务层通常只需要 linear_mm_s/angular_mdeg_s。 */
    int16_t right_rpm = 0;
    /** 左轮 q 轴电流，单位 mA。 */
    int16_t left_iq_mA = 0;
    /** 右轮 q 轴电流，单位 mA。 */
    int16_t right_iq_mA = 0;
    /** 母线电压，单位 cV，即 0.01 V。 */
    uint16_t vbus_cV = 0;
    /** 轮组故障位图，具体 bit 含义由 MCU 侧定义。 */
    uint16_t fault_flags = 0;
    /** 左轮驱动状态，枚举含义由 MCU 侧定义。 */
    uint8_t state_l = 0;
    /** 右轮驱动状态，枚举含义由 MCU 侧定义。 */
    uint8_t state_r = 0;
    /** SDK 本地收到该状态的时间戳，单位 ms。 */
    uint32_t update_ms_local = 0;
};

/** MCU 周期上报的锂电池 BMS 状态缓存。pack_voltage_mV 即底盘 FOC 母线电压。 */
struct JqrBmsStatus {
    /** BMS 在线，0=离线(RS485 超时)，非 0=在线。 */
    uint8_t online = 0;
    /** 剩余电量 RSOC，单位 %。 */
    uint8_t soc_percent = 0;
    /** 健康度 SOH，单位 %。 */
    uint8_t soh_percent = 0;
    /** 母线总电压，单位 mV，即底盘 FOC 母线电压。 */
    uint16_t pack_voltage_mV = 0;
    /** 电池电流，单位 10mA（A = 值 * 0.01），符号区分充放电。 */
    int16_t pack_current_10mA = 0;
    /** MOS 温度，单位 ℃。 */
    int16_t mos_temp_c = 0;
    /** 电芯温度 1~4，单位 ℃。 */
    std::array<int16_t, 4> cell_temp_c{{0, 0, 0, 0}};
    /** 循环次数。 */
    uint16_t cycle_count = 0;
    /** 保护状态 H 位（过充/过流/过温等），bit 含义见 BMS 协议。 */
    uint16_t protect_h = 0;
    /** 保护状态 L 位（MOS 过温等）。 */
    uint16_t protect_l = 0;
    /** SDK 本地收到该状态的时间戳，单位 ms。 */
    uint32_t update_ms_local = 0;
};

/** MCU 周期上报的头部四轴状态缓存。 */
struct JqrHeadStatus {
    /** 四轴当前位置，单位 deg，顺序为 head_pitch、neck_pitch、neck_swing、head_horizontal。 */
    std::array<float, 4> position_deg{{0, 0, 0, 0}};
    /** 四轴当前速度，单位 deg/s，顺序同 position_deg。 */
    std::array<float, 4> speed_deg_s{{0, 0, 0, 0}};
    /** 四轴状态，枚举含义由 MCU 侧定义。 */
    std::array<uint8_t, 4> state{{0, 0, 0, 0}};
    /** 四轴故障码或故障位，含义由 MCU 侧定义。 */
    std::array<uint8_t, 4> fault{{0, 0, 0, 0}};
    /** SDK 本地收到该状态的时间戳，单位 ms。 */
    uint32_t update_ms_local = 0;
};

/** MCU Aux/0x81 周期上报的药盒状态缓存。 */
struct JqrMedicineStatus {
    uint32_t uptime_ms = 0;
    MedicineState state = MedicineState::UNINIT;
    MedicineCommand target_cmd = MedicineCommand::STOP;
    MedicineCommandSource command_source = MedicineCommandSource::NONE;
    /** bit0关闭限位、bit1按钮、bit2编码器在线、bit3电流采样有效。 */
    uint8_t io_flags = 0;
    /** bit0初始化、bit1 I2C、bit2过流、bit3超时、bit4堵转、bit5 ADC、bit6状态。 */
    uint16_t fault_flags = 0;
    int16_t current_mA = 0;
    uint16_t angle_raw = 0;
    uint8_t last_cmd_seq = 0;
    MedicineResult last_result = MedicineResult::NONE;
    uint32_t update_ms_local = 0;
};

/** MCU Light/0x81 固定 18 字节状态缓存。 */
struct JqrLightStatus {
    uint32_t uptime_ms = 0;
    uint8_t last_cmd_seq = 0;
    LightControlMode control_mode = LightControlMode::OFF;
    LightScene scene = LightScene::OFF;
    LightAmbient ambient = LightAmbient::DAY;
    LightEffect effect = LightEffect::OFF;
    /** bit0初始化完成，bit1已有有效控制命令。 */
    uint8_t flags = 0;
    uint16_t r_permille = 0;
    uint16_t g_permille = 0;
    uint16_t b_permille = 0;
    uint16_t w_permille = 0;
    uint32_t update_ms_local = 0;
};

/**
 * @brief 周期目标命令最近一次 ACK 状态。
 *
 * SetHeadTarget 和 SetChassisVelocity 不同步等待 ACK，因此 SDK 将收到的目标 ACK 缓存在该
 * 结构中。业务层可用 count 判断是否收到过 ACK，用 error_count 判断是否出现过错误。
 */
struct TargetAckStatus {
    /** 最近一次 ACK 的 seq。新目标会递增 seq，周期补发复用同一 seq。 */
    uint8_t seq = 0;
    /** 最近一次 ACK 对应的命令模块 ID。 */
    uint8_t req_mod = 0;
    /** 最近一次 ACK 对应的命令消息 ID。 */
    uint8_t req_msg = 0;
    /** 最近一次 ACK 状态码，取值见 AckStatus。 */
    uint8_t status = 0;
    /** 最近一次 ACK 的扩展详情。 */
    uint16_t detail = 0;
    /** SDK 本地收到最近一次 ACK 的时间戳，单位 ms。 */
    uint32_t rx_ms = 0;
    /** 已累计收到的该类目标 ACK 数量。 */
    uint32_t count = 0;
    /** 已累计收到的非 OK 目标 ACK 数量。 */
    uint32_t error_count = 0;
};

/**
 * @brief 传感器原始状态缓存。
 *
 * 当前 MCU 侧传感器矩阵仍处于逐步接入阶段，SDK 暂时保留原始 payload。业务层应根据
 * 具体固件协议解释 data[0..len)。
 */
struct JqrSensorStatusRaw {
    /** 原始 payload 缓冲区，最多保留 64 字节。 */
    std::array<uint8_t, 64> data{};
    /** 当前有效数据长度。 */
    uint16_t len = 0;
    /** SDK 本地收到该状态的时间戳，单位 ms。 */
    uint32_t update_ms_local = 0;
};

/** MCU Sensor/0x82 上报的 IMU 数据，字段顺序与 MCU payload 完全一致。 */
struct ImuRecvDataStruct {
    float Accel_x = 0.0f;
    float Accel_y = 0.0f;
    float Accel_z = 0.0f;
    float Gyro_x = 0.0f;
    float Gyro_y = 0.0f;
    float Gyro_z = 0.0f;
    float Euler_Roll = 0.0f;
    float Euler_Pitch = 0.0f;
    float Euler_Yaw = 0.0f;
    float heading_360 = 0.0f;
    float heading_180 = 0.0f;
};

/**
 * @brief SDK 运行统计。
 *
 * 这些统计用于排查通信线程被调度延迟、ACK 超时、串口错误、自动重连和周期目标补发
 * 抖动等问题。统计值是 SDK 本地累计值，close 后对象销毁才会清零。
 */
struct JqrSdkRuntimeStats {
    /** 已成功写入 USB 的协议帧数量。 */
    uint32_t tx_frame_count = 0;
    /** 已从 USB 解析出的协议帧数量。 */
    uint32_t rx_frame_count = 0;
    /** 同步等待 ACK 超时次数。 */
    uint32_t ack_timeout_count = 0;
    /** 自动重连成功次数。 */
    uint32_t reconnect_count = 0;
    /** 串口读写或打开错误次数。 */
    uint32_t serial_error_count = 0;
    /** USB 写失败次数。 */
    uint32_t usb_tx_fail_count = 0;

    /** 心跳发送次数。 */
    uint32_t heartbeat_tx_count = 0;
    /** 头部目标总发送次数，包含新目标和周期补发。 */
    uint32_t head_target_tx_count = 0;
    /** 轮组目标总发送次数，包含新目标和周期补发。 */
    uint32_t wheel_target_tx_count = 0;
    /** 头部新内容目标发送次数。 */
    uint32_t head_new_content_send_count = 0;
    /** 头部同一目标周期补发次数。 */
    uint32_t head_periodic_send_count = 0;
    /** 轮组新内容目标发送次数。 */
    uint32_t wheel_new_content_send_count = 0;
    /** 轮组同一目标周期补发次数。 */
    uint32_t wheel_periodic_send_count = 0;

    /** 已收到 ACK 数量。 */
    uint32_t rx_ack_count = 0;
    /** 已收到非 OK ACK 数量。 */
    uint32_t ack_error_count = 0;

    /** 最近一次发送成功的本地时间戳，单位 ms。 */
    uint32_t last_tx_ms = 0;
    /** 最近一次收到任意有效帧的本地时间戳，单位 ms。 */
    uint32_t last_rx_ms = 0;
    /** 最近一次收到状态类帧的本地时间戳，单位 ms。 */
    uint32_t last_status_rx_ms = 0;

    /** TX 线程周期调度最大抖动，单位 ms。 */
    uint32_t tx_loop_max_jitter_ms = 0;
    /** SetTarget 调用后到实际写 USB 的最大延迟，单位 ms。 */
    uint32_t settarget_to_write_max_delay_ms = 0;
};

} // namespace jqr
