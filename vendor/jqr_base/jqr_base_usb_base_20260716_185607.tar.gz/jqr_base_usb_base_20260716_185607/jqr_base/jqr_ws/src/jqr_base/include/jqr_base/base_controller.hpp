#ifndef JQR_BASE__BASE_CONTROLLER_HPP_
#define JQR_BASE__BASE_CONTROLLER_HPP_

#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <sensor_msgs/msg/imu.hpp>
#include <sensor_msgs/msg/range.hpp>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <jqr_ros_msgs/msg/battery_level.hpp>
#include <std_msgs/msg/float32_multi_array.hpp>
#include <std_msgs/msg/u_int8.hpp>

#include <gpiod.hpp>
#include <atomic>

#include <jqr_ros_msgs/srv/move_mode.hpp>
#include <jqr_ros_msgs/srv/robot_tilt.hpp>
#include <jqr_ros_msgs/srv/robot_tilt_state.hpp>
#include <jqr_ros_msgs/srv/robot_rise.hpp>
#include <jqr_ros_msgs/srv/robot_rise_state.hpp>
#include <jqr_ros_msgs/srv/screen_tilt.hpp>
#include <jqr_ros_msgs/srv/screen_tilt_state.hpp>
#include <jqr_ros_msgs/srv/medicine_box_switch.hpp>
#include <jqr_ros_msgs/srv/medicine_box_state.hpp>
#include <jqr_ros_msgs/srv/medicine_box_command.hpp>
#include <jqr_ros_msgs/srv/medicine_box_status.hpp>
#include <jqr_ros_msgs/srv/laser_pointer.hpp>
#include <jqr_ros_msgs/srv/laser_pointer_state.hpp>
#include <jqr_ros_msgs/srv/clear_fault.hpp>
#include <jqr_ros_msgs/srv/status_light_scene.hpp>
#include <jqr_ros_msgs/srv/status_light_state.hpp>

#include<rgb_controller/rgb_controller_node.hpp>

//动态库
#include <jqr_sdk_lib/include/SdkController.h>
#include <jqr_sdk_lib/include/MotorDataRefresh.h>
namespace jqr_base
{

// 常量定义
constexpr double DEG_TO_RAD = M_PI / 180.0;
constexpr double RAD_TO_DEG = 180.0 / M_PI;
constexpr double GRAVITY = 9.7947;

struct RobotState {
  uint8_t medicine_box_state;     // 0表示关闭状态，1表示打开状态 ，2表示关闭中，3表示打开中
  double screen_tilt_state;    // float64对应double
  bool robot_rise_state;       // true升起 false降下
  double robot_tilt_state;
  double battery_power_state;
  bool laser_pointer_state;
  float head_pitch_angle;      // 头部俯仰角度，单位：度，最上方为零度，范围 0 - 60°
  float head_yaw_angle;        // 头部偏航角度，单位：度，最右边为零度，范围 0 - 340°

  RobotState(){
    medicine_box_state = 0;
    screen_tilt_state = 0.0;
    robot_rise_state = false;
    robot_tilt_state = 0.0;
    battery_power_state = 0.0;
    laser_pointer_state = false;
    head_pitch_angle = 0.0f;
    head_yaw_angle = 0.0f;
  }
};


struct MoterControlStartTime {
  std::chrono::steady_clock::time_point medicine_operation_start_time; 
  std::chrono::steady_clock::time_point screen_tilt_operation_start_time; 
  std::chrono::steady_clock::time_point robot_rise_operation_start_time; 
  std::chrono::steady_clock::time_point robot_tilt_operation_start_time;     

  MoterControlStartTime(){
    medicine_operation_start_time = std::chrono::steady_clock::now();
    screen_tilt_operation_start_time = std::chrono::steady_clock::now();
    robot_rise_operation_start_time = std::chrono::steady_clock::now();
    robot_tilt_operation_start_time = std::chrono::steady_clock::now();
  } 
};


class BaseController : public rclcpp::Node
{
public:
  explicit BaseController(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());
  virtual ~BaseController() = default;

private:

  std::unique_ptr<SdkControl> sdk_controller_;

  std::unique_ptr<RGBControllerNode> rgb_controller_;

  static const int LASER_PIN = 18;  // 物理引脚18
  std::unique_ptr<gpiod::chip> chip;
  gpiod::line line;

  // State variabless
  double x_ = 0.0;
  double y_ = 0.0;
  double theta_ = 0.0;
  rclcpp::Time last_odom_update_;
  double target_linear_vel_ = 0.0;
  double target_angular_vel_ = 0.0;
  double max_linear_vel_ = 0.5;
  double max_angular_vel_ = 1.5708;  // 90°/s
  double linear_vel = 0.0;
  double angular_vel = 0.0;

  double robot_tilt_min_ = -5.0;
  double robot_tilt_max_ = 5.0;
  double screen_tilt_min_ = -28.0;
  double screen_tilt_max_ = 7.0;

  bool first_odom_update = true;

  bool first_velocity_data_ = true;
  double last_linear_vel_ = 0.0;
  double last_angular_vel_ = 0.0;

  std::atomic<uint8_t> stall_flag_{0xFF};  // 堵转故障标志，0xFF哨兵值保证首次读取必触发发布


  //std::chrono::steady_clock::time_point medicine_operation_start_time = std::chrono::steady_clock::now();

  RobotState robot_state_;
  MoterControlStartTime motor_control_start_time_;
  std::mutex robot_state_mutex_;
  
  // Parameters
  std::string odom_frame_id_;
  std::string base_frame_id_;
  std::string imu_frame_id_;
  std::string us_frame_id_;   //us为ultrasonic的简写，表示超声波

  // rclcpp::CallbackGroup::SharedPtr service_callback_group_;
  rclcpp::CallbackGroup::SharedPtr update_robot_state_callback_group_;
  rclcpp::CallbackGroup::SharedPtr laser_pointer_callback_group_;
  rclcpp::CallbackGroup::SharedPtr medicine_box_callback_group_;
  rclcpp::CallbackGroup::SharedPtr screen_tilt_callback_group_;
  rclcpp::CallbackGroup::SharedPtr robot_tilt_rise_callback_group_;
  rclcpp::CallbackGroup::SharedPtr cmd_vel_callback_group_;
  rclcpp::CallbackGroup::SharedPtr motor_control_callback_group_;
  rclcpp::CallbackGroup::SharedPtr head_motor_callback_group_;
  rclcpp::CallbackGroup::SharedPtr clear_fault_callback_group_;
  rclcpp::CallbackGroup::SharedPtr status_light_callback_group_;

  // ros2 subscribers
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_sub_;
  rclcpp::Subscription<std_msgs::msg::Float32MultiArray>::SharedPtr motor_control_sub_;
  rclcpp::Subscription<std_msgs::msg::Float32MultiArray>::SharedPtr head_motor_speed_control_sub_;
  rclcpp::Subscription<std_msgs::msg::Float32MultiArray>::SharedPtr four_motor_position_control_sub_;

  // ROS2 publishers
  rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr odom_pub_;
  rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_pub_;
  rclcpp::Publisher<sensor_msgs::msg::Range>::SharedPtr us_pub_front_;
  rclcpp::Publisher<sensor_msgs::msg::Range>::SharedPtr us_pub_back_;
  rclcpp::Publisher<jqr_ros_msgs::msg::BatteryLevel>::SharedPtr battery_level_pub_;
  rclcpp::Publisher<std_msgs::msg::Float32MultiArray>::SharedPtr motor_state_pub_;  //add1218
  rclcpp::Publisher<std_msgs::msg::Float32MultiArray>::SharedPtr head_motor_angle_feedback_pub_;
  rclcpp::Publisher<std_msgs::msg::Float32MultiArray>::SharedPtr four_motor_position_feedback_pub_;
  rclcpp::Publisher<std_msgs::msg::UInt8>::SharedPtr stall_flag_pub_;

  // ROS2 services
  rclcpp::Service<jqr_ros_msgs::srv::MoveMode>::SharedPtr move_mode_service_;
  rclcpp::Service<jqr_ros_msgs::srv::RobotTilt>::SharedPtr robot_tilt_service_;
  rclcpp::Service<jqr_ros_msgs::srv::RobotTiltState>::SharedPtr robot_tilt_state_service_;
  rclcpp::Service<jqr_ros_msgs::srv::RobotRise>::SharedPtr robot_rise_service_;
  rclcpp::Service<jqr_ros_msgs::srv::RobotRiseState>::SharedPtr robot_rise_state_service_;
  rclcpp::Service<jqr_ros_msgs::srv::ScreenTilt>::SharedPtr screen_tilt_service_;
  rclcpp::Service<jqr_ros_msgs::srv::ScreenTiltState>::SharedPtr screen_tilt_state_service_;
  rclcpp::Service<jqr_ros_msgs::srv::MedicineBoxSwitch>::SharedPtr medicine_box_switch_service_;
  rclcpp::Service<jqr_ros_msgs::srv::MedicineBoxState>::SharedPtr medicine_box_state_service_;
  rclcpp::Service<jqr_ros_msgs::srv::MedicineBoxCommand>::SharedPtr medicine_box_command_service_;
  rclcpp::Service<jqr_ros_msgs::srv::MedicineBoxStatus>::SharedPtr medicine_box_status_service_;
  rclcpp::Service<jqr_ros_msgs::srv::LaserPointer>::SharedPtr laser_pointer_service_;
  rclcpp::Service<jqr_ros_msgs::srv::LaserPointerState>::SharedPtr laser_pointer_state_service_;
  rclcpp::Service<jqr_ros_msgs::srv::ClearFault>::SharedPtr clear_fault_service_;
  rclcpp::Service<jqr_ros_msgs::srv::StatusLightScene>::SharedPtr status_light_scene_service_;
  rclcpp::Service<jqr_ros_msgs::srv::StatusLightState>::SharedPtr status_light_state_service_;

  
  // Timers
  //rclcpp::TimerBase::SharedPtr control_timer_;
  rclcpp::TimerBase::SharedPtr update_robot_state_timer_;
  rclcpp::TimerBase::SharedPtr odom_timer_;
  rclcpp::TimerBase::SharedPtr imu_timer_;
  rclcpp::TimerBase::SharedPtr us_timer_;
  rclcpp::TimerBase::SharedPtr battery_level_timer_;
  rclcpp::TimerBase::SharedPtr get_la_timer_;
  rclcpp::TimerBase::SharedPtr motor_state_timer_;  //add1218
  rclcpp::TimerBase::SharedPtr head_motor_angle_feedback_timer_;
  rclcpp::TimerBase::SharedPtr four_motor_position_feedback_timer_;
  rclcpp::TimerBase::SharedPtr stall_flag_timer_;


  // Callbacks
  void UpdateRobotState();
  void OdomPublishLoop();
  void ImuPublishLoop();
  void UsPublishLoop();
  void BatteryLevelPublish();
  void TimerMotorStatePublish();
  void GetVelocityDataLoop();  // 重命名自 aa()
  void HeadMotorAngleFeedbackPublish();
  void StallFlagPublish();

  bool isRobotRisen();
  bool autoRiseRobot(int duration = 0);
  bool forceTiltToZero(int duration = 0);

  // Utility functions
  void MotorStatePublish();
  void UpdateOdometry(double linear_vel, double angular_vel, double dt);
  void PublishOdometry(double linear_vel, double angular_vel);
  
  void CmdVelCallback(const geometry_msgs::msg::Twist::SharedPtr msg);
  void SendVelocitiesToMCU(double linear_vel, double angular_vel);
  void MotorControlCallback(const std_msgs::msg::Float32MultiArray::SharedPtr msg);
  void HeadMotorSpeedControlCallback(const std_msgs::msg::Float32MultiArray::SharedPtr msg);
  void FourMotorPositionControlCallback(const std_msgs::msg::Float32MultiArray::SharedPtr msg);
  void FourMotorPositionFeedbackPublish();

  // Service callbacks
  void MoveModeCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::MoveMode::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::MoveMode::Response> response);

  void RobotTiltCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::RobotTilt::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::RobotTilt::Response> response);

  void RobotTiltStateCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::RobotTiltState::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::RobotTiltState::Response> response);
  
  void RobotRiseCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::RobotRise::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::RobotRise::Response> response);

  void RobotRiseStateCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::RobotRiseState::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::RobotRiseState::Response> response);

  void ScreenTiltCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::ScreenTilt::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::ScreenTilt::Response> response);

  void ScreenTiltStateCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::ScreenTiltState::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::ScreenTiltState::Response> response);

  void MedicineBoxSwitchCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxSwitch::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxSwitch::Response> response);

  void MedicineBoxStateCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxState::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxState::Response> response);

  void MedicineBoxCommandCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxCommand::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxCommand::Response> response);

  void MedicineBoxStatusCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxStatus::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::MedicineBoxStatus::Response> response);
  
  void LaserPointerCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::LaserPointer::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::LaserPointer::Response> response);

  void LaserPointerStateCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::LaserPointerState::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::LaserPointerState::Response> response);

  void ClearFaultCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::ClearFault::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::ClearFault::Response> response);

  void StatusLightSceneCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::StatusLightScene::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::StatusLightScene::Response> response);

  void StatusLightStateCallback(
    const std::shared_ptr<jqr_ros_msgs::srv::StatusLightState::Request> request,
    std::shared_ptr<jqr_ros_msgs::srv::StatusLightState::Response> response);

};

}  // namespace jqr_base

#endif  // JQR_BASE__BASE_CONTROLLER_HPP_
