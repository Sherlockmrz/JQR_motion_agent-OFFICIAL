//
// SdkController.cpp - 适配 JQR_USB_SDK_CPP (jqr::JqrSdkController) 的桥接实现
//
// 背景：底层通信协议由旧自定义协议（0xAA 0x55 帧）切换为厂商正式发布的
//       JQR USB SDK（0xFA 0xFA 帧 + CRC8，mod_id/msg_id）。本文件保持
//       SdkController.h 公开接口签名与 MotorDataRefresh.h 数据结构完全不变，
//       只把每个公开方法桥接到新 SDK。
//
// 协议覆盖范围（v0.3.0-comm-alpha）：
//   - 底盘整机速度（SetChassisVelocityMm）
//   - 头部 4 轴位置目标 + 状态（SetHeadTarget / GetHeadStatus）
//   - 系统使能 / 版本 / 状态
//   - IMU 专用上报（Sensor/0x82，GetImuData）
//   - 锂电池 BMS 状态（MOD_BMS/0x81，GetBmsStatus → SOC）
//   - 药盒控制和状态（MOD_AUX/0x01、0x81）
//   - 产品状态灯场景和状态（MOD_LIGHT/0x02、0x81）
//   - 传感器原始 blob（布局未定义，暂不解析）
//
// 新协议尚未覆盖、暂以桩函数处理（一次性 WARN，set 空操作 / get 返回 0）：
//   机身升降、机身俯仰、屏幕俯仰、头部堵转标志、超声波、
//   Demo3 头部速度控制 / 角度读取。
//   待厂商补 Aux/Sensor 协议后再接。
//
#include "SdkController.h"
#include "MotorDataRefresh.h"

#include "JqrSdkController.h"

#include <array>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <mutex>
#include <string>
#include <thread>

namespace {

// 一次性告警：某个尚未接入新协议的接口被调用时，只打印一次，避免高频刷屏。
#define WARN_ONCE(tag)                                                        \
    do {                                                                      \
        static std::atomic<bool> warned_##tag{false};                         \
        bool expected = false;                                                \
        if (warned_##tag.compare_exchange_strong(expected, true)) {           \
            std::fprintf(stderr,                                              \
                "[SdkControl] WARN: '" #tag "' 在当前 USB SDK 协议"           \
                "(v0.3.0-comm-alpha) 中尚未实现，按桩函数处理。\n");          \
        }                                                                     \
    } while (0)

inline float clampf(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

// PLACEHOLDER_IMPL
} // namespace

// ───── PIMPL：持有新 SDK 句柄与头部 4 轴目标缓存 ────────────
class SdkControl::Impl {
public:
    jqr::JqrSdkController sdk;

    // 头部 4 轴目标缓存，顺序与协议 target_deg[4] 一致：
    // [0]=head_pitch [1]=neck_pitch [2]=neck_swing(摇摆) [3]=head_horizontal(水平)
    std::mutex head_mtx;
    std::array<float, 4> head_target_deg{{0.0f, 0.0f, 0.0f, 0.0f}};
    float head_speed_limit_deg_s = 30.0f;

    // 把当前缓存的 4 轴目标整帧下发。
    bool flushHeadTarget() {
        std::array<float, 4> t;
        float spd;
        {
            std::lock_guard<std::mutex> lk(head_mtx);
            t = head_target_deg;
            spd = head_speed_limit_deg_s;
        }
        return sdk.SetHeadTarget(t[0], t[1], t[2], t[3], spd);
    }

    // ───── 硬件急停恢复监控线程 ─────────────────────────────
    //
    // 厂商新增硬件急停按钮：按下后 MCU 失能（system_enable=0、estop=1），返回
    // ACK_DISABLED 拒绝一切运动命令。恢复流程是：人工先按硬件复位键（MCU 清 estop=0，
    // 但 system_enable 仍为 0，不会自动恢复），随后**上位机必须再发一次
    // SetSystemEnable(true)** 才能重新接收指令。
    //
    // MCU 周期上报 SystemStatus（含 estop / system_enable），SDK 已缓存，可查询。
    // 本线程轮询该状态，识别“急停已物理复位但系统仍未使能”这一边沿，自动补发使能，
    // 把厂商要求的“硬件复位后再次使能”动作做成 SDK 内部自愈，业务层无需感知。
    //
    // 放在 PIMPL 内部，不新增任何 SdkControl 公开符号，ABI 与旧 .so 保持一致。
    std::thread       estop_thr_;
    std::atomic<bool> estop_running_{false};
    bool              prev_estop_ = false;  // 仅监控线程访问

    void startEstopRecovery() {
        estop_running_.store(true);
        estop_thr_ = std::thread([this]() { estopRecoveryLoop(); });
    }

    void stopEstopRecovery() {
        estop_running_.store(false);
        if (estop_thr_.joinable()) estop_thr_.join();
    }

    void estopRecoveryLoop() {
        using namespace std::chrono_literals;
        while (estop_running_.load()) {
            std::this_thread::sleep_for(100ms);
            if (!estop_running_.load()) break;

            jqr::JqrSystemStatus st;
            if (!sdk.GetSystemStatus(st)) continue;   // 尚无状态缓存
            if (!sdk.GetMcuConnectStatus()) continue; // MCU 离线时不操作

            const bool estop_now = (st.estop != 0);

            // 急停被按下 → 记录边沿，打印一次提示。
            if (estop_now && !prev_estop_) {
                std::fprintf(stderr,
                    "[SdkControl] 硬件急停已触发，MCU 失能并拒绝运动命令；"
                    "请按硬件复位键后等待自动重新使能。\n");
            }

            // 急停已物理复位（estop 回 0）但系统仍未使能 → 补发一次使能恢复。
            // 这正是厂商要求的“硬件复位后再次 SetSystemEnable(true)”。
            if (!estop_now && st.system_enable == 0) {
                if (impl_reenable()) {
                    std::fprintf(stderr,
                        "[SdkControl] 检测到急停已复位且系统未使能，已自动重新使能。\n");
                }
            }

            prev_estop_ = estop_now;
        }
    }

    // 重新使能；返回 true 表示 MCU 回 OK ACK。
    bool impl_reenable() {
        return sdk.SetSystemEnable(true);
    }
};

// ───── 构造 / 析构 ─────────────────────────────────────
SdkControl::SdkControl() : impl_(std::make_unique<Impl>()) {}
SdkControl::~SdkControl() {
    // 先停急停恢复线程，再析构 SDK（thread 持有 impl_ 裸指针）。
    if (impl_) impl_->stopEstopRecovery();
}

// ───── 初始化 ──────────────────────────────────────────
bool SdkControl::init() {
    jqr::JqrSdkConfig cfg;
    // 设备节点可由环境变量覆盖，默认 /dev/ttyACM0。
    if (const char* dev = std::getenv("JQR_USB_DEVICE")) {
        if (dev[0] != '\0') cfg.device = dev;
    }
    if (const char* baud = std::getenv("JQR_BAUDRATE")) {
        int b = std::atoi(baud);
        if (b > 0) cfg.baudrate = b;
    }

    // 底盘速度缓存死手保护采用 wheel_target_cache_expire_ms=200（见 JqrSdkConfig.h）：
    // 上游以 10Hz（100ms 周期）发布 /cmd_vel，base_controller 每帧转发刷新缓存。
    // expire 必须显著大于 cmd_vel 周期，否则每个发布间隔尾部都会误判失联、停止补发，
    // 导致 MCU 死手超时——这正是首帧到第二帧丢帧问题的根因。200ms 给 10Hz 留一倍裕量。
    // 一旦上游真的停发或失联超过 200ms，SDK 停止补发、MCU 再按 wheel_target_timeout_ms
    // 清零停车。这是移动底盘期望的安全行为，不要覆盖为 0。

    if (!impl_->sdk.init(cfg)) {
        std::fprintf(stderr, "[SdkControl] init 失败：无法打开 USB CDC 设备 %s\n",
                     cfg.device.c_str());
        return false;
    }

    // 新协议要求运动命令前先 SystemEnable，否则 MCU 返回 ACK_DISABLED。
    // 旧协议无显式使能，为保持上层行为，这里初始化即使能。
    if (!impl_->sdk.SetSystemEnable(true)) {
        std::fprintf(stderr,
            "[SdkControl] WARN: SetSystemEnable(true) 未收到 OK ACK，"
            "MCU 可能尚未就绪，运动命令在使能前会被拒绝。\n");
    }

    // 启动硬件急停恢复监控：急停按下后 MCU 失能，人工按硬件复位键清 estop 后，
    // 由该线程自动补发 SetSystemEnable(true) 恢复（厂商要求的恢复流程）。
    impl_->startEstopRecovery();
    return true;
}

bool SdkControl::GetMcuConnectStatus(void) {
    return impl_->sdk.GetMcuConnectStatus();
}

bool SdkControl::ClearFault(uint32_t FaultMask) {
    return impl_->sdk.ClearFault(FaultMask);
}

// ───── 整机速度 ────────────────────────────────────────
// 旧单位：linear 0.01 m/s（=10 mm/s），angular 0.1 deg/s。
// 新接口单位：mm/s 与 mdeg/s。换算：mm/s = old*10，mdeg/s = old*100。
bool SdkControl::SetRobotVelocities(int32_t linear_vel, int32_t angular_vel) {
    int32_t linear_mm_s    = linear_vel * 10;
    int32_t angular_mdeg_s = angular_vel * 100;
    return impl_->sdk.SetChassisVelocityMm(linear_mm_s, angular_mdeg_s);
}

bool SdkControl::GetRobotVelocities(std::vector<HubMotorRecvData>& arry) {
    jqr::JqrWheelStatus ws;
    bool ok = impl_->sdk.GetWheelStatus(ws);
    HubMotorRecvData d;
    // 反向换算回旧单位，供上层 base_controller 现有 /100、/10 逻辑使用。
    d.ActualLinearVel  = static_cast<float>(ws.linear_mm_s) / 10.0f;
    d.ActualAngularVel = static_cast<float>(ws.angular_mdeg_s) / 100.0f;
    arry.clear();
    arry.push_back(d);
    return ok && impl_->sdk.GetMcuConnectStatus();
}

// ───── 四自由度头颈位置控制（核心映射）────────────────────
// 旧接口（base_controller 调用）-> 新协议 target_deg[4] 映射，依据协议方向定义：
//   SetHeadPitchTargetPos -> axis0 head_pitch       (-25~25°)
//   SetNeckPitchTargetPos -> axis1 neck_pitch       (-30~30°)
//   SetNeckYawTargetPos(摇摆) -> axis2 neck_swing    (-30~30°)
//   SetNeckRollTargetPos(旋转) -> axis3 head_horizontal (-170~170°)
// 单轴 set 只更新缓存对应轴，再整帧下发，避免其他轴被写 0。
bool SdkControl::SetHeadPitchTargetPos(float HeadPitchTargetPos) {
    {
        std::lock_guard<std::mutex> lk(impl_->head_mtx);
        impl_->head_target_deg[0] = clampf(HeadPitchTargetPos, -25.0f, 25.0f);
    }
    return impl_->flushHeadTarget();
}
bool SdkControl::SetNeckPitchTargetPos(float NeckPitchTargetPos) {
    {
        std::lock_guard<std::mutex> lk(impl_->head_mtx);
        impl_->head_target_deg[1] = clampf(NeckPitchTargetPos, -30.0f, 30.0f);
    }
    return impl_->flushHeadTarget();
}
bool SdkControl::SetNeckYawTargetPos(float NeckYawTargetPos) {
    {
        std::lock_guard<std::mutex> lk(impl_->head_mtx);
        impl_->head_target_deg[2] = clampf(NeckYawTargetPos, -30.0f, 30.0f);
    }
    return impl_->flushHeadTarget();
}
bool SdkControl::SetNeckRollTargetPos(float NeckRollTargetPos) {
    {
        std::lock_guard<std::mutex> lk(impl_->head_mtx);
        impl_->head_target_deg[3] = clampf(NeckRollTargetPos, -170.0f, 170.0f);
    }
    return impl_->flushHeadTarget();
}
bool SdkControl::GetHeadPitchTargetPos(float& HeadPitchActualPos) {
    jqr::JqrHeadStatus hs;
    bool ok = impl_->sdk.GetHeadStatus(hs);
    HeadPitchActualPos = hs.position_deg[0];
    return ok && impl_->sdk.GetMcuConnectStatus();
}
bool SdkControl::GetNeckPitchTargetPos(float& NeckPitchActualPos) {
    jqr::JqrHeadStatus hs;
    bool ok = impl_->sdk.GetHeadStatus(hs);
    NeckPitchActualPos = hs.position_deg[1];
    return ok && impl_->sdk.GetMcuConnectStatus();
}
bool SdkControl::GetNeckYawTargetPos(float& NeckYawActualPos) {
    jqr::JqrHeadStatus hs;
    bool ok = impl_->sdk.GetHeadStatus(hs);
    NeckYawActualPos = hs.position_deg[2];
    return ok && impl_->sdk.GetMcuConnectStatus();
}
bool SdkControl::GetNeckRollTargetPos(float& NeckRollActualPos) {
    jqr::JqrHeadStatus hs;
    bool ok = impl_->sdk.GetHeadStatus(hs);
    NeckRollActualPos = hs.position_deg[3];
    return ok && impl_->sdk.GetMcuConnectStatus();
}

// ═══════════════════════════════════════════════════════════
// 以下功能新协议(v0.3.0-comm-alpha)尚未覆盖，桩函数处理。
// 待厂商补 Aux / Sensor 子协议后再桥接。
// ═══════════════════════════════════════════════════════════

// ───── IMU（Sensor/0x82 专用上报）─────────────────────────
// 新版 SDK 已解析 MCU 的 IMU 上报（11 个 float32），字段顺序与桥接层
// ImuRecvDataStruct（MotorDataRefresh.h）完全一致，逐字段拷贝即可。
bool SdkControl::GetImuData(std::vector<ImuRecvDataStruct>& arry) {
    jqr::ImuRecvDataStruct s;
    bool ok = impl_->sdk.GetImuData(s);
    ImuRecvDataStruct d;
    d.Accel_x     = s.Accel_x;
    d.Accel_y     = s.Accel_y;
    d.Accel_z     = s.Accel_z;
    d.Gyro_x      = s.Gyro_x;
    d.Gyro_y      = s.Gyro_y;
    d.Gyro_z      = s.Gyro_z;
    d.Euler_Roll  = s.Euler_Roll;
    d.Euler_Pitch = s.Euler_Pitch;
    d.Euler_Yaw   = s.Euler_Yaw;
    d.heading_360 = s.heading_360;
    d.heading_180 = s.heading_180;
    arry.clear();
    arry.push_back(d);
    return ok && impl_->sdk.GetMcuConnectStatus();
}

// ───── 药盒 ────────────────────────────────────────────
bool SdkControl::SetMedicineBoxSwitch(uint8_t TargetCmd, uint8_t /*SpeedGear*/) {
    const auto command = TargetCmd == 0 ? jqr::MedicineCommand::CLOSE
                                        : jqr::MedicineCommand::OPEN;
    return impl_->sdk.SetMedicineBox(command);
}

bool SdkControl::SetMedicineBoxCommand(uint8_t Command, uint8_t& CommandSeq) {
    if (Command > static_cast<uint8_t>(jqr::MedicineCommand::CLOSE)) {
        CommandSeq = 0;
        return false;
    }
    return impl_->sdk.SetMedicineBox(static_cast<jqr::MedicineCommand>(Command), CommandSeq);
}

bool SdkControl::GetMedicineBoxStatus(uint8_t& Status) {
    jqr::JqrMedicineStatus status;
    if (!impl_->sdk.GetMedicineStatus(status) || !impl_->sdk.GetMcuConnectStatus()) {
        return false;
    }

    switch (status.state) {
        case jqr::MedicineState::CLOSED:
            Status = 0;
            break;
        case jqr::MedicineState::OPEN:
            Status = 1;
            break;
        default:
            Status = 2;
            break;
    }
    return true;
}

bool SdkControl::GetMedicineBoxStatusDetail(MedicineBoxStatusData& Status) {
    jqr::JqrMedicineStatus status;
    if (!impl_->sdk.GetMedicineStatus(status) || !impl_->sdk.GetMcuConnectStatus()) {
        return false;
    }
    Status.uptime_ms = status.uptime_ms;
    Status.state = static_cast<uint8_t>(status.state);
    Status.target_cmd = static_cast<uint8_t>(status.target_cmd);
    Status.command_source = static_cast<uint8_t>(status.command_source);
    Status.io_flags = status.io_flags;
    Status.fault_flags = status.fault_flags;
    Status.current_mA = status.current_mA;
    Status.angle_raw = status.angle_raw;
    Status.last_cmd_seq = status.last_cmd_seq;
    Status.last_result = static_cast<uint8_t>(status.last_result);
    return true;
}

bool SdkControl::SetStatusLightScene(uint8_t Scene, uint8_t Ambient, bool RestartPattern) {
    if (Scene > static_cast<uint8_t>(jqr::LightScene::PAIRING) ||
        Ambient > static_cast<uint8_t>(jqr::LightAmbient::NIGHT)) {
        return false;
    }
    return impl_->sdk.SetLightScene(static_cast<jqr::LightScene>(Scene),
                                    static_cast<jqr::LightAmbient>(Ambient),
                                    RestartPattern);
}

bool SdkControl::GetStatusLightStatus(StatusLightData& Status) {
    jqr::JqrLightStatus status;
    if (!impl_->sdk.GetLightStatus(status) || !impl_->sdk.GetMcuConnectStatus()) {
        return false;
    }
    Status.uptime_ms = status.uptime_ms;
    Status.last_cmd_seq = status.last_cmd_seq;
    Status.control_mode = static_cast<uint8_t>(status.control_mode);
    Status.scene = static_cast<uint8_t>(status.scene);
    Status.ambient = static_cast<uint8_t>(status.ambient);
    Status.effect = static_cast<uint8_t>(status.effect);
    Status.flags = status.flags;
    Status.r_permille = status.r_permille;
    Status.g_permille = status.g_permille;
    Status.b_permille = status.b_permille;
    Status.w_permille = status.w_permille;
    return true;
}

// ───── 机身升降 ────────────────────────────────────────
bool SdkControl::FuselageLiftControl(uint8_t /*TargetCmd*/) {
    WARN_ONCE(FuselageLiftControl);
    return false;
}
bool SdkControl::GetFuselageLiftStatus(uint8_t& FuselageLiftStatus) {
    WARN_ONCE(GetFuselageLiftStatus);
    FuselageLiftStatus = 0;
    return false;
}

// ───── 机身俯仰 ────────────────────────────────────────
bool SdkControl::SetFuselagePitchPos(int32_t /*FuselagePitchTargetPos*/) {
    WARN_ONCE(SetFuselagePitchPos);
    return false;
}
bool SdkControl::GetFuselagePitchPos(int32_t& FuselagePitchActualPos) {
    WARN_ONCE(GetFuselagePitchPos);
    FuselagePitchActualPos = 0;
    return false;
}

// ───── 屏幕俯仰 ────────────────────────────────────────
bool SdkControl::SetScreenTiltPos(float /*ScreenTiltTargetPos*/) {
    WARN_ONCE(SetScreenTiltPos);
    return false;
}
bool SdkControl::GetScreenTiltPos(float& ScreenTiltActualPos) {
    WARN_ONCE(GetScreenTiltPos);
    ScreenTiltActualPos = 0.0f;
    return false;
}

// ───── 超声波 ──────────────────────────────────────────
bool SdkControl::GetUltrasonicData(std::vector<UltrasonicRecvData>& arry) {
    WARN_ONCE(GetUltrasonicData);
    arry.clear();
    arry.push_back(UltrasonicRecvData{});
    return false;
}

// ───── 电池电量（BMS/0x81 上报）────────────────────────
// 新版 SDK 已解析锂电池 BMS 状态。旧接口只要 SOC 百分比，取 soc_percent。
// 说明：base_controller 的电池发布逻辑目前整体注释，本接口接通后该能力在
// SDK/桥接 API 层已真实可用，是否对外发布 ROS 话题由上层决定。
bool SdkControl::GetBmsSoc(uint8_t& BmsSoc) {
    jqr::JqrBmsStatus bs;
    bool ok = impl_->sdk.GetBmsStatus(bs);
    BmsSoc = bs.soc_percent;
    return ok && impl_->sdk.GetMcuConnectStatus();
}

// ───── 整机控制聚合接口 ────────────────────────────────
bool SdkControl::SetAllMotorCmd(AllMotorCmd /*AllCmd*/) {
    WARN_ONCE(SetAllMotorCmd);
    return false;
}
bool SdkControl::GetAllMotorStatus(std::vector<AllMotorStatus>& arry) {
    WARN_ONCE(GetAllMotorStatus);
    arry.clear();
    arry.push_back(AllMotorStatus{});
    return false;
}

// ───── Demo3 头部速度接口（新协议为位置模式，无速度业务接口）─────
bool SdkControl::SetHeadPitchSpeed(float /*HeadPitchSpeed*/) {
    WARN_ONCE(SetHeadPitchSpeed);
    return false;
}
bool SdkControl::SetHeadYawSpeed(float /*HeadYawSpeed*/) {
    WARN_ONCE(SetHeadYawSpeed);
    return false;
}
// Demo3 头部角度读取：新协议头部为 float° 4 轴，旧接口要求 0.1° 整数。
// head_pitch 取 axis0，head_yaw 取 axis3(头部水平)，做单位换算后返回。
bool SdkControl::GetHeadPitchAngle(int32_t& HeadPitchAngle) {
    WARN_ONCE(GetHeadPitchAngle);
    jqr::JqrHeadStatus hs;
    bool ok = impl_->sdk.GetHeadStatus(hs);
    HeadPitchAngle = static_cast<int32_t>(hs.position_deg[0] * 10.0f);  // °->0.1°
    return ok && impl_->sdk.GetMcuConnectStatus();
}
bool SdkControl::GetHeadYawAngle(int32_t& HeadYawAngle) {
    WARN_ONCE(GetHeadYawAngle);
    jqr::JqrHeadStatus hs;
    bool ok = impl_->sdk.GetHeadStatus(hs);
    HeadYawAngle = static_cast<int32_t>(hs.position_deg[3] * 10.0f);  // °->0.1°
    return ok && impl_->sdk.GetMcuConnectStatus();
}

// ───── 头部堵转标志（新协议未单独上报）──────────────────
bool SdkControl::GetStallFlag(uint8_t& StallFlag) {
    WARN_ONCE(GetStallFlag);
    StallFlag = 0;
    return false;
}
