#!/usr/bin/env bash
#
# build_sdk_so.sh - 编译 libSdkController_<arch>.so（桥接 JQR_USB_SDK_CPP）
#
# 用法：
#   ./build_sdk_so.sh            # 本机架构编译，产物覆盖 lib/sdk_lib/
#
# 设计：编译厂商 JQR USB SDK 源码（../src/）+ SdkController.cpp 桥接，
#       产出与旧 .so 同名同接口的动态库，jqr_base 的 CMakeLists 不改。
#
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"   # .../jqr_sdk_lib/include
LIBDIR="$HERE/../lib/sdk_lib"
ARCH="$(uname -m)"
OUT="$LIBDIR/libSdkController_${ARCH}.so"

mkdir -p "$LIBDIR"

SRCS=(
  "$HERE/SdkController.cpp"
  "$HERE/../src/JqrProtocol.cpp"
  "$HERE/../src/JqrSerialPort.cpp"
  "$HERE/../src/JqrThreadUtil.cpp"
  "$HERE/../src/JqrUsbDataRefresh.cpp"
  "$HERE/../src/JqrSdkController.cpp"
)

echo "[build_sdk_so] arch=$ARCH"
echo "[build_sdk_so] out=$OUT"

g++ -std=c++17 -O2 -fPIC -shared -Wall \
  -I"$HERE" \
  "${SRCS[@]}" \
  -lpthread \
  -o "$OUT"

echo "[build_sdk_so] OK"
ls -la "$OUT"
file "$OUT"
