#pragma once

#include <string>
#include "JqrUsbDataRefresh.h"
#include "JqrSdkVersion.h"

namespace jqr {

/**
 * @brief 上位机业务层推荐使用的 SDK 门面类。
 *
 * 业务层通常只需要持有一个 JqrSdkController 对象，通过本类完成 USB CDC
 * 初始化、系统使能、运动目标下发和状态读取。串口打开、协议组帧、收发线程、
 * 周期补发、ACK 匹配和断线重连都封装在内部的 JqrUsbDataRefresh 中。
 *
 * 重要语义：
 * - SetSystemEnable、ClearFault、GetVersion、StopWheel 是同步等待类接口。
 * - SetHeadTarget、SetHeadAxisTarget、SetChassisVelocity 是高响应目标缓存接口，返回 true
 *   只表示 SDK 已接收目标并唤醒发送线程，不表示 MCU 已执行完成或机构已到位。
 * - 周期目标的 MCU ACK 由接收线程异步更新，可通过 GetLastWheelTargetAck 或
 *   GetLastHeadTargetAck 查询最近一次目标应答。
 * - GetXXXStatus 返回 SDK 本地缓存的最新状态，业务层可结合 update_ms_local 判断
 *   数据新鲜度。
 */
class JqrSdkController {
public:
    /**
     * @brief 使用设备路径和波特率初始化 SDK。
     *
     * 成功后会打开 Linux USB CDC ACM 串口，并启动 RX、TX、Watchdog 三个后台线程。
     * device 默认是 /dev/ttyACM0，baudrate 默认 115200。CDC 设备本质仍按串口方式访问，
     * 这里不直接使用 libusb。
     *
     * @param device USB CDC 设备节点，例如 /dev/ttyACM0。
     * @param baudrate 串口波特率，需与 MCU 侧 CDC/串口配置保持一致。
     * @return true 初始化成功；false 串口打开、配置或线程启动前置条件失败。
     */
    bool init(const std::string& device = "/dev/ttyACM0", int baudrate = 115200);

    /**
     * @brief 使用完整配置初始化 SDK。
     *
     * 适合业务层需要调整通信周期、运动目标超时、断线重连或实时线程参数的场景。
     * 配置中的高响应目标周期会影响目标补发频率，但目标内容变化时仍会优先唤醒 TX
     * 线程发送。
     *
     * @param cfg SDK 总配置，详见 JqrSdkConfig。
     * @return true 初始化成功；false 串口打开或配置失败。
     */
    bool init(const JqrSdkConfig& cfg);

    /**
     * @brief 停止 SDK 并释放 USB CDC 资源。
     *
     * 会通知后台线程退出，等待线程 join，然后关闭串口。可以重复调用；如果 SDK
     * 未运行，函数会直接返回。
     */
    void close();

    /**
     * @brief 查询 MCU 当前是否在线。
     *
     * 在线状态由接收线程根据 MCU 上报的系统状态和 Watchdog 超时维护。刚初始化但尚未
     * 收到状态帧时可能返回 false。
     *
     * @return true MCU 最近有有效状态上报且 usb_online 有效；false 未连接、状态超时或
     * 尚未收到状态。
     */
    bool GetMcuConnectStatus() const;

    /**
     * @brief 设置系统使能或失能。
     *
     * 这是同步等待 ACK 的控制命令。返回 true 表示 MCU 已确认接受使能状态切换请求；
     * 不表示所有机构动作已经完成。
     *
     * @param enable true 使能系统，false 关闭系统使能。
     * @return true MCU ACK 为 OK；false 发送失败、超时或 MCU 返回错误状态。
     */
    bool SetSystemEnable(bool enable);

    /**
     * @brief 清除 MCU 故障锁存。
     *
     * 这是同步等待 ACK 的控制命令。mask 用于选择要清除的故障位，默认清除全部故障位。
     *
     * @param mask 故障位掩码，默认 0xFFFFFFFF 表示清除全部。
     * @return true MCU ACK 为 OK；false 发送失败、超时或故障未被允许清除。
     */
    bool ClearFault(uint32_t mask = 0xFFFFFFFFu);

    /**
     * @brief 读取 MCU 协议和固件版本。
     *
     * SDK 会发送版本查询帧，并等待 MCU 的版本上报帧。该接口会阻塞等待一小段时间，
     * 适合初始化后确认协议兼容性。
     *
     * @param version 输出版本信息结构体。
     * @return true 成功收到并解析版本上报；false 查询帧发送失败或等待超时。
     */
    bool GetVersion(JqrVersion& version);

    /**
     * @brief 下发头部四轴位置目标。
     *
     * 这是高响应缓存接口，调用线程只更新 SDK 内部最新目标并唤醒 TX 线程，不直接阻塞
     * 等待目标 ACK。TX 线程会在最小发送间隔允许时立即发送新目标，并按
     * head_target_period_ms 周期补发同一目标，直到 ClearHeadTarget、close 或缓存过期。
     *
     * @param head_pitch_deg 头部 pitch 目标角度，单位 deg。
     * @param neck_pitch_deg 颈部 pitch 目标角度，单位 deg。
     * @param neck_swing_deg 颈部 swing 目标角度，单位 deg。
     * @param head_horizontal_deg 头部水平目标角度，单位 deg。
     * @param speed_limit_deg_s 四个轴共用的速度限制，单位 deg/s。
     * @return true SDK 已接收并缓存目标；false 当前版本通常只在内部不可用时返回。
     */
    bool SetHeadTarget(float head_pitch_deg,
                       float neck_pitch_deg,
                       float neck_swing_deg,
                       float head_horizontal_deg,
                       float speed_limit_deg_s = 30.0f);

    /**
     * @brief 下发头部单轴位置目标，其他三轴保持最近目标。
     *
     * 单轴接口内部仍发送完整 4 轴 HeadTarget，不会只发单轴帧。SDK 会优先使用最近一次
     * HeadStatus 初始化四轴缓存，因此只控制头部水平时，其他轴默认保持当前位置。
     *
     * @param axis 要控制的轴，顺序见 HeadAxis。
     * @param target_deg 单轴目标角度，单位 deg。
     * @param speed_limit_deg_s 四个轴共用的速度限制，单位 deg/s。
     * @return true SDK 已接收并缓存完整 4 轴目标；false 尚未收到 HeadStatus 或参数非法。
     */
    bool SetHeadAxisTarget(HeadAxis axis,
                           float target_deg,
                           float speed_limit_deg_s = 30.0f);

    /**
     * @brief 立即发送 Head STOP 并停止 SDK 继续周期下发头部目标。
     *
     * ClearHeadTarget 内部调用 StopHead。STOP 帧不同步等待 ACK，最近一次 ACK 通过
     * GetLastHeadTargetAck 查询。
     *
     * @return true STOP 帧已进入发送队列；false SDK 未运行或组帧失败。
     */
    bool ClearHeadTarget();

    /**
     * @brief 立即发送 Head STOP 并停止 SDK 继续周期下发头部目标。
     *
     * @return true STOP 帧已进入发送队列；false SDK 未运行或组帧失败。
     */
    bool StopHead();

    /**
     * @brief 下发整机底盘速度目标。
     *
     * 这是高响应缓存接口。调用后 TX 线程会尽快发送新目标，并在缓存未过期时按
     * wheel_target_period_ms 周期补发最新目标。默认 wheel_target_cache_expire_ms=100，
     * 业务层需要持续刷新底盘速度。返回值不代表 MCU 执行完成，最近一次目标 ACK 需
     * 通过 GetLastWheelTargetAck 查询。
     *
     * @param linear_mm_s 线速度，单位 mm/s。
     * @param angular_mdeg_s 角速度，单位 mdeg/s，即 1000 mdeg/s = 1 deg/s。
     * @return true SDK 已接收并缓存目标。
     */
    bool SetChassisVelocityMm(int32_t linear_mm_s, int32_t angular_mdeg_s);

    /**
     * @brief 下发整机底盘速度目标，兼容旧接口，单位同 SetChassisVelocityMm。
     *
     * 第一版 SDK 只提供毫米/毫度整数单位接口，不提供 m/s、rad/s 浮点重载，
     * 目的是避免上位机业务层混淆单位。新代码建议优先调用 SetChassisVelocityMm。
     */
    bool SetChassisVelocity(int32_t linear_mm_s, int32_t angular_mdeg_s);

    /**
     * @brief 立即停止轮组目标并等待 MCU ACK。
     *
     * 该接口会先使 SDK 侧轮组周期目标失效，再发送一帧 STOP 目标并同步等待 ACK。
     * 用于业务层明确要求停止轮组输出的场景。
     *
     * @return true MCU ACK 为 OK；false 发送失败、ACK 超时或 MCU 返回错误状态。
     */
    bool StopWheel();

    /**
     * @brief 同步下发药盒控制命令。
     * @note true表示MCU接受命令；实际到位或故障请继续读取 GetMedicineStatus。
     */
    bool SetMedicineBox(MedicineCommand command);

    /**
     * @brief 同步下发药盒控制命令，并返回本次命令seq。
     * @note 应以GetMedicineStatus返回的last_cmd_seq匹配seq_out后再判断动作结果。
     */
    bool SetMedicineBox(MedicineCommand command, uint8_t& seq_out);

    /**
     * @brief 同步切换产品状态灯场景。
     * @param scene 由 S100-p 状态管理器仲裁后的唯一场景。
     * @param ambient 白天/夜间亮度配置。
     * @param restart_pattern true 强制呼吸/闪烁从相位零重新开始。
     */
    bool SetLightScene(LightScene scene,
                       LightAmbient ambient,
                       bool restart_pattern = false);

    /** @brief RGBW 千分比直控，仅用于产测和颜色标定。 */
    bool SetLightRgbw(uint16_t r_permille,
                      uint16_t g_permille,
                      uint16_t b_permille,
                      uint16_t w_permille);

    /**
     * @brief 获取最近一次系统状态缓存。
     *
     * @param status 输出系统状态，包含系统使能、急停、碰撞、故障位和本地更新时间。
     * @return true 已收到过系统状态；false 尚无有效缓存。
     */
    bool GetSystemStatus(JqrSystemStatus& status) const;

    /**
     * @brief 获取最近一次轮组状态缓存。
     *
     * @param status 输出轮组速度、电流、母线电压、故障和本地更新时间。
     * @return true 已收到过轮组状态；false 尚无有效缓存。
     */
    bool GetWheelStatus(JqrWheelStatus& status) const;

    /**
     * @brief 获取最近一次头部状态缓存。
     *
     * @param status 输出头部四轴位置、速度、状态、故障和本地更新时间。
     * @return true 已收到过头部状态；false 尚无有效缓存。
     */
    bool GetHeadStatus(JqrHeadStatus& status) const;

    /**
     * @brief 获取最近一次传感器原始状态缓存。
     *
     * 当前传感器协议还保留为原始 payload，业务层需要按 MCU 版本约定自行解释 data。
     *
     * @param status 输出传感器原始字节、长度和本地更新时间。
     * @return true 已收到过传感器状态；false 尚无有效缓存。
     */
    bool GetSensorStatusRaw(JqrSensorStatusRaw& status) const;

    /**
     * @brief 获取最近一次 IMU 专用上报。
     *
     * Sensor/0x82 payload 按 ImuRecvDataStruct 的 11 个 float32 字段顺序解析。
     *
     * @param imu 输出 IMU 数据。
     * @return true 已收到过 IMU 上报；false 尚无有效缓存。
     */
    bool GetImuData(ImuRecvDataStruct& imu) const;

    /**
     * @brief 获取最近一次锂电池 BMS 状态缓存。
     *
     * pack_voltage_mV 即底盘 FOC 母线电压。电流单位 10mA，温度 ℃，SOC/SOH 单位 %，
     * protect_h/protect_l 为 BMS 保护状态位。
     *
     * @param status 输出 BMS 状态及本地更新时间。
     * @return true 已收到过 BMS 状态；false 尚无有效缓存。
     */
    bool GetBmsStatus(JqrBmsStatus& status) const;

    /** @brief 获取药盒状态、限位、电流、编码器和最近动作结果。 */
    bool GetMedicineStatus(JqrMedicineStatus& status) const;

    /** @brief 获取 MCU 最近一次状态灯执行快照。 */
    bool GetLightStatus(JqrLightStatus& status) const;

    /**
     * @brief 查询最近一次轮组周期目标 ACK。
     *
     * 周期补发同一目标时会复用同一个 wire_seq，MCU 侧重复 ACK 会累计 count。
     * status 可用 ackStatusToString 转成可读字符串。
     *
     * @param ack 输出最近一次轮组目标 ACK 及累计统计。
     * @return true 已收到过轮组目标 ACK；false 尚未收到。
     */
    bool GetLastWheelTargetAck(TargetAckStatus& ack) const;

    /**
     * @brief 查询最近一次头部周期目标 ACK。
     *
     * 用于业务层区分目标参数错误、系统未使能、故障锁定等异步错误。返回 true 仅表示
     * 有 ACK 缓存，具体是否 OK 需要检查 ack.status。
     *
     * @param ack 输出最近一次头部目标 ACK 及累计统计。
     * @return true 已收到过头部目标 ACK；false 尚未收到。
     */
    bool GetLastHeadTargetAck(TargetAckStatus& ack) const;

    /**
     * @brief 获取 SDK 运行统计。
     *
     * 统计项包括收发帧数量、ACK 超时、串口错误、重连次数、周期目标发送次数和最大调度
     * 抖动，可用于定位运动目标下发延迟或 USB 链路异常。
     *
     * @return 当前统计快照。
     */
    JqrSdkRuntimeStats GetStats() const;

    /**
     * @brief 注册原始协议帧回调。
     *
     * 回调在 RX 线程中被调用，业务层应避免在回调里做耗时操作或再次调用可能阻塞的 SDK
     * 接口。适合记录日志、协议调试或透传未结构化的扩展帧。
     *
     * @param cb 帧回调；传入空回调可取消注册。
     */
    void SetFrameCallback(JqrUsbDataRefresh::FrameCallback cb);

private:
    JqrUsbDataRefresh data_;
};

} // namespace jqr
