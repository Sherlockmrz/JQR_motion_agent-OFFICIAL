# 堵转故障标志（Stall Flag）接口设计文档

**版本**：v1.0
**日期**：2026-04-23
**模块**：`jqr_base::BaseController`
**相关 SDK**：`SdkController.h` — `GetStallFlag(uint8_t &StallFlag)`

---

## 1. 背景

底层 SDK (`jqr_sdk_lib`) 新增 `GetStallFlag()` 接口用于查询轮毂电机的堵转故障标志。
base 工程需要在 ROS2 层面将该标志暴露给上层应用，供故障检测、上层策略、日志记录等订阅使用。

设计参考 base 中既有的 `TimerMotorStatePublish` worktimer 发布实践，并针对"堵转故障"这种**低频、事件驱动**的信号做了针对性优化。

---

## 2. 设计目标

| 目标 | 说明 |
|------|------|
| **变化即发** | 标志 0→1 或 1→0 翻转时延迟 ≤ 100ms 发布 |
| **周期兜底** | 稳态下每 10s 心跳一次，避免订阅端长期得不到数据 |
| **启动即发** | 节点启动后首次读到真实值立即发布一次，避免订阅端冷启等待 |
| **线程安全** | 多 callback group 并发访问下无锁、无竞态 |
| **零侵入** | 不改动 `RobotState` 内其他已有字段的发布路径 |

---

## 3. ROS2 接口

### 3.1 话题

| 属性 | 值 |
|------|-----|
| **Topic 名** | `stall_flag` |
| **消息类型** | `std_msgs/msg/UInt8` |
| **QoS 深度** | `10` |
| **语义** | `0` = 正常，`1` = 堵转故障（由 MCU 侧定义） |

### 3.2 发布频率

| 场景 | 频率 / 延迟 |
|------|-------------|
| 标志翻转（事件路径） | 最坏 100ms（受 `UpdateRobotState` 周期决定），立即发布 |
| 稳态无变化（周期路径） | 10s 一次心跳 |
| 节点启动首次读到 0/1 | 立即发布（由 `0xFF` 哨兵初值保证） |

### 3.3 订阅示例

```bash
ros2 topic echo /stall_flag
```

```cpp
node->create_subscription<std_msgs::msg::UInt8>(
    "stall_flag", 10,
    [](std_msgs::msg::UInt8::SharedPtr msg){
        if (msg->data == 1) { /* 处理堵转事件 */ }
    });
```

---

## 4. 实现架构

### 4.1 关键成员

```@/home/jungong3/vln/as/git_jqr_base/Jbase/jqr_ws/src/jqr_base/include/jqr_base/base_controller.hpp:120-120
  std::atomic<uint8_t> stall_flag_{0xFF};  // 堵转故障标志，0xFF哨兵值保证首次读取必触发发布
```

```@/home/jungong3/vln/as/git_jqr_base/Jbase/jqr_ws/src/jqr_base/include/jqr_base/base_controller.hpp:158-158
  rclcpp::Publisher<std_msgs::msg::UInt8>::SharedPtr stall_flag_pub_;
```

```@/home/jungong3/vln/as/git_jqr_base/Jbase/jqr_ws/src/jqr_base/include/jqr_base/base_controller.hpp:184-184
  rclcpp::TimerBase::SharedPtr stall_flag_timer_;
```

| 成员 | 类型 | 作用 |
|------|------|------|
| `stall_flag_` | `std::atomic<uint8_t>` | 当前堵转标志的唯一真相源，**同时承担"上次值"职责**用于变化检测 |
| `stall_flag_pub_` | `Publisher<UInt8>` | 向 `/stall_flag` 话题发布 |
| `stall_flag_timer_` | `wall_timer` (10s) | 兜底周期触发发布 |

### 4.2 两条发布路径

```
                    ┌─────────────────────────────────┐
                    │        SdkControl MCU           │
                    │     GetStallFlag(&flag)         │
                    └────────────────┬────────────────┘
                                     │
            ┌────────────────────────┴─────────────────────────┐
            │                                                  │
            ▼                                                  ▼
  ┌────────────────────┐                         ┌────────────────────────┐
  │ UpdateRobotState() │  (100ms, 事件路径)       │ stall_flag_timer_      │
  │                    │                         │   (10s, 兜底路径)       │
  │ exchange()比较:    │                         │                        │
  │   新值 ≠ 旧值?     │                         │                        │
  │   → 立即发布        │                         │   → 周期发布            │
  └────────┬───────────┘                         └────────────┬───────────┘
           │                                                  │
           └──────────────────┬───────────────────────────────┘
                              ▼
                   ┌─────────────────────┐
                   │  StallFlagPublish() │
                   │  (无锁，原子 load)    │
                   └──────────┬──────────┘
                              ▼
                     topic: /stall_flag
```

### 4.3 事件路径核心代码

```@/home/jungong3/vln/as/git_jqr_base/Jbase/jqr_ws/src/jqr_base/src/base_controller.cpp:355-361
  //堵转故障标志
  uint8_t StallFlag;
  if (sdk_controller_->GetStallFlag(StallFlag) &&
      stall_flag_.exchange(StallFlag) != StallFlag) {
    RCLCPP_INFO(this->get_logger(), "Stall flag changed: %d", StallFlag);
    StallFlagPublish();
  }
```

**关键点**：
- `exchange(StallFlag)` 原子地"写入新值并返回旧值"，**单次原子操作**完成变化检测
- 比较结果 `旧值 != 新值` 成立时发布，触发路径与更新路径无锁耦合
- 位于 `update_robot_state_timer_`（100ms 周期）回调中，检测延迟上限 100ms

### 4.4 周期路径

```@/home/jungong3/vln/as/git_jqr_base/Jbase/jqr_ws/src/jqr_base/src/base_controller.cpp:206-208
  stall_flag_timer_ = this->create_wall_timer(
    std::chrono::seconds(10),
    std::bind(&BaseController::StallFlagPublish, this));
```

### 4.5 统一发布函数

```@/home/jungong3/vln/as/git_jqr_base/Jbase/jqr_ws/src/jqr_base/src/base_controller.cpp:1346-1351
void BaseController::StallFlagPublish(){
  std_msgs::msg::UInt8 stall_msg;
  stall_msg.data = stall_flag_.load();
  stall_flag_pub_->publish(std::move(stall_msg));
}
```

**设计点**：无锁读取，事件路径与周期路径共用此函数，发布逻辑单点定义。

---

## 5. 设计决策

### 5.1 为什么 `stall_flag` 不放进 `RobotState` 结构体？

| 对比维度 | 放入 RobotState | 拆为独立原子成员（选择） |
|----------|----------------|------------------------|
| 聚合发布 | 不参与 `MotorStatePublish`，放进去会让结构体"名不副实" | 独立字段，职责清晰 |
| 并发访问 | 必须共享 `robot_state_mutex_`，与其他字段锁粒度耦合 | 原子变量，零锁 |
| 变化检测 | 需要额外 `last_stall_flag_` 成员 | 原子变量自身承担"上次值" |

### 5.2 为什么用 `std::atomic<uint8_t>` 而非互斥锁？

| 维度 | mutex 方案 | atomic 方案（选择） |
|------|-----------|--------------------|
| 代码行数 | 事件检测 8 行，发布 5 行 | 事件检测 3 行，发布 2 行 |
| 运行开销 | 加锁/解锁 syscall 潜在竞争 | ARM/x86 单条 LDREX/STREX 或 LOCK CMPXCHG |
| 死锁风险 | 存在（需配合 `unique_lock + unlock`） | 无 |
| 原语表达力 | "读-比-写" 三步 | `exchange` 一步完成 |

对于**单字节标志位**，`std::atomic<uint8_t>` 是教科书级正确选择。

### 5.3 为什么用 `0xFF` 作哨兵？

- `GetStallFlag` 正常只会返回 0 或 1（由 MCU 协议约束）
- `0xFF` 作初值，保证节点启动后**首次读到**任何合法值（0 或 1）都与之不等，自动走"变化路径"发布
- 免去了 `bool first_read_` 之类的一次性状态变量，**单一真相源**

### 5.4 为什么选 10s 兜底而非更短？

- 堵转是**稀疏事件**，稳态下标志长期为 0
- 10s 心跳足以让订阅端判断 publisher 存活（配合 QoS keepalive 或业务层超时）
- 过高频兜底会挤占话题带宽且无实际信息增量

### 5.5 为什么 100ms 检测粒度够用？

- `GetStallFlag` 走 MCU 通信链路，与其他 SDK 调用共享带宽
- 电机堵转从物理发生到 MCU 上报本身就有数十毫秒延迟
- 100ms 检测 + ROS2 发布已小于人类感知与上层决策周期

---

## 6. 接口契约

### 6.1 Publisher 侧保证

| 保证 | 说明 |
|------|------|
| **至少一次**发布变化 | 每次 0→1 或 1→0 翻转都会触发发布（除非节点在翻转瞬间崩溃） |
| **最大延迟** | 翻转后 ≤ 100ms（+ ROS2 DDS 传输延迟） |
| **心跳周期** | 稳态下每 10s 一次 |
| **启动语义** | 节点启动后首次读到合法值即发布 |

### 6.2 Subscriber 侧建议

- **边沿触发业务逻辑**：订阅端可自行比较前后两次收到的 `data` 字段检测翻转
- **超时保护**：如连续 > 15s 未收到任何消息，视为 `base_controller` 节点异常
- **QoS 对齐**：建议使用 `rclcpp::QoS(10).reliable()` 与默认 publisher 语义对齐

---

## 7. 文件清单

| 文件 | 改动 |
|------|------|
| `@/home/jungong3/vln/as/git_jqr_base/Jbase/jqr_ws/src/jqr_base/include/jqr_base/base_controller.hpp` | +`#include <atomic>`、+`#include <std_msgs/msg/u_int8.hpp>`、+原子成员 `stall_flag_`、+publisher/timer 成员、+回调声明 `StallFlagPublish()` |
| `@/home/jungong3/vln/as/git_jqr_base/Jbase/jqr_ws/src/jqr_base/src/base_controller.cpp` | +publisher 创建、+10s timer 创建、+`UpdateRobotState()` 中事件检测、+`StallFlagPublish()` 实现 |

---

## 8. 迭代历史

| 版本 | 变更 |
|------|------|
| v0.1 | 初版：添加 `stall_flag` 字段到 `RobotState` + 100ms 定时发布 |
| v0.2 | 用户反馈："变化即发 + 10s 兜底" 策略 |
| v0.3 | 化简：移除 `last_stall_flag_` / `first_read_` 辅助变量，用 `0xFF` 哨兵 + `unique_lock` |
| **v1.0** | 最终：`std::atomic<uint8_t>` + `exchange` 无锁方案，代码量与复杂度最低 |

---

## 9. 验证建议

### 9.1 单元级

```bash
# 观察话题
ros2 topic echo /stall_flag

# 确认频率：稳态 ≈ 0.1Hz（10s 一次），触发堵转瞬间立即多发一条
ros2 topic hz /stall_flag
```

### 9.2 集成级

- 人工让电机堵转（卡住轮子）→ 确认 100ms 内收到 `data=1` 消息
- 释放堵转 → 确认 100ms 内收到 `data=0` 消息
- 断开 MCU 通信 → 确认话题无新消息，且 node 打印 MCU 断连 WARN

### 9.3 压测

- `ros2 topic hz /stall_flag` 持续 1 分钟，稳态应恒定 ≈ 0.1Hz
- 反复触发堵转（每秒一次），确认无消息丢失、无顺序错乱
