//
// MotorDataRefresh.h - 桥接层与上层共享的数据结构定义。
//
// 历史上本文件还含 MotorDataRefresh 通信类（旧自定义协议实现），底层切换为厂商
// JQR USB SDK 后该类已废弃删除，仅保留上层 base_controller 与 SdkController 依赖
// 的 pack(1) 数据结构（HubMotorRecvData / ImuRecvDataStruct / UltrasonicRecvData 等），
// 布局保持二进制兼容不变。
//
#ifndef DATA_TO_PLC_REFRESH_H
#define DATA_TO_PLC_REFRESH_H

#include <cstdint>

#pragma pack(push, 1)
struct HubMotorRecvData {
    float ActualLinearVel  = 0;
    float ActualAngularVel = 0;
};

struct UltrasonicRecvData {
    uint16_t FrontDistance = 0;
    uint16_t RearDistance  = 0;
};

struct ImuRecvDataStruct {
    float Accel_x;
    float Accel_y;
    float Accel_z;
    float Gyro_x;
    float Gyro_y;
    float Gyro_z;
    float Euler_Roll;
    float Euler_Pitch;
    float Euler_Yaw;
    float heading_360;
    float heading_180;
};

struct CycleSendData {
    int32_t TargetLinearVel  = 0;
    int32_t TargetAngularVel = 0;
    uint8_t TargetHubMotorFlag = 0;
    uint8_t MedicineBoxCmd = 0;
    uint8_t MedicineBoxRunSpeed = 0;
    uint8_t MedicineBoxCmdFlag = 0;
    uint8_t FuselageLiftCmd = 0;
    int32_t FuselagePitchPos = 0;
    float ScreenTiltPos = 0.0f;
    float HeadPitchSpeed = 0.0;
    float HeadYawSpeed = 0.0;
    float HeadPitchTargetPos = 0.0;
    float NeckPitchTargetPos = 0.0;
    float NeckYawTargetPos = 0.0;
    float NeckRollTargetPos = 0.0;
};

struct CycleRecvData {
    HubMotorRecvData HubMotor;
    ImuRecvDataStruct ImuData;
    uint8_t MedicineBoxStatus;
    uint8_t FuselageLiftStatus;
    int32_t FuselagePitchPostion;
    float ScreenTiltPosition;
    UltrasonicRecvData UltrData;
    uint8_t BmsSoc;
    int32_t HeadPitchAngle;
    int32_t HeadYawAngle;
    uint8_t HeadStallFlag;
    float HeadPitchActualPos;
    float NeckPitchActualPos;
    float NeckYawActualPos;
    float NeckRollActualPos;
};
#pragma pack(pop)

#endif // DATA_TO_PLC_REFRESH_H
