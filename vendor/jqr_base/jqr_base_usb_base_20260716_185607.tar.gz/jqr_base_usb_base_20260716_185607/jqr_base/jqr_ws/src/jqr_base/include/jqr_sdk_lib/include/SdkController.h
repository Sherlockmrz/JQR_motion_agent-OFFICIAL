//
// Created by zcliu15 Timin on 25/11/21.
//

#ifndef MOTOR_CONTROL_SDK_H
#define MOTOR_CONTROL_SDK_H
#include "MotorDataRefresh.h"
#include <vector>
#include <cstdint>
#include <memory>

#pragma pack(push, 1)
/* 除轮毂电机外功能控制接口 */
struct AllMotorCmd {
    uint8_t MedicineBoxCmd = 0;
    uint8_t MedicineBoxRunSpeed = 0;
    uint8_t FuselageLiftCmd = 0;
    int32_t FuselagePitchPos = 0;
    float ScreenTiltPos = 0.0f;
};

/* 通讯循环接收数据结构体定义 */
struct AllMotorStatus {
    ImuRecvDataStruct ImuData;
    uint8_t MedicineBoxStatus;
    uint8_t FuselageLiftStatus;
    int32_t FuselagePitchPostion;
    float ScreenTiltPosition;
    UltrasonicRecvData UltrData;
    uint8_t BmsSoc;
};
#pragma pack(pop)

struct MedicineBoxStatusData {
    uint32_t uptime_ms = 0;
    uint8_t state = 0;
    uint8_t target_cmd = 0;
    uint8_t command_source = 0;
    uint8_t io_flags = 0;
    uint16_t fault_flags = 0;
    int16_t current_mA = 0;
    uint16_t angle_raw = 0;
    uint8_t last_cmd_seq = 0;
    uint8_t last_result = 0;
};

struct StatusLightData {
    uint32_t uptime_ms = 0;
    uint8_t last_cmd_seq = 0;
    uint8_t control_mode = 0;
    uint8_t scene = 0;
    uint8_t ambient = 0;
    uint8_t effect = 0;
    uint8_t flags = 0;
    uint16_t r_permille = 0;
    uint16_t g_permille = 0;
    uint16_t b_permille = 0;
    uint16_t w_permille = 0;
};

class SdkControl {
    private:
        /* 通信实现句柄（PIMPL）。底层已由旧自定义协议切换为
         * JQR_USB_SDK_CPP（jqr::JqrSdkController），此处只持有不透明指针，
         * 公开接口签名保持与旧 .so 完全一致。 */
        class Impl;
        std::unique_ptr<Impl> impl_;
    public:
        /* 默认构造函数 */
        SdkControl();
        /* 默认析构函数 */
        ~SdkControl();
        /* 初始化init函数 */
        bool init();
        /* 获取MCU通信的连接状态 连接保持返回 true 连接断开返回 false */
        bool GetMcuConnectStatus(void);
        /* 同步清除故障，FaultMask = 0xFFFFFFFF 表示清除全部故障位 */
        bool ClearFault(uint32_t FaultMask = 0xFFFFFFFFu);
        /* 设置整机线速度角速度 */
        bool SetRobotVelocities(int32_t linear_vel, int32_t angular_vel);
        /* 读取整机线速度角速度 */
        bool GetRobotVelocities(std::vector<HubMotorRecvData>& arry);
        /* 读取IMU数据 */
        bool GetImuData(std::vector<ImuRecvDataStruct>& arry);
        /* 药盒控制 */ /* TargetCmd = 0 是关闭药盒 TargetCmd = 1 是打开药盒 */ /* SpeedGear = 0 是低速档 SpeedGear = 1 是高速档 */
        bool SetMedicineBoxSwitch(uint8_t TargetCmd, uint8_t SpeedGear);
        /* 原生药盒命令：0停止、1打开、2关闭；seq用于关联异步状态。 */
        bool SetMedicineBoxCommand(uint8_t Command, uint8_t &CommandSeq);
        /* 获取药盒电机开关状态 */
        /* Status = 0 是关闭状态 Status = 1 是打开状态 Status = 2 是中间正在运行 */
        bool GetMedicineBoxStatus(uint8_t &Status);
        /* 获取 MCU 上报的完整药盒状态。 */
        bool GetMedicineBoxStatusDetail(MedicineBoxStatusData &Status);
        /* 产品状态灯场景：Scene=0..10，Ambient=0白天/1夜间。 */
        bool SetStatusLightScene(uint8_t Scene, uint8_t Ambient, bool RestartPattern);
        /* 获取 MCU 上报的状态灯执行状态。 */
        bool GetStatusLightStatus(StatusLightData &Status);
        /* 机身升降控制 */ /* TargetCmd = 0 机身下降 TargetCmd = 1 机身升起 */
        bool FuselageLiftControl(uint8_t TargetCmd);
        /* 获取机身升降状态 */ /* FuselageLiftStatus = 0 机身低位状态 FuselageLiftStatus = 1 机身高位状态 FuselageLiftStatus = 2 是中间正在运行*/
        bool GetFuselageLiftStatus(uint8_t &FuselageLiftStatus);
        /* 机身俯仰角度控制 */ /* FuselagePitchTargetPos 单位 0.1度 垂直状态为0度 向前为正 向后为负 */ /* 角度有效范围 -5° - 5° 数值范围 -50 - 50 */
        bool SetFuselagePitchPos(int32_t FuselagePitchTargetPos);
        /* 机身俯仰角度状态获取 */ /* FuselagePitchActualPos 单位 0.1度 垂直状态为0度 向前为正 向后为负 */ /* 误差 ±0.1° */
        bool GetFuselagePitchPos(int32_t &FuselagePitchActualPos);
        /* 屏幕俯仰角度控制 */ /* 单位0.01度 垂直状态为零度 向下为正 向上为负 */ /* 角度有效范围 -28° - 7° 数值范围 -2800 - 700 */
        bool SetScreenTiltPos(float ScreenTiltTargetPos);
        /* 屏幕俯仰角度状态获取 */ /* 单位0.01度 垂直状态为零度 向下为正 向上为负 */
        bool GetScreenTiltPos(float &ScreenTiltActualPos);
        /* 超声波数据获取 */ /* 单位 0.1mm */ /* 有效测距范围 60mm - 1000mm */
        bool GetUltrasonicData(std::vector<UltrasonicRecvData>& arry);
        /* 电池电量获取 */ /* 百分比 1%-100% */
        bool GetBmsSoc(uint8_t &BmsSoc);
        /* 控制除轮毂电机外所有器件功能 */
        bool SetAllMotorCmd(AllMotorCmd AllCmd);
        /* 获取除轮毂电机外所有器件状态 */
        bool GetAllMotorStatus(std::vector<AllMotorStatus>& arry);
    /* Demo3样机头部指令接口 */
        /* 头部俯仰旋转速度控制 */ /* HeadPitchSpeed 单位 rad/s 方向 向下为正 向上为负 */
        bool SetHeadPitchSpeed(float HeadPitchSpeed);
        /* 头部俯仰角度获取 */ /* HeadPitchAngle 单位角度0.1° 最上方为零度 角度数值范围 0 - 600 */
        bool GetHeadPitchAngle(int32_t &HeadPitchAngle);
        /* 头部水平旋转速度控制 */ /* HeadYawSpeed 单位 rad/s 方向 逆时针为正 顺时针为负 */
        bool SetHeadYawSpeed(float HeadYawSpeed);
        /* 头部水平旋转角度获取 */ /* HeadYadAngle 单位角度0.1° 最右边为零度 角度范围 0 - 3400 */
        bool GetHeadYawAngle(int32_t &HeadYadAngle);
        /* 获取堵转故障标志 */
        bool GetStallFlag(uint8_t &StallFlag);
    /* 四自由度样机头部指令接口 */
        /* 头部俯仰角度控制 */ /* HeadPitchTargetPos 单位°角度 范围 -25° - 25° */
        bool SetHeadPitchTargetPos(float HeadPitchTargetPos);
        /* 脖子俯仰角度控制 */ /* NeckPitchTargetPos 单位°角度 范围 -30° - 30° */
        bool SetNeckPitchTargetPos(float NeckPitchTargetPos);
        /* 脖子摇摆角度控制 */ /* NeckYawTargetPos 单位°角度 范围 -30° - 30° */
        bool SetNeckYawTargetPos(float NeckYawTargetPos);
        /* 脖子旋转角度控制 */ /* NeckRollTargetPos 单位°角度 范围 -170° - 170° */
        bool SetNeckRollTargetPos(float NeckRollTargetPos);
        /* 头部俯仰角度获取 */ /* HeadPitchActualPos 单位°角度 范围 -25° - 25° */
        bool GetHeadPitchTargetPos(float &HeadPitchActualPos);
        /* 脖子俯仰角度获取 */ /* NeckPitchActualPos 单位°角度 范围 -30° - 30° */
        bool GetNeckPitchTargetPos(float &NeckPitchActualPos);
        /* 脖子摇摆角度获取 */ /* NeckYawActualPos 单位°角度 范围 -30° - 30° */
        bool GetNeckYawTargetPos(float &NeckYawActualPos);
        /* 脖子旋转角度获取 */ /* NeckRollActualPos 单位°角度 范围 -170° - 170° */
        bool GetNeckRollTargetPos(float &NeckRollActualPos);
};
#endif // MOTOR_CONTROL_SDK_H
