#pragma once

#include <string>
#include <thread>
#include "JqrSdkConfig.h"

namespace jqr {

/**
 * @brief Linux 线程实时性配置工具。
 *
 * 该工具集中处理线程命名、SCHED_FIFO 优先级、CPU 绑核和内存锁定。相关操作在 Linux
 * 下可能因为权限不足失败，SDK 设计为返回 warning 字符串供日志记录，而不是直接让
 * 初始化失败。
 */
class JqrThreadUtil {
public:
    /**
     * @brief 对指定 std::thread 应用实时调度和 CPU 绑核配置。
     *
     * 函数会尝试设置线程名，priority > 0 时尝试设置 SCHED_FIFO 优先级，
     * enable_affinity 为 true 且 cpu >= 0 时尝试绑定 CPU。任何一步失败都会追加 warning。
     *
     * @param th 已启动的线程对象。
     * @param name 线程名，可为空。
     * @param priority SCHED_FIFO 优先级，<=0 表示不设置实时优先级。
     * @param enable_affinity 是否启用 CPU 绑核。
     * @param cpu CPU 编号，enable_affinity 为 true 时生效。
     * @return 空字符串表示无 warning；非空字符串描述失败原因，SDK 可继续运行。
     */
    static std::string applyRealtimeToThread(std::thread& th,
                                             const char* name,
                                             int priority,
                                             bool enable_affinity,
                                             int cpu);

    /**
     * @brief 根据配置决定是否锁定进程内存。
     *
     * enable_mlockall 为 true 时在 Linux 下调用 mlockall(MCL_CURRENT | MCL_FUTURE)，
     * 用于减少缺页导致的偶发通信延迟。该操作通常需要 cap_ipc_lock 或合适的 memlock
     * 限额。
     *
     * @param enable_mlockall 是否启用内存锁定。
     * @return 空字符串表示未启用或调用成功；非空字符串为 warning。
     */
    static std::string lockMemoryIfEnabled(bool enable_mlockall);
};

} // namespace jqr
