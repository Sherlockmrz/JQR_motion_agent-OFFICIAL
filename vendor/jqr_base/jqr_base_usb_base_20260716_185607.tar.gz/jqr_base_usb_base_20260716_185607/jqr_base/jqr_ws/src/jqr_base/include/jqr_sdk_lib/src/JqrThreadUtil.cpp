#include "JqrThreadUtil.h"

#include <pthread.h>
#include <sched.h>
#include <sstream>
#include <sys/mman.h>

namespace jqr {

// 给已启动线程设置名称、SCHED_FIFO 优先级和 CPU 绑核；失败只返回 warning，不中断 SDK。
std::string JqrThreadUtil::applyRealtimeToThread(std::thread& th,
                                                 const char* name,
                                                 int priority,
                                                 bool enable_affinity,
                                                 int cpu) {
    std::ostringstream warn;

#if defined(__linux__)
    pthread_t handle = th.native_handle();

    if (name != nullptr) {
        (void)pthread_setname_np(handle, name);
    }

    if (priority > 0) {
        sched_param sp{};
        sp.sched_priority = priority;

        int ret = pthread_setschedparam(handle, SCHED_FIFO, &sp);
        if (ret != 0) {
            warn << "[WARN] 设置线程 " << (name ? name : "") << " SCHED_FIFO 优先级 "
                 << priority << " 失败，可能缺少 root/cap_sys_nice 权限；";
        }
    }

    if (enable_affinity && cpu >= 0) {
        cpu_set_t cpuset;
        CPU_ZERO(&cpuset);
        CPU_SET(cpu, &cpuset);

        int ret = pthread_setaffinity_np(handle, sizeof(cpu_set_t), &cpuset);
        if (ret != 0) {
            warn << "[WARN] 设置线程 " << (name ? name : "") << " 绑定 CPU"
                 << cpu << " 失败；";
        }
    }
#else
    (void)th;
    (void)name;
    (void)priority;
    (void)enable_affinity;
    (void)cpu;
#endif

    return warn.str();
}

// 按配置调用 mlockall 锁定内存页，减少缺页造成的偶发调度延迟。
std::string JqrThreadUtil::lockMemoryIfEnabled(bool enable_mlockall) {
    if (!enable_mlockall) {
        return "";
    }

#if defined(__linux__)
    if (mlockall(MCL_CURRENT | MCL_FUTURE) != 0) {
        return "[WARN] mlockall 失败，可能缺少 cap_ipc_lock 或 memlock 权限；";
    }
#endif
    return "";
}

} // namespace jqr
