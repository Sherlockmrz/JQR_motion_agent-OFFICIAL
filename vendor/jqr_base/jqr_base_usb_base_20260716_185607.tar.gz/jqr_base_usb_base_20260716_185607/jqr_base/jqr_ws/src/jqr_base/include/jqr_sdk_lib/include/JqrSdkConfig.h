#pragma once

#include <cstdint>
#include <string>

namespace jqr {

/**
 * @brief SDK 后台线程实时性配置。
 *
 * USB CDC 通信延迟主要受 TX/RX 线程调度、串口驱动缓冲和业务层调用频率影响。
 * 该结构体用于在 Linux 部署环境中给通信线程设置 SCHED_FIFO 优先级、CPU 绑核和
 * mlockall。开发机权限不足时建议保持默认关闭，正式地瓜板部署时再按实测开启。
 */
struct JqrRealtimeConfig {
    /** 是否启用实时调度配置；false 时不会改线程调度策略。 */
    bool enable_realtime = false;

    /** RX 接收线程 SCHED_FIFO 优先级，数值越大越优先。 */
    int rx_thread_priority = 40;
    /** TX 发送线程 SCHED_FIFO 优先级，目标下发延迟优先关注该线程。 */
    int tx_thread_priority = 50;
    /** Watchdog 线程优先级，通常低于收发线程即可。 */
    int watchdog_thread_priority = 20;

    /** 是否把线程绑定到指定 CPU，适合多核板卡上减少调度迁移抖动。 */
    bool enable_cpu_affinity = false;
    /** RX 线程绑定 CPU 编号，enable_cpu_affinity 为 true 时生效。 */
    int rx_thread_cpu = 1;
    /** TX 线程绑定 CPU 编号，enable_cpu_affinity 为 true 时生效。 */
    int tx_thread_cpu = 1;
    /** Watchdog 线程绑定 CPU 编号，enable_cpu_affinity 为 true 时生效。 */
    int watchdog_thread_cpu = 1;

    /** 是否调用 mlockall 锁住当前和后续内存页，减少缺页造成的偶发延迟。 */
    bool enable_mlockall = false;
};

/**
 * @brief SDK 总配置。
 *
 * 业务层可通过该配置统一调整 USB 设备、通信周期、运动目标超时、状态超时、重连策略和
 * 实时线程策略。默认值偏向高响应目标下发：轮组目标 5 ms 周期补发，头部目标 10 ms
 * 周期补发，新目标最小发送间隔 2 ms；底盘速度目标默认 100 ms 未刷新即停止补发。
 */
struct JqrSdkConfig {
    /** Linux USB CDC ACM 设备节点，例如 /dev/ttyACM0。 */
    std::string device = "/dev/ttyACM0";
    /** 串口波特率，需与 MCU 侧配置一致。 */
    int baudrate = 115200;

    /** 周期保活帧发送间隔，单位 ms；MCU 可据此判断上位机是否在线。 */
    uint32_t heartbeat_period_ms = 50;

    /** 头部目标周期补发间隔，单位 ms；目标变化时仍会优先立即发送。 */
    uint32_t head_target_period_ms = 10;
    /** 轮组目标周期补发间隔，单位 ms；目标变化时仍会优先立即发送。 */
    uint32_t wheel_target_period_ms = 5;

    /** 头部新目标立即发送的最小间隔，单位 ms，用于限制业务层过高调用频率。 */
    uint32_t head_min_send_interval_ms = 2;
    /** 轮组新目标立即发送的最小间隔，单位 ms，用于限制业务层过高调用频率。 */
    uint32_t wheel_min_send_interval_ms = 2;

    /** MCU 侧头部目标超时时间，单位 ms；应大于 SDK 头部补发周期。 */
    uint16_t head_target_timeout_ms = 150;
    /** MCU 侧轮组目标超时时间，单位 ms；应大于 SDK 轮组补发周期。 */
    uint16_t wheel_target_timeout_ms = 300;

    /** 状态接收超时，单位 ms；超过该时间没有状态上报时 SDK 会判定链路异常。 */
    uint32_t status_timeout_ms = 300;

    /** 是否在串口错误或状态超时后自动关闭并重新打开设备节点。 */
    bool enable_reconnect = true;
    /** 自动重连尝试间隔，单位 ms。 */
    uint32_t reconnect_interval_ms = 1000;

    /**
     * 兼容旧版本的全局周期目标缓存自动过期时间，单位 ms。
     *
     * 新代码优先使用 head_target_cache_expire_ms / wheel_target_cache_expire_ms。
     * 该字段非 0 时会覆盖头部和底盘专用配置；0 表示不覆盖专用配置。
     */
    uint32_t target_cache_expire_ms = 0;

    /**
     * 头部目标缓存自动过期时间，单位 ms。
     *
     * 默认 0 表示不过期：SetHeadTarget/SetHeadAxisTarget 一次后，SDK 继续周期补发头部
     * 最新目标，直到 StopHead/ClearHeadTarget/disable。
     */
    uint32_t head_target_cache_expire_ms = 0;

    /**
     * 底盘目标缓存自动过期时间，单位 ms。
     *
     * 默认 200ms：业务层必须持续刷新 SetChassisVelocityMm；超过该时间未刷新时，SDK
     * 停止周期补发旧速度目标，MCU 再按 wheel_target_timeout_ms 清零并停车。
     * 如需旧版“一次下发持续保持”行为，可显式设为 0。
     */
    uint32_t wheel_target_cache_expire_ms = 200;

    /** 后台线程实时性配置，默认关闭。 */
    JqrRealtimeConfig realtime;
};

} // namespace jqr
