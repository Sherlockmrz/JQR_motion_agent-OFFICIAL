from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='jqr_base',
            executable='jqr_base_node',
            name='base_controller',
            output='screen',
            parameters=[{
                # 根据构造函数更新参数名称和值
                'odom_frequency': 50.0,
                'imu_frequency': 100.0,
                'battery_level_frequency': 0.1,
                'max_linear_vel': 1.2,
                'max_angular_vel': 1.5708,  # 90°/s
                'odom_frame_id': 'odom',
                'imu_frame_id': 'imu_link',
                'base_frame_id': 'base_link'
            }]
        )
    ])