#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <vector>
#include "JqrCommTypes.h"

namespace jqr {

/**
 * @brief 一帧已经完成 CRC/帧尾校验的 JQR USB 协议帧。
 *
 * 协议帧格式为：
 * FA FA + body_len(le32) + mod_id + msg_id + payload + crc8 + AF AF。
 * body_len 包含 mod_id、msg_id、payload、crc、EOF 两字节，因此最小值为 5。
 */
struct JqrFrame {
    /** 模块 ID，见 MOD_SYSTEM、MOD_WHEEL 等常量。 */
    uint8_t mod_id = 0;
    /** 消息 ID，见 MSG_XXX 常量。 */
    uint8_t msg_id = 0;
    /** 不包含帧头、长度、mod/msg、CRC 和帧尾的业务 payload。 */
    std::vector<uint8_t> payload;
    /** 完整原始帧字节，便于日志或协议调试。 */
    std::vector<uint8_t> raw;
};

/**
 * @brief USB CDC 字节流协议解析器。
 *
 * USB CDC 给上位机的是连续字节流，不保证一次 read 对应一帧。解析器内部缓存未完成
 * 数据，能够处理半包、粘包、噪声字节、CRC 错误后的重新同步。每个串口连接建议使用
 * 一个独立 parser，重连后调用 reset 清空残留字节。
 */
class JqrProtocolParser {
public:
    /**
     * @brief 输入一段新收到的字节并解析出完整协议帧。
     *
     * @param data 新收到的字节指针，长度为 len。
     * @param len 新收到的字节数。
     * @return 解析出的完整有效帧列表；如果只有半包或全部无效则返回空列表。
     */
    std::vector<JqrFrame> feed(const uint8_t* data, size_t len);

    /**
     * @brief 清空解析缓存。
     *
     * 串口重连、协议错误恢复或业务层希望丢弃残留半包时调用。
     */
    void reset();

private:
    /** 尚未组成完整帧的接收缓存。 */
    std::vector<uint8_t> rx_buf_;
};

/**
 * @brief 计算协议使用的 CRC8/ATM 校验值。
 *
 * @param data 被计算数据首地址。
 * @param len 被计算数据长度。
 * @return CRC8 校验值。
 */
uint8_t crc8Atm(const uint8_t* data, size_t len);

/**
 * @brief 根据模块、消息和 payload 生成完整协议帧。
 *
 * @param mod_id 模块 ID。
 * @param msg_id 消息 ID。
 * @param payload 业务 payload，最大 256 字节。
 * @return 完整帧字节；payload 过长时返回空 vector。
 */
std::vector<uint8_t> buildFrame(uint8_t mod_id, uint8_t msg_id, const std::vector<uint8_t>& payload);

/**
 * @brief 打包心跳 payload。
 *
 * @param seq 命令序号，用于 MCU ACK 回显和匹配。
 * @return payload 字节，需再通过 buildFrame 加帧头帧尾。
 */
std::vector<uint8_t> packHeartbeat(uint8_t seq);

/**
 * @brief 打包系统使能 payload。
 *
 * @param seq 命令序号。
 * @param enable true 使能系统，false 失能系统。
 * @return payload 字节。
 */
std::vector<uint8_t> packSystemEnable(uint8_t seq, bool enable);

/**
 * @brief 打包药盒一次性控制命令。
 * @param seq 命令序号。
 * @param command STOP/OPEN/CLOSE。
 * @return 固定3字节 payload，speed_gear 当前固定为0。
 */
std::vector<uint8_t> packMedicineCommand(uint8_t seq, MedicineCommand command);

/** 打包 Light/0x01 固定 9 字节 RGBW 直控命令。 */
std::vector<uint8_t> packLightRgbw(uint8_t seq,
                                   uint16_t r_permille,
                                   uint16_t g_permille,
                                   uint16_t b_permille,
                                   uint16_t w_permille);

/** 打包 Light/0x02 固定 4 字节场景命令。 */
std::vector<uint8_t> packLightScene(uint8_t seq,
                                    LightScene scene,
                                    LightAmbient ambient,
                                    bool restart_pattern);

/**
 * @brief 打包清故障 payload。
 *
 * @param seq 命令序号。
 * @param fault_mask 需要清除的故障位掩码。
 * @return payload 字节。
 */
std::vector<uint8_t> packClearFault(uint8_t seq, uint32_t fault_mask);

/**
 * @brief 打包轮组目标 payload。
 *
 * @param seq 目标序号。新目标递增 seq，周期补发同一目标复用 seq。
 * @param mode 轮组控制模式。
 * @param enable 是否使能轮组输出。
 * @param timeout_ms MCU 侧目标超时时间，单位 ms。
 * @param linear_mm_s 底盘线速度，单位 mm/s，仅 CHASSIS 模式使用。
 * @param angular_mdeg_s 底盘角速度，单位 mdeg/s，仅 CHASSIS 模式使用。
 * @param left_rpm 协议兼容保留字段；SDK 业务接口固定传 0。
 * @param right_rpm 协议兼容保留字段；SDK 业务接口固定传 0。
 * @param flags 扩展标志位，当前默认 0。
 * @return payload 字节。
 */
std::vector<uint8_t> packWheelTarget(uint8_t seq,
                                     WheelMode mode,
                                     bool enable,
                                     uint16_t timeout_ms,
                                     int32_t linear_mm_s,
                                     int32_t angular_mdeg_s,
                                     int16_t left_rpm,
                                     int16_t right_rpm,
                                     uint8_t flags = 0);

/**
 * @brief 打包头部四轴 float 目标 payload。
 *
 * @param seq 目标序号。新目标递增 seq，周期补发同一目标复用 seq。
 * @param mode 头部控制模式，业务接口当前使用 POSITION。
 * @param enable_mask 四轴使能掩码，bit0..bit3 分别对应四个轴。
 * @param timeout_ms MCU 侧目标超时时间，单位 ms。
 * @param head_pitch_deg 头部 pitch 目标角度，单位 deg。
 * @param neck_pitch_deg 颈部 pitch 目标角度，单位 deg。
 * @param neck_swing_deg 颈部 swing 目标角度，单位 deg。
 * @param head_horizontal_deg 头部水平目标角度，单位 deg。
 * @param speed_limit_deg_s 四轴速度限制，单位 deg/s。
 * @param flags 扩展标志位，例如限位处理策略。
 * @return payload 字节。
 */
std::vector<uint8_t> packHeadTargetFloat(uint8_t seq,
                                         HeadMode mode,
                                         uint8_t enable_mask,
                                         uint16_t timeout_ms,
                                         float head_pitch_deg,
                                         float neck_pitch_deg,
                                         float neck_swing_deg,
                                         float head_horizontal_deg,
                                         const std::array<float, 4>& speed_limit_deg_s,
                                         uint8_t flags);

/**
 * @brief 解码 MCU ACK payload。
 *
 * @param payload ACK payload。
 * @param out 输出 ACK 结构体。
 * @return true 长度合法并成功解码；false payload 太短。
 */
bool decodeAck(const std::vector<uint8_t>& payload, JqrAck& out);

/**
 * @brief 解码版本上报 payload。
 *
 * @param payload 版本上报 payload。
 * @param out 输出版本结构体。
 * @return true 长度合法并成功解码；false payload 太短。
 */
bool decodeVersion(const std::vector<uint8_t>& payload, JqrVersion& out);

/**
 * @brief 解码系统状态 payload。
 *
 * @param payload 系统状态 payload。
 * @param out 输出系统状态结构体。
 * @return true 长度合法并成功解码；false payload 太短。
 */
bool decodeSystemStatus(const std::vector<uint8_t>& payload, JqrSystemStatus& out);

/**
 * @brief 解码轮组状态 payload。
 *
 * @param payload 轮组状态 payload。
 * @param out 输出轮组状态结构体。
 * @return true 长度合法并成功解码；false payload 太短。
 */
bool decodeWheelStatus(const std::vector<uint8_t>& payload, JqrWheelStatus& out);

/**
 * @brief 解码头部四轴状态 payload。
 *
 * @param payload 头部状态 payload。
 * @param out 输出头部状态结构体。
 * @return true 长度合法并成功解码；false payload 太短。
 */
bool decodeHeadStatus(const std::vector<uint8_t>& payload, JqrHeadStatus& out);

/**
 * @brief 解码锂电池 BMS 状态 payload。
 *
 * @param payload BMS 状态 payload。
 * @param out 输出 BMS 状态结构体。
 * @return true 长度合法并成功解码；false payload 太短。
 */
bool decodeBmsStatus(const std::vector<uint8_t>& payload, JqrBmsStatus& out);

/** 解码 Aux/0x81 固定16字节药盒状态。 */
bool decodeMedicineStatus(const std::vector<uint8_t>& payload, JqrMedicineStatus& out);

/** 解码 Light/0x81 固定 18 字节状态。 */
bool decodeLightStatus(const std::vector<uint8_t>& payload, JqrLightStatus& out);

/**
 * @brief 解码传感器原始状态 payload。
 *
 * @param payload 传感器原始 payload。
 * @param out 输出原始数据缓存，最多复制 64 字节。
 * @return true 始终成功，超出缓存的部分会被截断。
 */
bool decodeSensorStatusRaw(const std::vector<uint8_t>& payload, JqrSensorStatusRaw& out);

/**
 * @brief 解码 IMU 专用上报 payload。
 *
 * @param payload Sensor/0x82 payload，固定 11 个 float32 小端。
 * @param out 输出 IMU 数据结构。
 * @return true 长度合法并成功解码；false payload 太短。
 */
bool decodeImuReport(const std::vector<uint8_t>& payload, ImuRecvDataStruct& out);

/**
 * @brief 将 ACK 状态码转为可读字符串。
 *
 * @param status ACK 状态码。
 * @return 状态名称，例如 OK、PARAM_ERROR、DISABLED 或 UNKNOWN。
 */
std::string ackStatusToString(uint8_t status);

/**
 * @brief 将协议帧格式化为便于日志查看的字符串。
 *
 * 对已知状态帧会尝试解码关键字段；未知帧只输出模块、消息和 payload 长度。
 *
 * @param frame 已解析的协议帧。
 * @return 可读日志字符串。
 */
std::string frameToString(const JqrFrame& frame);

} // namespace jqr
