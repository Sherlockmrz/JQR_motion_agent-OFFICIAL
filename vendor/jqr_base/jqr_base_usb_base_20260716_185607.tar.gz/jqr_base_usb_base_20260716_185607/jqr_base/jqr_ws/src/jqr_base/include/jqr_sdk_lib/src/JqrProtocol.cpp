#include "JqrProtocol.h"

#include <cstring>
#include <iomanip>
#include <sstream>
#include <utility>

namespace jqr {

namespace {

constexpr uint8_t SOF0 = 0xFA;
constexpr uint8_t SOF1 = 0xFA;
constexpr uint8_t EOF0 = 0xAF;
constexpr uint8_t EOF1 = 0xAF;
constexpr uint32_t MAX_PAYLOAD = 256;

// 从 payload 指定偏移读取 uint16 小端值，调用前由上层解码函数保证长度足够。
uint16_t readU16Le(const std::vector<uint8_t>& p, size_t off) {
    return static_cast<uint16_t>(p[off]) | (static_cast<uint16_t>(p[off + 1]) << 8);
}

// 从 payload 指定偏移读取 int16 小端值，按二进制补码直接转换。
int16_t readI16Le(const std::vector<uint8_t>& p, size_t off) {
    return static_cast<int16_t>(readU16Le(p, off));
}

// 从 payload 指定偏移读取 uint32 小端值，调用前由上层解码函数保证长度足够。
uint32_t readU32Le(const std::vector<uint8_t>& p, size_t off) {
    return static_cast<uint32_t>(p[off]) |
           (static_cast<uint32_t>(p[off + 1]) << 8) |
           (static_cast<uint32_t>(p[off + 2]) << 16) |
           (static_cast<uint32_t>(p[off + 3]) << 24);
}

// 从 payload 指定偏移读取 int32 小端值，按二进制补码直接转换。
int32_t readI32Le(const std::vector<uint8_t>& p, size_t off) {
    return static_cast<int32_t>(readU32Le(p, off));
}

// 从 payload 指定偏移读取 IEEE754 float 小端值，使用 memcpy 避免别名访问问题。
float readF32Le(const std::vector<uint8_t>& p, size_t off) {
    uint32_t u = readU32Le(p, off);
    float f = 0.0f;
    std::memcpy(&f, &u, sizeof(f));
    return f;
}

// 向 payload 追加 uint16 小端值。
void pushU16Le(std::vector<uint8_t>& v, uint16_t x) {
    v.push_back(static_cast<uint8_t>(x & 0xFF));
    v.push_back(static_cast<uint8_t>((x >> 8) & 0xFF));
}

// 向 payload 追加 int16 小端值。
void pushI16Le(std::vector<uint8_t>& v, int16_t x) {
    pushU16Le(v, static_cast<uint16_t>(x));
}

// 向 payload 追加 uint32 小端值。
void pushU32Le(std::vector<uint8_t>& v, uint32_t x) {
    v.push_back(static_cast<uint8_t>(x & 0xFF));
    v.push_back(static_cast<uint8_t>((x >> 8) & 0xFF));
    v.push_back(static_cast<uint8_t>((x >> 16) & 0xFF));
    v.push_back(static_cast<uint8_t>((x >> 24) & 0xFF));
}

// 向 payload 追加 int32 小端值。
void pushI32Le(std::vector<uint8_t>& v, int32_t x) {
    pushU32Le(v, static_cast<uint32_t>(x));
}

// 向 payload 追加 IEEE754 float 小端值，使用 memcpy 保持跨编译器安全。
void pushF32Le(std::vector<uint8_t>& v, float x) {
    uint32_t u = 0;
    std::memcpy(&u, &x, sizeof(u));
    pushU32Le(v, u);
}

// 将单字节转成 0xNN 形式，供日志格式化使用。
std::string hexByte(uint8_t x) {
    std::ostringstream ss;
    ss << "0x" << std::hex << std::uppercase << std::setw(2) << std::setfill('0')
       << static_cast<int>(x);
    return ss.str();
}

} // namespace

// 计算 CRC8/ATM，范围由调用方指定；组帧时覆盖 SOF 到 payload 的所有字节。
uint8_t crc8Atm(const uint8_t* data, size_t len) {
    uint8_t crc = 0;
    for (size_t i = 0; i < len; ++i) {
        crc ^= data[i];
        for (int b = 0; b < 8; ++b) {
            if (crc & 0x80) {
                crc = static_cast<uint8_t>((crc << 1) ^ 0x07);
            } else {
                crc = static_cast<uint8_t>(crc << 1);
            }
        }
    }
    return crc;
}

// 生成完整协议帧：帧头、长度、模块、消息、payload、CRC 和帧尾一次性打包。
std::vector<uint8_t> buildFrame(uint8_t mod_id, uint8_t msg_id, const std::vector<uint8_t>& payload) {
    if (payload.size() > MAX_PAYLOAD) {
        return {};
    }

    const uint32_t body_len = static_cast<uint32_t>(payload.size()) + 5u;

    std::vector<uint8_t> frame;
    frame.reserve(payload.size() + 11u);

    frame.push_back(SOF0);
    frame.push_back(SOF1);
    pushU32Le(frame, body_len);
    frame.push_back(mod_id);
    frame.push_back(msg_id);
    frame.insert(frame.end(), payload.begin(), payload.end());

    // CRC 计算范围：从 SOF0 到 payload 最后一个字节，不包含 CRC 和 EOF。
    frame.push_back(crc8Atm(frame.data(), frame.size()));
    frame.push_back(EOF0);
    frame.push_back(EOF1);

    return frame;
}

// 清空 parser 内部半包缓存，通常在串口重连后调用。
void JqrProtocolParser::reset() {
    rx_buf_.clear();
}

// 把新收到的 CDC 字节流追加到缓存中，并尽可能解析出完整有效帧。
std::vector<JqrFrame> JqrProtocolParser::feed(const uint8_t* data, size_t len) {
    rx_buf_.insert(rx_buf_.end(), data, data + len);
    std::vector<JqrFrame> out;

    while (true) {
        if (rx_buf_.size() < 11) {
            break;
        }

        // 手动查找 FA FA，避免临时数组迭代器导致未定义行为。
        size_t sof_pos = rx_buf_.size();
        for (size_t i = 0; i + 1 < rx_buf_.size(); ++i) {
            if (rx_buf_[i] == SOF0 && rx_buf_[i + 1] == SOF1) {
                sof_pos = i;
                break;
            }
        }

        if (sof_pos == rx_buf_.size()) {
            // 保留最后一个 FA，避免半个帧头被清掉。
            if (!rx_buf_.empty() && rx_buf_.back() == SOF0) {
                uint8_t last = rx_buf_.back();
                rx_buf_.clear();
                rx_buf_.push_back(last);
            } else {
                rx_buf_.clear();
            }
            break;
        }

        if (sof_pos > 0) {
            rx_buf_.erase(rx_buf_.begin(), rx_buf_.begin() + static_cast<long>(sof_pos));
        }

        if (rx_buf_.size() < 6) {
            break;
        }

        uint32_t body_len = static_cast<uint32_t>(rx_buf_[2]) |
                            (static_cast<uint32_t>(rx_buf_[3]) << 8) |
                            (static_cast<uint32_t>(rx_buf_[4]) << 16) |
                            (static_cast<uint32_t>(rx_buf_[5]) << 24);

        if (body_len < 5 || body_len > MAX_PAYLOAD + 5) {
            rx_buf_.erase(rx_buf_.begin());
            continue;
        }

        size_t frame_len = 6u + body_len;
        if (rx_buf_.size() < frame_len) {
            break;
        }

        if (rx_buf_[frame_len - 2] != EOF0 || rx_buf_[frame_len - 1] != EOF1) {
            rx_buf_.erase(rx_buf_.begin());
            continue;
        }

        size_t payload_len = body_len - 5u;
        size_t crc_index = 8u + payload_len;

        uint8_t calc = crc8Atm(rx_buf_.data(), crc_index);
        if (calc != rx_buf_[crc_index]) {
            rx_buf_.erase(rx_buf_.begin());
            continue;
        }

        JqrFrame frame;
        frame.mod_id = rx_buf_[6];
        frame.msg_id = rx_buf_[7];
        frame.payload.assign(rx_buf_.begin() + 8, rx_buf_.begin() + 8 + payload_len);
        frame.raw.assign(rx_buf_.begin(), rx_buf_.begin() + frame_len);
        out.push_back(std::move(frame));

        rx_buf_.erase(rx_buf_.begin(), rx_buf_.begin() + frame_len);
    }

    return out;
}

// 打包心跳 payload，仅包含 seq。
std::vector<uint8_t> packHeartbeat(uint8_t seq) {
    return {seq};
}

// 打包系统使能 payload，enable 转成协议约定的 0/1 字节。
std::vector<uint8_t> packSystemEnable(uint8_t seq, bool enable) {
    return {seq, static_cast<uint8_t>(enable ? 1 : 0)};
}

// 药盒是低频一次性命令，第三字节调速档位在当前GPIO驱动硬件上固定为0。
std::vector<uint8_t> packMedicineCommand(uint8_t seq, MedicineCommand command) {
    return {seq, static_cast<uint8_t>(command), 0};
}

// RGBW 直控使用千分比整数，避免 USB 协议传浮点数。
std::vector<uint8_t> packLightRgbw(uint8_t seq,
                                   uint16_t r_permille,
                                   uint16_t g_permille,
                                   uint16_t b_permille,
                                   uint16_t w_permille) {
    std::vector<uint8_t> p;
    p.reserve(9);
    p.push_back(seq);
    pushU16Le(p, r_permille);
    pushU16Le(p, g_permille);
    pushU16Le(p, b_permille);
    pushU16Le(p, w_permille);
    return p;
}

std::vector<uint8_t> packLightScene(uint8_t seq,
                                    LightScene scene,
                                    LightAmbient ambient,
                                    bool restart_pattern) {
    return {seq,
            static_cast<uint8_t>(scene),
            static_cast<uint8_t>(ambient),
            static_cast<uint8_t>(restart_pattern ? LIGHT_SCENE_FLAG_RESTART_PATTERN : 0u)};
}

// 打包清故障 payload，fault_mask 使用小端 uint32。
std::vector<uint8_t> packClearFault(uint8_t seq, uint32_t fault_mask) {
    std::vector<uint8_t> p;
    p.push_back(seq);
    pushU32Le(p, fault_mask);
    return p;
}

// 打包轮组目标 payload，字段顺序必须与 MCU 侧协议结构体保持一致。
std::vector<uint8_t> packWheelTarget(uint8_t seq,
                                     WheelMode mode,
                                     bool enable,
                                     uint16_t timeout_ms,
                                     int32_t linear_mm_s,
                                     int32_t angular_mdeg_s,
                                     int16_t left_rpm,
                                     int16_t right_rpm,
                                     uint8_t flags) {
    std::vector<uint8_t> p;
    p.reserve(20);
    p.push_back(seq);
    p.push_back(static_cast<uint8_t>(mode));
    p.push_back(static_cast<uint8_t>(enable ? 1 : 0));
    pushU16Le(p, timeout_ms);
    pushI32Le(p, linear_mm_s);
    pushI32Le(p, angular_mdeg_s);
    pushI16Le(p, left_rpm);
    pushI16Le(p, right_rpm);
    p.push_back(flags);
    pushU16Le(p, 0);
    return p;
}

// 打包头部四轴 float 目标 payload，四个位置和四个速度限制均按小端 float 发送。
std::vector<uint8_t> packHeadTargetFloat(uint8_t seq,
                                         HeadMode mode,
                                         uint8_t enable_mask,
                                         uint16_t timeout_ms,
                                         float head_pitch_deg,
                                         float neck_pitch_deg,
                                         float neck_swing_deg,
                                         float head_horizontal_deg,
                                         const std::array<float, 4>& speed_limit_deg_s,
                                         uint8_t flags) {
    std::vector<uint8_t> p;
    p.reserve(40);
    p.push_back(seq);
    p.push_back(static_cast<uint8_t>(mode));
    p.push_back(enable_mask);
    pushU16Le(p, timeout_ms);
    pushF32Le(p, head_pitch_deg);
    pushF32Le(p, neck_pitch_deg);
    pushF32Le(p, neck_swing_deg);
    pushF32Le(p, head_horizontal_deg);
    for (float s : speed_limit_deg_s) {
        pushF32Le(p, s);
    }
    p.push_back(flags);
    pushU16Le(p, 0);
    return p;
}

// 解码统一 ACK payload，长度不足时返回 false，调用方不会使用部分字段。
bool decodeAck(const std::vector<uint8_t>& payload, JqrAck& out) {
    if (payload.size() < 6) return false;
    out.seq = payload[0];
    out.req_mod = payload[1];
    out.req_msg = payload[2];
    out.status = payload[3];
    out.detail = readU16Le(payload, 4);
    return true;
}

// 解码版本上报 payload，用于业务层确认协议和固件版本。
bool decodeVersion(const std::vector<uint8_t>& payload, JqrVersion& out) {
    if (payload.size() < 14) return false;
    out.protocol_major = payload[0];
    out.protocol_minor = payload[1];
    out.firmware_major = payload[2];
    out.firmware_minor = payload[3];
    out.firmware_patch = payload[4];
    out.board_type = payload[5];
    out.build_timestamp = readU32Le(payload, 6);
    out.git_hash_short = readU32Le(payload, 10);
    return true;
}

// 解码系统状态 payload，并保留 MCU 侧上报的使能、急停、故障和在线状态。
bool decodeSystemStatus(const std::vector<uint8_t>& payload, JqrSystemStatus& out) {
    if (payload.size() < 16) return false;
    out.uptime_ms = readU32Le(payload, 0);
    out.system_enable = payload[4];
    out.estop = payload[5];
    out.bump = payload[6];
    out.fault_bitmap = readU32Le(payload, 7);
    out.usb_online = payload[11];
    out.work_mode = payload[12];
    return true;
}

// 解码锂电池 BMS 状态 payload（小端，布局与 MCU jqr_app_send_bms_status 一致）。
bool decodeBmsStatus(const std::vector<uint8_t>& payload, JqrBmsStatus& out) {
    if (payload.size() < 24) return false;
    out.online = payload[0];
    out.soc_percent = payload[1];
    out.soh_percent = payload[2];
    // payload[3] 保留对齐
    out.pack_voltage_mV = readU16Le(payload, 4);
    out.pack_current_10mA = readI16Le(payload, 6);
    out.mos_temp_c = readI16Le(payload, 8);
    for (int i = 0; i < 4; ++i) {
        out.cell_temp_c[i] = readI16Le(payload, 10 + i * 2);
    }
    out.cycle_count = readU16Le(payload, 18);
    out.protect_h = readU16Le(payload, 20);
    out.protect_l = readU16Le(payload, 22);
    return true;
}

// 解码药盒状态，布局与主MCU jqr_app_send_medicine_status 的16字节定义一致。
bool decodeMedicineStatus(const std::vector<uint8_t>& payload, JqrMedicineStatus& out) {
    if (payload.size() < 16) return false;
    out.uptime_ms = readU32Le(payload, 0);
    out.state = static_cast<MedicineState>(payload[4]);
    out.target_cmd = static_cast<MedicineCommand>(payload[5]);
    out.command_source = static_cast<MedicineCommandSource>(payload[6]);
    out.io_flags = payload[7];
    out.fault_flags = readU16Le(payload, 8);
    out.current_mA = readI16Le(payload, 10);
    out.angle_raw = readU16Le(payload, 12);
    out.last_cmd_seq = payload[14];
    out.last_result = static_cast<MedicineResult>(payload[15]);
    return true;
}

// 解码状态灯执行快照，实际输出亮度可用于联调呼吸/闪烁包络。
bool decodeLightStatus(const std::vector<uint8_t>& payload, JqrLightStatus& out) {
    if (payload.size() < 18) return false;
    out.uptime_ms = readU32Le(payload, 0);
    out.last_cmd_seq = payload[4];
    out.control_mode = static_cast<LightControlMode>(payload[5]);
    out.scene = static_cast<LightScene>(payload[6]);
    out.ambient = static_cast<LightAmbient>(payload[7]);
    out.effect = static_cast<LightEffect>(payload[8]);
    out.flags = payload[9];
    out.r_permille = readU16Le(payload, 10);
    out.g_permille = readU16Le(payload, 12);
    out.b_permille = readU16Le(payload, 14);
    out.w_permille = readU16Le(payload, 16);
    return true;
}

// 解码轮组状态 payload，速度、电流和电压字段均按协议单位输出。
bool decodeWheelStatus(const std::vector<uint8_t>& payload, JqrWheelStatus& out) {
    if (payload.size() < 22) return false;
    out.linear_mm_s = readI32Le(payload, 0);
    out.angular_mdeg_s = readI32Le(payload, 4);
    out.left_rpm = readI16Le(payload, 8);
    out.right_rpm = readI16Le(payload, 10);
    out.left_iq_mA = readI16Le(payload, 12);
    out.right_iq_mA = readI16Le(payload, 14);
    out.vbus_cV = readU16Le(payload, 16);
    out.fault_flags = readU16Le(payload, 18);
    out.state_l = payload[20];
    out.state_r = payload[21];
    return true;
}

// 解码头部四轴状态 payload，数组顺序与目标下发顺序保持一致。
bool decodeHeadStatus(const std::vector<uint8_t>& payload, JqrHeadStatus& out) {
    if (payload.size() < 40) return false;
    for (size_t i = 0; i < 4; ++i) out.position_deg[i] = readF32Le(payload, i * 4);
    for (size_t i = 0; i < 4; ++i) out.speed_deg_s[i] = readF32Le(payload, 16 + i * 4);
    for (size_t i = 0; i < 4; ++i) out.state[i] = payload[32 + i];
    for (size_t i = 0; i < 4; ++i) out.fault[i] = payload[36 + i];
    return true;
}

// 传感器状态暂按原始字节缓存，超过 SDK 固定缓存长度的部分会被截断。
bool decodeSensorStatusRaw(const std::vector<uint8_t>& payload, JqrSensorStatusRaw& out) {
    out.len = static_cast<uint16_t>(payload.size() > out.data.size() ? out.data.size() : payload.size());
    for (uint16_t i = 0; i < out.len; ++i) {
        out.data[i] = payload[i];
    }
    return true;
}

// 解码 IMU 专用上报 payload，固定为 11 个 float32 小端。
bool decodeImuReport(const std::vector<uint8_t>& payload, ImuRecvDataStruct& out) {
    if (payload.size() < 44) return false;
    out.Accel_x = readF32Le(payload, 0);
    out.Accel_y = readF32Le(payload, 4);
    out.Accel_z = readF32Le(payload, 8);
    out.Gyro_x = readF32Le(payload, 12);
    out.Gyro_y = readF32Le(payload, 16);
    out.Gyro_z = readF32Le(payload, 20);
    out.Euler_Roll = readF32Le(payload, 24);
    out.Euler_Pitch = readF32Le(payload, 28);
    out.Euler_Yaw = readF32Le(payload, 32);
    out.heading_360 = readF32Le(payload, 36);
    out.heading_180 = readF32Le(payload, 40);
    return true;
}

// 将 ACK 状态码转成字符串，方便日志和业务层调试显示。
std::string ackStatusToString(uint8_t status) {
    switch (status) {
        case 0x00: return "OK";
        case 0x01: return "CRC_ERROR";
        case 0x02: return "LEN_ERROR";
        case 0x03: return "UNSUPPORTED";
        case 0x04: return "BUSY";
        case 0x05: return "PARAM_ERROR";
        case 0x06: return "STATE_ERROR";
        case 0x07: return "TIMEOUT";
        case 0x08: return "FAULT_LOCKED";
        case 0x09: return "DISABLED";
        default: return "UNKNOWN";
    }
}

// 将已解析帧格式化为人可读文本；已知帧尽量展开关键字段，未知帧输出摘要。
std::string frameToString(const JqrFrame& frame) {
    std::ostringstream ss;
    if (frame.mod_id == MOD_SYSTEM && frame.msg_id == MSG_ACK) {
        JqrAck ack;
        if (decodeAck(frame.payload, ack)) {
            ss << "ACK: seq=" << static_cast<int>(ack.seq)
               << ", req=" << hexByte(ack.req_mod) << "/" << hexByte(ack.req_msg)
               << ", status=" << hexByte(ack.status) << "(" << ackStatusToString(ack.status) << ")"
               << ", detail=0x" << std::hex << std::uppercase << std::setw(4) << std::setfill('0') << ack.detail;
            return ss.str();
        }
    }

    if (frame.mod_id == MOD_SYSTEM && frame.msg_id == MSG_VERSION_RPT) {
        JqrVersion v;
        if (decodeVersion(frame.payload, v)) {
            ss << "VersionReport: protocol=" << static_cast<int>(v.protocol_major) << "."
               << static_cast<int>(v.protocol_minor)
               << ", firmware=" << static_cast<int>(v.firmware_major) << "."
               << static_cast<int>(v.firmware_minor) << "."
               << static_cast<int>(v.firmware_patch)
               << ", board=" << static_cast<int>(v.board_type);
            return ss.str();
        }
    }

    if (frame.mod_id == MOD_SYSTEM && frame.msg_id == MSG_SYSTEM_STATUS) {
        JqrSystemStatus s;
        if (decodeSystemStatus(frame.payload, s)) {
            ss << "SystemStatus: uptime=" << s.uptime_ms << "ms"
               << ", enable=" << static_cast<int>(s.system_enable)
               << ", fault=0x" << std::hex << std::uppercase << std::setw(8) << std::setfill('0') << s.fault_bitmap
               << std::dec << ", usb_online=" << static_cast<int>(s.usb_online)
               << ", work_mode=" << static_cast<int>(s.work_mode);
            return ss.str();
        }
    }

    if (frame.mod_id == MOD_WHEEL && frame.msg_id == MSG_WHEEL_STATUS) {
        JqrWheelStatus w;
        if (decodeWheelStatus(frame.payload, w)) {
            ss << "WheelStatus: linear=" << w.linear_mm_s
               << "mm/s, angular=" << w.angular_mdeg_s
               << "mdeg/s, L=" << w.left_rpm
               << "rpm, R=" << w.right_rpm
               << "rpm, fault=0x" << std::hex << std::uppercase << std::setw(4) << std::setfill('0') << w.fault_flags
               << std::dec << ", state=(" << static_cast<int>(w.state_l) << "," << static_cast<int>(w.state_r) << ")";
            return ss.str();
        }
    }

    if (frame.mod_id == MOD_HEAD && frame.msg_id == MSG_HEAD_STATUS_FLOAT) {
        JqrHeadStatus h;
        if (decodeHeadStatus(frame.payload, h)) {
            ss << "HeadStatus: pos=[hp=" << h.position_deg[0]
               << ", np=" << h.position_deg[1]
               << ", ns=" << h.position_deg[2]
               << ", head_horizontal=" << h.position_deg[3] << "]"
               << ", fault=[" << static_cast<int>(h.fault[0]) << ","
               << static_cast<int>(h.fault[1]) << ","
               << static_cast<int>(h.fault[2]) << ","
               << static_cast<int>(h.fault[3]) << "]";
            return ss.str();
        }
    }

    if (frame.mod_id == MOD_AUX && frame.msg_id == MSG_MEDICINE_STATUS) {
        JqrMedicineStatus m;
        if (decodeMedicineStatus(frame.payload, m)) {
            ss << "MedicineStatus: state=" << static_cast<int>(m.state)
               << ", target=" << static_cast<int>(m.target_cmd)
               << ", source=" << static_cast<int>(m.command_source)
               << ", current=" << m.current_mA << "mA"
               << ", angle_raw=" << m.angle_raw
               << ", fault=0x" << std::hex << std::uppercase
               << std::setw(4) << std::setfill('0') << m.fault_flags
               << std::dec << ", result=" << static_cast<int>(m.last_result);
            return ss.str();
        }
    }

    if (frame.mod_id == MOD_LIGHT && frame.msg_id == MSG_LIGHT_STATUS) {
        JqrLightStatus l;
        if (decodeLightStatus(frame.payload, l)) {
            ss << "LightStatus: mode=" << static_cast<int>(l.control_mode)
               << ", scene=" << static_cast<int>(l.scene)
               << ", ambient=" << static_cast<int>(l.ambient)
               << ", effect=" << static_cast<int>(l.effect)
               << ", rgbw=[" << l.r_permille << "," << l.g_permille
               << "," << l.b_permille << "," << l.w_permille << "]";
            return ss.str();
        }
    }

    if (frame.mod_id == MOD_SENSOR && frame.msg_id == MSG_IMU_REPORT) {
        ImuRecvDataStruct imu;
        if (decodeImuReport(frame.payload, imu)) {
            ss << "ImuReport: accel=[" << imu.Accel_x << "," << imu.Accel_y << "," << imu.Accel_z
               << "]g, gyro=[" << imu.Gyro_x << "," << imu.Gyro_y << "," << imu.Gyro_z
               << "]dps, euler=[" << imu.Euler_Roll << "," << imu.Euler_Pitch << "," << imu.Euler_Yaw
               << "], heading=[" << imu.heading_360 << "," << imu.heading_180 << "]";
            return ss.str();
        }
    }

    ss << "RX: mod=" << hexByte(frame.mod_id) << ", msg=" << hexByte(frame.msg_id)
       << ", payload_len=" << frame.payload.size();
    return ss.str();
}

} // namespace jqr
