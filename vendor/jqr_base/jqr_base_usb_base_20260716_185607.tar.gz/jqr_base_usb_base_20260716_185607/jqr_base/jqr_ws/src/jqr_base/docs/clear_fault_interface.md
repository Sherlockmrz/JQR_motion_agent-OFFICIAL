# Clear fault ROS 2 interface

The base controller exposes MCU fault clearing as a service because the operation is
synchronous and callers need to know whether the MCU acknowledged it.

## Interface

- Service name: `/clear_fault`
- Service type: `jqr_ros_msgs/srv/ClearFault`
- Request: `fault_mask` selects the fault bits to clear
- Response: `result_number` is `1` on MCU ACK and `0` on rejection, timeout, or send failure

Clear all fault bits:

```bash
ros2 service call /clear_fault jqr_ros_msgs/srv/ClearFault \
  "{fault_mask: 4294967295}"
```

Clear selected bits, for example bits 0 and 2:

```bash
ros2 service call /clear_fault jqr_ros_msgs/srv/ClearFault \
  "{fault_mask: 5}"
```

Clearing a fault does not bypass its physical cause. A fault that is still active may
remain set or be reported again by the MCU.
