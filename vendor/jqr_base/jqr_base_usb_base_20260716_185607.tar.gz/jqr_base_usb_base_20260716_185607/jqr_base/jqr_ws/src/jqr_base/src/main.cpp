#include "jqr_base/base_controller.hpp"
#include <rclcpp/rclcpp.hpp>

namespace {
const std::string KJqrBaseVersion = "1.3.2";
}

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  
  auto node = std::make_shared<jqr_base::BaseController>();
  rclcpp::executors::MultiThreadedExecutor executor;   //add
  
  RCLCPP_INFO(node->get_logger(), "Starting JQR Base Node");
  RCLCPP_INFO(node->get_logger(), "JQR Base Version: %s", KJqrBaseVersion.c_str());
  
  executor.add_node(node);
  executor.spin();
  //rclcpp::spin(node);
  rclcpp::shutdown();
  
  return 0;
}