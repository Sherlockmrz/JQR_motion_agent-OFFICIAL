#!/usr/bin/env python3
"""ROS 2 test client for MCU fault, medicine-box, and status-light services."""

import argparse
import sys
import time

import rclpy
from rclpy.node import Node

from jqr_ros_msgs.srv import ClearFault
from jqr_ros_msgs.srv import MedicineBoxCommand
from jqr_ros_msgs.srv import MedicineBoxStatus
from jqr_ros_msgs.srv import StatusLightScene
from jqr_ros_msgs.srv import StatusLightState


SERVICES = {
    "clear_fault": (ClearFault, "clear_fault"),
    "medicine_command": (MedicineBoxCommand, "set_medicine_box_command"),
    "medicine_status": (MedicineBoxStatus, "get_medicine_box_status"),
    "light_scene": (StatusLightScene, "set_status_light_scene"),
    "light_status": (StatusLightState, "get_status_light_state"),
}

MEDICINE_COMMANDS = {"stop": 0, "open": 1, "close": 2}
MEDICINE_STATES = {
    0: "UNINIT", 1: "UNKNOWN", 2: "CLOSED", 3: "OPENING",
    4: "OPEN", 5: "CLOSING", 6: "STOPPED", 7: "FAULT",
}
LIGHT_SCENES = {
    "off": 0, "waiting": 1, "working": 2, "safety_alert": 3,
    "fault": 4, "estop": 5, "low_battery": 6,
    "critical_battery": 7, "charging": 8, "upgrading": 9,
    "pairing": 10,
}
LIGHT_EFFECTS = {0: "OFF", 1: "STEADY", 2: "BLINK", 3: "BREATHE"}


class McuAuxTester(Node):
    def __init__(self, namespace, service_timeout):
        super().__init__("mcu_aux_test")
        self.service_timeout = service_timeout
        prefix = "/" + namespace.strip("/") if namespace.strip("/") else ""
        self.service_clients = {
            key: self.create_client(srv_type, prefix + "/" + name)
            for key, (srv_type, name) in SERVICES.items()
        }

    def wait_for_service(self, key):
        client = self.service_clients[key]
        if client.wait_for_service(timeout_sec=self.service_timeout):
            return True
        print("[FAIL] service unavailable: {}".format(client.srv_name))
        return False

    def call(self, key, request):
        if not self.wait_for_service(key):
            return None
        future = self.service_clients[key].call_async(request)
        rclpy.spin_until_future_complete(
            self, future, timeout_sec=self.service_timeout)
        if not future.done():
            print("[FAIL] service timeout: {}".format(
                self.service_clients[key].srv_name))
            return None
        try:
            return future.result()
        except Exception as exc:  # pragma: no cover - depends on ROS transport
            print("[FAIL] service call raised: {}".format(exc))
            return None


def print_medicine_status(response):
    print(
        "medicine: valid={} state={}({}) target={} source={} seq={} "
        "fault=0x{:04x} result={} current={}mA angle_raw={} "
        "io=0x{:02x}".format(
            response.valid,
            response.state,
            MEDICINE_STATES.get(response.state, "INVALID"),
            response.target_command,
            response.command_source,
            response.last_command_seq,
            response.fault_flags,
            response.last_result,
            response.current_ma,
            response.angle_raw,
            response.io_flags,
        )
    )


def print_light_status(response):
    scene_name = next(
        (name.upper() for name, value in LIGHT_SCENES.items()
         if value == response.scene),
        "INVALID",
    )
    print(
        "light: valid={} mode={} scene={}({}) ambient={} effect={}({}) "
        "seq={} flags=0x{:02x} rgbw=[{},{},{},{}]".format(
            response.valid,
            response.control_mode,
            response.scene,
            scene_name,
            response.ambient,
            response.effect,
            LIGHT_EFFECTS.get(response.effect, "INVALID"),
            response.last_command_seq,
            response.flags,
            response.r_permille,
            response.g_permille,
            response.b_permille,
            response.w_permille,
        )
    )


def command_check(node, _args):
    failed = False
    for key in SERVICES:
        client = node.service_clients[key]
        available = client.wait_for_service(timeout_sec=node.service_timeout)
        print("[{}] {}".format(
            "PASS" if available else "FAIL", client.srv_name))
        failed = failed or not available
    return 2 if failed else 0


def command_status(node, _args):
    medicine = node.call("medicine_status", MedicineBoxStatus.Request())
    light = node.call("light_status", StatusLightState.Request())
    if medicine is None or light is None:
        return 2
    print_medicine_status(medicine)
    print_light_status(light)
    if not medicine.valid or not light.valid:
        print(
            "[FAIL] MCU status cache is not valid; "
            "check USB connection and MCU reports")
        return 3
    print("[PASS] medicine-box and status-light reports are valid")
    return 0


def command_clear_fault(node, args):
    request = ClearFault.Request()
    request.fault_mask = args.mask
    response = node.call("clear_fault", request)
    if response is None:
        return 2
    ok = response.result_number.data == 1
    print("[{}] {}".format("PASS" if ok else "FAIL", response.result_msg.data))
    return 0 if ok else 2


def medicine_finished(status, command):
    if command == MEDICINE_COMMANDS["open"]:
        return status.state == 4
    if command == MEDICINE_COMMANDS["close"]:
        return status.state == 2
    return status.state not in (3, 5)


def command_medicine(node, args):
    command = MEDICINE_COMMANDS[args.command]
    request = MedicineBoxCommand.Request()
    request.command = command
    response = node.call("medicine_command", request)
    if response is None:
        return 2
    print("medicine ACK: accepted={} seq={} message={}".format(
        response.accepted, response.command_seq, response.message))
    if not response.accepted:
        return 2
    if not args.wait:
        print("[PASS] command acknowledged; completion was not requested")
        return 0

    deadline = time.monotonic() + args.timeout
    while rclpy.ok() and time.monotonic() < deadline:
        status = node.call("medicine_status", MedicineBoxStatus.Request())
        if status is None:
            return 2
        print_medicine_status(status)
        current_command = (
            status.valid
            and status.command_source == 2
            and status.last_command_seq == response.command_seq
            and status.target_command == command
        )
        if current_command and status.state == 7:
            print("[FAIL] medicine box entered FAULT, flags=0x{:04x}".format(
                status.fault_flags))
            return 3
        if current_command and medicine_finished(status, command):
            print("[PASS] matching MCU completion status received")
            return 0
        time.sleep(0.1)
    print("[FAIL] timed out waiting for medicine-box completion")
    return 3


def command_light(node, args):
    request = StatusLightScene.Request()
    request.scene = LIGHT_SCENES[args.scene]
    request.ambient = 0 if args.ambient == "day" else 1
    request.restart_pattern = args.restart
    response = node.call("light_scene", request)
    if response is None:
        return 2
    print("light ACK: accepted={} message={}".format(
        response.accepted, response.message))
    if not response.accepted:
        return 2
    if not args.verify:
        print(
            "[PASS] scene command acknowledged; "
            "state verification was not requested")
        return 0

    deadline = time.monotonic() + args.timeout
    while rclpy.ok() and time.monotonic() < deadline:
        status = node.call("light_status", StatusLightState.Request())
        if status is None:
            return 2
        print_light_status(status)
        mode_matches = status.control_mode == 2 or (
            request.scene == LIGHT_SCENES["off"] and status.control_mode == 0)
        if (status.valid and mode_matches
                and status.scene == request.scene
                and status.ambient == request.ambient):
            print("[PASS] MCU reports the requested status-light scene")
            return 0
        time.sleep(0.1)
    print("[FAIL] timed out waiting for status-light scene feedback")
    return 3


def parse_mask(value):
    try:
        parsed = int(value, 0)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            "mask must be decimal or 0x-prefixed") from exc
    if not 0 <= parsed <= 0xFFFFFFFF:
        raise argparse.ArgumentTypeError("mask must fit uint32")
    return parsed


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--namespace", default="", help="base node namespace")
    parser.add_argument(
        "--service-timeout", type=float, default=3.0,
        help=(
            "seconds to wait for discovery and each service response "
            "(default: 3)"))
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    check = subparsers.add_parser("check", help="check service discovery only")
    check.set_defaults(handler=command_check)

    status = subparsers.add_parser(
        "status", help="read both MCU status services")
    status.set_defaults(handler=command_status)

    clear_fault = subparsers.add_parser("clear-fault", help="clear MCU faults")
    clear_fault.add_argument("--mask", required=True, type=parse_mask)
    clear_fault.set_defaults(handler=command_clear_fault)

    medicine = subparsers.add_parser(
        "medicine", help="control the medicine box")
    medicine.add_argument("command", choices=sorted(MEDICINE_COMMANDS))
    medicine.add_argument(
        "--wait", action="store_true", help="wait for matching completion")
    medicine.add_argument("--timeout", type=float, default=12.0)
    medicine.set_defaults(handler=command_medicine)

    light = subparsers.add_parser(
        "light", help="set a product status-light scene")
    light.add_argument("scene", choices=sorted(LIGHT_SCENES))
    light.add_argument("--ambient", choices=("day", "night"), default="day")
    light.add_argument("--restart", action="store_true")
    light.add_argument(
        "--verify", action="store_true", help="verify MCU scene feedback")
    light.add_argument("--timeout", type=float, default=3.0)
    light.set_defaults(handler=command_light)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.service_timeout <= 0:
        print("--service-timeout must be greater than zero", file=sys.stderr)
        return 2
    if hasattr(args, "timeout") and args.timeout <= 0:
        print("--timeout must be greater than zero", file=sys.stderr)
        return 2

    rclpy.init(args=None)
    node = McuAuxTester(args.namespace, args.service_timeout)
    try:
        return args.handler(node, args)
    except KeyboardInterrupt:
        print("interrupted")
        return 130
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    sys.exit(main())
