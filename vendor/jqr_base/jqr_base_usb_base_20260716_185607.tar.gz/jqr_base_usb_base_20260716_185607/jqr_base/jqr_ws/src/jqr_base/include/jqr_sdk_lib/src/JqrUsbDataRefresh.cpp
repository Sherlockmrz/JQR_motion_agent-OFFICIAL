#include "JqrUsbDataRefresh.h"

#include <algorithm>
#include <chrono>
#include <iostream>
#include <thread>
#include <utility>

#include "JqrThreadUtil.h"

namespace jqr {

using Clock = std::chrono::steady_clock;

// 析构时主动停止通信，防止对象销毁后后台线程继续访问成员变量。
JqrUsbDataRefresh::~JqrUsbDataRefresh() {
    stop();
}

// 返回 SDK 本地单调毫秒计时，所有本地延迟、超时和新鲜度判断都使用该时间基准。
uint32_t JqrUsbDataRefresh::localMs() {
    static const auto t0 = Clock::now();
    auto now = Clock::now();
    return static_cast<uint32_t>(std::chrono::duration_cast<std::chrono::milliseconds>(now - t0).count());
}

// 判断周期是否到期，使用 uint32_t 差值以兼容毫秒计数自然回绕。
bool JqrUsbDataRefresh::elapsed(uint32_t now, uint32_t last, uint32_t period) {
    return static_cast<uint32_t>(now - last) >= period;
}

// 计算两个本地毫秒时间戳的差值，用于统计 SetTarget 到实际写 USB 的延迟。
uint32_t JqrUsbDataRefresh::diffMs(uint32_t now, uint32_t last) {
    return static_cast<uint32_t>(now - last);
}

// 启动串口、协议解析器和三个后台线程，是 SDK 从未运行进入运行状态的唯一入口。
bool JqrUsbDataRefresh::start(const JqrSdkConfig& cfg) {
    if (running_.load()) {
        return true;
    }

    cfg_ = cfg;
    mcu_online_.store(false);
    invalidateMedicineStatusCache();
    invalidateLightStatusCache();

    std::string mem_warn = JqrThreadUtil::lockMemoryIfEnabled(cfg_.realtime.enable_mlockall);
    if (!mem_warn.empty()) {
        std::cerr << mem_warn << std::endl;
    }

    {
        std::lock_guard<std::mutex> lk(serial_mtx_);
        if (!openSerialLocked()) {
            return false;
        }
    }

    running_.store(true);
    serial_need_reopen_.store(false);

    rx_thread_ = std::thread(&JqrUsbDataRefresh::rxLoop, this);
    tx_thread_ = std::thread(&JqrUsbDataRefresh::txLoop, this);
    watchdog_thread_ = std::thread(&JqrUsbDataRefresh::watchdogLoop, this);

    /*
     * 旧 EIP SDK 曾经因为线程优先级低导致通信超时。
     * 这里提供同样能力，但默认关闭，避免开发机权限不足。
     */
    if (cfg_.realtime.enable_realtime) {
        auto w1 = JqrThreadUtil::applyRealtimeToThread(rx_thread_, "jqr_rx",
                                                       cfg_.realtime.rx_thread_priority,
                                                       cfg_.realtime.enable_cpu_affinity,
                                                       cfg_.realtime.rx_thread_cpu);
        auto w2 = JqrThreadUtil::applyRealtimeToThread(tx_thread_, "jqr_tx",
                                                       cfg_.realtime.tx_thread_priority,
                                                       cfg_.realtime.enable_cpu_affinity,
                                                       cfg_.realtime.tx_thread_cpu);
        auto w3 = JqrThreadUtil::applyRealtimeToThread(watchdog_thread_, "jqr_watchdog",
                                                       cfg_.realtime.watchdog_thread_priority,
                                                       cfg_.realtime.enable_cpu_affinity,
                                                       cfg_.realtime.watchdog_thread_cpu);

        if (!w1.empty()) std::cerr << w1 << std::endl;
        if (!w2.empty()) std::cerr << w2 << std::endl;
        if (!w3.empty()) std::cerr << w3 << std::endl;
    }

    // 给 RX/TX 线程一点启动时间，避免 init 后第一条命令太早发出。
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    auto init_deadline = Clock::now() + std::chrono::milliseconds(cfg_.status_timeout_ms);
    while (running_.load() && Clock::now() < init_deadline) {
        {
            std::lock_guard<std::mutex> lk(cache_mtx_);
            if (head_target_.initialized) {
                break;
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    return true;
}

// 停止 RX/TX/Watchdog 线程并关闭串口；多次调用是安全的。
void JqrUsbDataRefresh::stop() {
    if (!running_.exchange(false)) {
        mcu_online_.store(false);
        invalidateMedicineStatusCache();
        invalidateLightStatusCache();
        return;
    }

    tx_cv_.notify_all();

    if (rx_thread_.joinable()) rx_thread_.join();
    if (tx_thread_.joinable()) tx_thread_.join();
    if (watchdog_thread_.joinable()) watchdog_thread_.join();

    {
        std::lock_guard<std::mutex> lk(serial_mtx_);
        serial_.close();
    }
    mcu_online_.store(false);
    invalidateMedicineStatusCache();
    invalidateLightStatusCache();
}

// 设置原始帧回调；回调保存时加锁，触发时会先拷贝出来再调用。
void JqrUsbDataRefresh::setFrameCallback(FrameCallback cb) {
    std::lock_guard<std::mutex> lk(cb_mtx_);
    frame_cb_ = std::move(cb);
}

// 为同步控制命令生成全局非零 seq；0 作为无效值保留不用。
uint8_t JqrUsbDataRefresh::nextSeq() {
    std::lock_guard<std::mutex> lk(tx_mtx_);
    uint8_t s = seq_++;
    if (seq_ == 0) seq_ = 1;
    return s;
}

// 为周期目标的独立 wire_seq 递增到下一个非零值。
uint8_t JqrUsbDataRefresh::nextNonZeroSeq(uint8_t s) {
    ++s;
    if (s == 0) {
        s = 1;
    }
    return s;
}

// 在 serial_mtx_ 已加锁的前提下打开串口并清空协议解析器缓存。
bool JqrUsbDataRefresh::openSerialLocked() {
    if (!serial_.open(cfg_.device, cfg_.baudrate)) {
        std::cerr << "Serial open failed: " << serial_.lastError() << std::endl;
        return false;
    }

    parser_.reset();
    return true;
}

// TX 线程统一写帧入口：组帧、串口写入、统计和错误标记都集中在这里完成。
bool JqrUsbDataRefresh::writeFrameFromTxThread(uint8_t mod_id, uint8_t msg_id, const std::vector<uint8_t>& payload) {
    auto frame = buildFrame(mod_id, msg_id, payload);
    if (frame.empty()) return false;

    std::lock_guard<std::mutex> ser_lk(serial_mtx_);

    if (!serial_.isOpen()) {
        std::lock_guard<std::mutex> st_lk(stats_mtx_);
        stats_.serial_error_count++;
        stats_.usb_tx_fail_count++;
        return false;
    }

    bool ok = serial_.writeAll(frame);
    {
        std::lock_guard<std::mutex> st_lk(stats_mtx_);
        if (ok) {
            stats_.tx_frame_count++;
            stats_.last_tx_ms = localMs();
        } else {
            stats_.serial_error_count++;
            stats_.usb_tx_fail_count++;
            serial_need_reopen_.store(true);
        }
    }

    return ok;
}

// 将普通命令放入 TX 队列，并唤醒 TX 线程尽快写出。
bool JqrUsbDataRefresh::queueRawFrame(uint8_t mod_id, uint8_t msg_id, const std::vector<uint8_t>& payload) {
    if (!running_.load()) {
        return false;
    }

    if (buildFrame(mod_id, msg_id, payload).empty()) {
        return false;
    }

    {
        std::lock_guard<std::mutex> lk(tx_queue_mtx_);
        tx_queue_.push_back(TxCommand{mod_id, msg_id, payload});
    }

    tx_cv_.notify_one();
    return true;
}

// 从 TX 队列取出一条命令；队列为空时返回 false。
bool JqrUsbDataRefresh::dequeueTxCommand(TxCommand& out) {
    std::lock_guard<std::mutex> lk(tx_queue_mtx_);
    if (tx_queue_.empty()) {
        return false;
    }

    out = std::move(tx_queue_.front());
    tx_queue_.pop_front();
    return true;
}

// 用最近一次 HeadStatus 初始化头部 target cache，保证单轴控制不会把其他轴写成 0。
bool JqrUsbDataRefresh::initHeadTargetFromFeedbackLocked(uint32_t now_ms) {
    if (!has_head_status_) {
        return false;
    }

    head_target_.target_deg = head_status_.position_deg;
    head_target_.speed_limit = 30.0f;
    head_target_.initialized = true;
    head_target_.update_ms = now_ms;
    return true;
}

// 发送需要确认的普通命令，并等待 seq/mod/msg 完全匹配的 ACK。
bool JqrUsbDataRefresh::sendCommandWaitAck(uint8_t mod_id, uint8_t msg_id,
                                           const std::vector<uint8_t>& payload,
                                           uint8_t seq,
                                           JqrAck* ack_out,
                                           int timeout_ms) {
    if (!running_.load() || buildFrame(mod_id, msg_id, payload).empty()) {
        return false;
    }

    {
        std::unique_lock<std::mutex> lk(ack_mtx_);

        // 第一版只允许一个前台阻塞命令等待 ACK，避免 ACK 匹配互相覆盖。
        if (waiting_ack_) {
            return false;
        }

        waiting_ack_ = true;
        ack_matched_ = false;
        pending_seq_ = seq;
        pending_mod_ = mod_id;
        pending_msg_ = msg_id;
        pending_ack_ = {};
    }

    {
        std::lock_guard<std::mutex> lk(tx_queue_mtx_);
        tx_queue_.push_back(TxCommand{mod_id, msg_id, payload});
    }
    tx_cv_.notify_one();

    std::unique_lock<std::mutex> lk(ack_mtx_);
    bool ok = ack_cv_.wait_for(lk, std::chrono::milliseconds(timeout_ms), [&]() {
        return ack_matched_;
    });

    waiting_ack_ = false;

    if (!ok) {
        std::lock_guard<std::mutex> st_lk(stats_mtx_);
        stats_.ack_timeout_count++;
        return false;
    }

    if (ack_out != nullptr) {
        *ack_out = pending_ack_;
    }

    return pending_ack_.status == static_cast<uint8_t>(AckStatus::OK);
}

// 发送心跳；周期心跳由 TX 线程直接写，手动心跳可选择等待 ACK。
bool JqrUsbDataRefresh::sendHeartbeat(bool wait_ack) {
    uint8_t seq = nextSeq();
    auto payload = packHeartbeat(seq);

    if (!wait_ack) {
        bool ok = writeFrameFromTxThread(MOD_SYSTEM, MSG_HEARTBEAT, payload);
        if (ok) {
            std::lock_guard<std::mutex> st_lk(stats_mtx_);
            stats_.heartbeat_tx_count++;
        }
        return ok;
    }

    JqrAck ack;
    return sendCommandWaitAck(MOD_SYSTEM, MSG_HEARTBEAT, payload, seq, &ack, 1000);
}

// 同步下发系统使能/失能命令，业务层可用返回值判断 MCU 是否接受。
bool JqrUsbDataRefresh::setSystemEnable(bool enable) {
    if (!enable) {
        /*
         * 失能是安全边界：必须先在 SDK 本地停止 Head/Wheel 周期 target，
         * 再把 SystemDisable 放入 TX 队列。
         *
         * 如果先发送 SystemDisable、ACK 后再清缓存，TX 线程可能在同一轮循环里
         * 先处理 disable 命令，再继续发送一帧周期 HeadTarget/WheelTarget，
         * MCU 会因已失能返回 ACK_DISABLED，导致 disable 后 head_tx 增加、ack_err 增加。
         */
        std::lock_guard<std::mutex> lk(cache_mtx_);
        uint32_t now = localMs();

        head_target_.valid = false;
        head_target_.initialized = false;
        head_target_.update_ms = now;
        head_target_.cache_version++;
        head_target_.sent_version = head_target_.cache_version;

        wheel_target_.valid = false;
        wheel_target_.enable = false;
        wheel_target_.mode = WheelMode::STOP;
        wheel_target_.flags = 0;
        wheel_target_.linear_mm_s = 0;
        wheel_target_.angular_mdeg_s = 0;
        wheel_target_.left_rpm = 0;
        wheel_target_.right_rpm = 0;
        wheel_target_.update_ms = now;
        wheel_target_.cache_version++;
        wheel_target_.sent_version = wheel_target_.cache_version;
    }

    uint8_t seq = nextSeq();
    auto payload = packSystemEnable(seq, enable);
    JqrAck ack;
    return sendCommandWaitAck(MOD_SYSTEM, MSG_SYSTEM_ENABLE, payload, seq, &ack, 1000);
}

// 同步下发清故障命令，mask 可选择清除全部或部分故障位。
bool JqrUsbDataRefresh::clearFault(uint32_t mask) {
    uint8_t seq = nextSeq();
    auto payload = packClearFault(seq, mask);
    JqrAck ack;
    return sendCommandWaitAck(MOD_SYSTEM, MSG_CLEAR_FAULT, payload, seq, &ack, 1000);
}

// 查询版本时先清除旧版本标志，再等待新的版本上报帧刷新缓存。
bool JqrUsbDataRefresh::getVersion(JqrVersion& out) {
    uint8_t seq = nextSeq();

    {
        std::lock_guard<std::mutex> lk(cache_mtx_);
        has_version_ = false;
    }

    auto payload = packHeartbeat(seq); // GetVersion payload 只有 seq。
    if (!queueRawFrame(MOD_SYSTEM, MSG_GET_VERSION, payload)) {
        return false;
    }

    std::unique_lock<std::mutex> lk(version_mtx_);
    bool ok = version_cv_.wait_for(lk, std::chrono::milliseconds(1500), [&]() {
        std::lock_guard<std::mutex> cache_lk(cache_mtx_);
        return has_version_;
    });

    if (!ok) return false;

    std::lock_guard<std::mutex> cache_lk(cache_mtx_);
    out = version_;
    return true;
}

// 写入头部完整 4 轴最新目标缓存；真正的 wire_seq 分配和 USB 写出由 TX 线程完成。
bool JqrUsbDataRefresh::setHeadTarget(float hp, float np, float ns, float head_horizontal,
                                      float speed_limit) {
    {
        std::lock_guard<std::mutex> lk(cache_mtx_);

        head_target_.valid = true;
        head_target_.initialized = true;
        head_target_.target_deg[0] = hp;
        head_target_.target_deg[1] = np;
        head_target_.target_deg[2] = ns;
        head_target_.target_deg[3] = head_horizontal;
        head_target_.speed_limit = speed_limit;
        head_target_.update_ms = localMs();
        head_target_.cache_version++;
    }

    tx_cv_.notify_one();
    return true;
}

// 更新头部单轴目标；其他轴来自已初始化的 latest target cache。
bool JqrUsbDataRefresh::setHeadAxisTarget(HeadAxis axis, float target_deg, float speed_limit) {
    uint8_t idx = static_cast<uint8_t>(axis);
    if (idx >= 4u) {
        return false;
    }

    {
        std::lock_guard<std::mutex> lk(cache_mtx_);
        uint32_t now = localMs();
        if (!head_target_.initialized && !initHeadTargetFromFeedbackLocked(now)) {
            return false;
        }

        head_target_.valid = true;
        head_target_.target_deg[idx] = target_deg;
        head_target_.speed_limit = speed_limit;
        head_target_.update_ms = now;
        head_target_.cache_version++;
    }

    tx_cv_.notify_one();
    return true;
}

// ClearHeadTarget 语义等同 StopHead：立即发 STOP，而不是只停止 SDK 周期兜底。
bool JqrUsbDataRefresh::clearHeadTarget() {
    return stopHead();
}

// 立即发送 Head STOP，不等待同步 ACK；ACK 由 RX 线程异步更新 last_head_target_ack_。
bool JqrUsbDataRefresh::stopHead() {
    uint8_t seq = 0;
    std::array<float, 4> target{{0, 0, 0, 0}};
    std::array<float, 4> speed{{0, 0, 0, 0}};
    {
        std::lock_guard<std::mutex> lk(cache_mtx_);
        head_target_.valid = false;
        head_target_.update_ms = localMs();
        head_target_.cache_version++;
        head_target_.wire_seq = nextNonZeroSeq(head_target_.wire_seq);
        head_target_.sent_version = head_target_.cache_version;
        seq = head_target_.wire_seq;
        if (head_target_.initialized) {
            target = head_target_.target_deg;
        }
    }

    auto payload = packHeadTargetFloat(seq, HeadMode::STOP, 0x00,
                                       cfg_.head_target_timeout_ms,
                                       target[0], target[1], target[2], target[3],
                                       speed, 0);
    return queueRawFrame(MOD_HEAD, MSG_HEAD_TARGET_FLOAT, payload);
}

// 写入轮组底盘速度目标缓存；线速度和角速度由 MCU 侧按 CHASSIS 模式解释。
bool JqrUsbDataRefresh::setChassisVelocity(int32_t linear_mm_s, int32_t angular_mdeg_s) {
    {
        std::lock_guard<std::mutex> lk(cache_mtx_);

        wheel_target_.valid = true;
        wheel_target_.mode = WheelMode::CHASSIS;
        wheel_target_.enable = true;
        wheel_target_.flags = 0;
        wheel_target_.linear_mm_s = linear_mm_s;
        wheel_target_.angular_mdeg_s = angular_mdeg_s;
        wheel_target_.left_rpm = 0;
        wheel_target_.right_rpm = 0;
        wheel_target_.update_ms = localMs();
        wheel_target_.cache_version++;
    }

    tx_cv_.notify_one();
    return true;
}

// 停止轮组时立即构造 STOP 目标并同步等待 ACK，避免旧周期目标继续补发。
bool JqrUsbDataRefresh::stopWheel() {
    uint8_t seq = 0;
    {
        std::lock_guard<std::mutex> lk(cache_mtx_);
        wheel_target_.valid = false;
        wheel_target_.enable = false;
        wheel_target_.mode = WheelMode::STOP;
        wheel_target_.linear_mm_s = 0;
        wheel_target_.angular_mdeg_s = 0;
        wheel_target_.left_rpm = 0;
        wheel_target_.right_rpm = 0;
        wheel_target_.update_ms = localMs();
        wheel_target_.cache_version++;
        wheel_target_.wire_seq = nextNonZeroSeq(wheel_target_.wire_seq);
        wheel_target_.sent_version = wheel_target_.cache_version;
        seq = wheel_target_.wire_seq;
    }

    // StopWheel 是立即安全命令，发送一次 STOP。
    auto payload = packWheelTarget(seq, WheelMode::STOP, false,
                                   cfg_.wheel_target_timeout_ms, 0, 0, 0, 0);
    JqrAck ack;
    return sendCommandWaitAck(MOD_WHEEL, MSG_WHEEL_TARGET, payload, seq, &ack, 1000);
}

// 兼容旧接口：忽略seq，但仍复用可关联结果的新实现。
bool JqrUsbDataRefresh::setMedicineCommand(MedicineCommand command) {
    uint8_t seq = 0;
    return setMedicineCommand(command, seq);
}

// 药盒是低频一次性动作；返回seq供业务层关联后续异步状态。
bool JqrUsbDataRefresh::setMedicineCommand(MedicineCommand command, uint8_t& seq_out) {
    seq_out = 0;
    uint8_t value = static_cast<uint8_t>(command);
    if (value > static_cast<uint8_t>(MedicineCommand::CLOSE)) {
        return false;
    }

    uint8_t seq = nextSeq();
    seq_out = seq;
    auto payload = packMedicineCommand(seq, command);
    JqrAck ack;
    return sendCommandWaitAck(MOD_AUX, MSG_MEDICINE_COMMAND,
                              payload, seq, &ack, 1000);
}

bool JqrUsbDataRefresh::setLightScene(LightScene scene,
                                      LightAmbient ambient,
                                      bool restart_pattern) {
    if (static_cast<uint8_t>(scene) > static_cast<uint8_t>(LightScene::PAIRING) ||
        static_cast<uint8_t>(ambient) > static_cast<uint8_t>(LightAmbient::NIGHT)) {
        return false;
    }

    uint8_t seq = nextSeq();
    auto payload = packLightScene(seq, scene, ambient, restart_pattern);
    JqrAck ack;
    return sendCommandWaitAck(MOD_LIGHT, MSG_LIGHT_SET_SCENE,
                              payload, seq, &ack, 1000);
}

bool JqrUsbDataRefresh::setLightRgbw(uint16_t r_permille,
                                     uint16_t g_permille,
                                     uint16_t b_permille,
                                     uint16_t w_permille) {
    if (r_permille > 1000u || g_permille > 1000u ||
        b_permille > 1000u || w_permille > 1000u) {
        return false;
    }

    uint8_t seq = nextSeq();
    auto payload = packLightRgbw(seq, r_permille, g_permille, b_permille, w_permille);
    JqrAck ack;
    return sendCommandWaitAck(MOD_LIGHT, MSG_LIGHT_SET_RGBW,
                              payload, seq, &ack, 1000);
}

// 链路生命周期变化时使药盒缓存失效；下一帧有效状态到达后再重新置位。
void JqrUsbDataRefresh::invalidateMedicineStatusCache() {
    std::lock_guard<std::mutex> lk(cache_mtx_);
    medicine_status_ = {};
    has_medicine_status_ = false;
}

void JqrUsbDataRefresh::invalidateLightStatusCache() {
    std::lock_guard<std::mutex> lk(cache_mtx_);
    light_status_ = {};
    has_light_status_ = false;
}

// 拷贝最近一次系统状态缓存；未收到过状态时返回 false。
bool JqrUsbDataRefresh::getSystemStatus(JqrSystemStatus& out) const {
    std::lock_guard<std::mutex> lk(cache_mtx_);
    if (!has_system_status_) return false;
    out = system_status_;
    return true;
}

// 拷贝最近一次锂电池 BMS 状态缓存；调用方可用 update_ms_local 判断新鲜度。
bool JqrUsbDataRefresh::getBmsStatus(JqrBmsStatus& out) const {
    std::lock_guard<std::mutex> lk(cache_mtx_);
    if (!has_bms_status_) return false;
    out = bms_status_;
    return true;
}

// 读取药盒状态缓存；动作完成以 state/last_result/fault_flags 为准。
bool JqrUsbDataRefresh::getMedicineStatus(JqrMedicineStatus& out) const {
    std::lock_guard<std::mutex> lk(cache_mtx_);
    if (!has_medicine_status_) return false;
    out = medicine_status_;
    return true;
}

bool JqrUsbDataRefresh::getLightStatus(JqrLightStatus& out) const {
    std::lock_guard<std::mutex> lk(cache_mtx_);
    if (!has_light_status_) return false;
    out = light_status_;
    return true;
}

// 拷贝最近一次轮组状态缓存；调用方可检查 update_ms_local 判断是否滞后。
bool JqrUsbDataRefresh::getWheelStatus(JqrWheelStatus& out) const {
    std::lock_guard<std::mutex> lk(cache_mtx_);
    if (!has_wheel_status_) return false;
    out = wheel_status_;
    return true;
}

// 拷贝最近一次头部状态缓存；状态由 RX 线程异步刷新。
bool JqrUsbDataRefresh::getHeadStatus(JqrHeadStatus& out) const {
    std::lock_guard<std::mutex> lk(cache_mtx_);
    if (!has_head_status_) return false;
    out = head_status_;
    return true;
}

// 拷贝最近一次传感器原始状态缓存；SDK 不解释具体传感器矩阵。
bool JqrUsbDataRefresh::getSensorStatusRaw(JqrSensorStatusRaw& out) const {
    std::lock_guard<std::mutex> lk(cache_mtx_);
    if (!has_sensor_status_) return false;
    out = sensor_status_;
    return true;
}

// 拷贝最近一次 IMU 专用上报缓存。
bool JqrUsbDataRefresh::getImuData(ImuRecvDataStruct& out) const {
    std::lock_guard<std::mutex> lk(cache_mtx_);
    if (!has_imu_data_) return false;
    out = imu_data_;
    return true;
}

// 读取轮组目标异步 ACK 缓存；count 为 0 表示还没有任何目标 ACK。
bool JqrUsbDataRefresh::getLastWheelTargetAck(TargetAckStatus& out) const {
    std::lock_guard<std::mutex> lk(cache_mtx_);
    if (last_wheel_target_ack_.count == 0) return false;
    out = last_wheel_target_ack_;
    return true;
}

// 读取头部目标异步 ACK 缓存；status 需要由业务层判断是否 OK。
bool JqrUsbDataRefresh::getLastHeadTargetAck(TargetAckStatus& out) const {
    std::lock_guard<std::mutex> lk(cache_mtx_);
    if (last_head_target_ack_.count == 0) return false;
    out = last_head_target_ack_;
    return true;
}

// 返回运行统计快照，拷贝时加锁保证字段一致性。
JqrSdkRuntimeStats JqrUsbDataRefresh::getStats() const {
    std::lock_guard<std::mutex> lk(stats_mtx_);
    return stats_;
}

// 判断周期目标缓存是否超过配置的自动过期时间，0 表示永不过期。
bool JqrUsbDataRefresh::isTargetCacheExpired(uint32_t target_update_ms, uint32_t now_ms, uint32_t expire_ms) {
    if (expire_ms == 0) {
        return false;
    }
    return elapsed(now_ms, target_update_ms, expire_ms);
}

uint32_t JqrUsbDataRefresh::headTargetCacheExpireMs() const {
    return (cfg_.target_cache_expire_ms != 0)
        ? cfg_.target_cache_expire_ms
        : cfg_.head_target_cache_expire_ms;
}

uint32_t JqrUsbDataRefresh::wheelTargetCacheExpireMs() const {
    return (cfg_.target_cache_expire_ms != 0)
        ? cfg_.target_cache_expire_ms
        : cfg_.wheel_target_cache_expire_ms;
}

// RX 线程主循环：非阻塞读串口、解析完整帧，并把有效帧交给 handleFrame。
void JqrUsbDataRefresh::rxLoop() {
    uint8_t buf[512];

    while (running_.load()) {
        int n = 0;
        {
            std::lock_guard<std::mutex> lk(serial_mtx_);
            if (serial_.isOpen()) {
                n = serial_.readSome(buf, sizeof(buf));
            }
        }

        if (n > 0) {
            auto frames = parser_.feed(buf, static_cast<size_t>(n));
            for (const auto& f : frames) {
                handleFrame(f);
            }
        } else if (n < 0) {
            serial_need_reopen_.store(true);
            mcu_online_.store(false);
            invalidateMedicineStatusCache();
            invalidateLightStatusCache();
            {
                std::lock_guard<std::mutex> st_lk(stats_mtx_);
                stats_.serial_error_count++;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        } else {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
    }
}

// 发送头部目标缓存的周期补发帧；该路径复用现有 wire_seq，不制造新目标。
void JqrUsbDataRefresh::sendPeriodicHeadTarget() {
    HeadTargetCache t;
    {
        std::lock_guard<std::mutex> lk(cache_mtx_);
        t = head_target_;
    }

    uint32_t now = localMs();
    if (!t.valid || isTargetCacheExpired(t.update_ms, now, headTargetCacheExpireMs())) {
        return;
    }

    std::array<float, 4> speed{{t.speed_limit, t.speed_limit, t.speed_limit, t.speed_limit}};

    if (t.wire_seq == 0) {
        return;
    }

    auto payload = packHeadTargetFloat(t.wire_seq, HeadMode::POSITION, 0x0F,
                                       cfg_.head_target_timeout_ms,
                                       t.target_deg[0], t.target_deg[1],
                                       t.target_deg[2], t.target_deg[3],
                                       speed, 0);

    if (writeFrameFromTxThread(MOD_HEAD, MSG_HEAD_TARGET_FLOAT, payload)) {
        std::lock_guard<std::mutex> st_lk(stats_mtx_);
        stats_.head_target_tx_count++;
        stats_.head_periodic_send_count++;
    }
}

// 发送轮组目标缓存的周期补发帧；该路径复用现有 wire_seq，不制造新目标。
void JqrUsbDataRefresh::sendPeriodicWheelTarget() {
    WheelTargetCache t;
    {
        std::lock_guard<std::mutex> lk(cache_mtx_);
        t = wheel_target_;
    }

    uint32_t now = localMs();
    if (!t.valid || isTargetCacheExpired(t.update_ms, now, wheelTargetCacheExpireMs())) {
        return;
    }

    if (t.wire_seq == 0) {
        return;
    }

    auto payload = packWheelTarget(t.wire_seq, t.mode, t.enable,
                                   cfg_.wheel_target_timeout_ms,
                                   t.linear_mm_s,
                                   t.angular_mdeg_s,
                                   t.left_rpm,
                                   t.right_rpm,
                                   t.flags);

    if (writeFrameFromTxThread(MOD_WHEEL, MSG_WHEEL_TARGET, payload)) {
        std::lock_guard<std::mutex> st_lk(stats_mtx_);
        stats_.wheel_target_tx_count++;
        stats_.wheel_periodic_send_count++;
    }
}

// 处理普通 TX 队列；如果等待 ACK 的命令写失败，会主动唤醒等待方并给出 TIMEOUT 状态。
void JqrUsbDataRefresh::processQueuedTxCommands() {
    TxCommand cmd;
    while (dequeueTxCommand(cmd)) {
        bool ok = writeFrameFromTxThread(cmd.mod_id, cmd.msg_id, cmd.payload);
        if (!ok && !cmd.payload.empty()) {
            std::lock_guard<std::mutex> lk(ack_mtx_);
            if (waiting_ack_ &&
                pending_seq_ == cmd.payload[0] &&
                pending_mod_ == cmd.mod_id &&
                pending_msg_ == cmd.msg_id) {
                pending_ack_.seq = pending_seq_;
                pending_ack_.req_mod = pending_mod_;
                pending_ack_.req_msg = pending_msg_;
                pending_ack_.status = static_cast<uint8_t>(AckStatus::TIMEOUT);
                pending_ack_.detail = 0;
                ack_matched_ = true;
                ack_cv_.notify_all();
            }
        }
    }
}

// TX 线程主循环：统一处理普通命令、新目标即时发送、周期目标补发和心跳。
void JqrUsbDataRefresh::txLoop() {
    auto next_heartbeat = Clock::now() + std::chrono::milliseconds(cfg_.heartbeat_period_ms);
    auto next_head = Clock::now() + std::chrono::milliseconds(cfg_.head_target_period_ms);
    auto next_wheel = Clock::now() + std::chrono::milliseconds(cfg_.wheel_target_period_ms);
    auto last_head_send = Clock::now() - std::chrono::milliseconds(1000);
    auto last_wheel_send = Clock::now() - std::chrono::milliseconds(1000);

    while (running_.load()) {
        auto now = Clock::now();

        processQueuedTxCommands();

        {
            WheelTargetCache t;
            bool should_send = false;
            bool is_new_content = false;
            uint32_t now_ms = localMs();

            {
                std::lock_guard<std::mutex> lk(cache_mtx_);
                bool valid = wheel_target_.valid &&
                             !isTargetCacheExpired(wheel_target_.update_ms, now_ms, wheelTargetCacheExpireMs());
                bool has_new_content = valid && (wheel_target_.cache_version != wheel_target_.sent_version);
                bool min_interval_ok =
                    (now - last_wheel_send) >= std::chrono::milliseconds(cfg_.wheel_min_send_interval_ms);

                if (has_new_content && min_interval_ok) {
                    // 新目标只更新 latest cache。真正发送前才递增 wire_seq，防止 dirty 丢失。
                    wheel_target_.wire_seq = nextNonZeroSeq(wheel_target_.wire_seq);
                    wheel_target_.sent_version = wheel_target_.cache_version;
                    t = wheel_target_;
                    should_send = true;
                    is_new_content = true;
                } else if (valid && !has_new_content && now >= next_wheel && wheel_target_.wire_seq != 0) {
                    // 周期兜底只重发最新目标，不递增 wire_seq。
                    t = wheel_target_;
                    should_send = true;
                }

                if (!should_send && now >= next_wheel) {
                    next_wheel = now + std::chrono::milliseconds(cfg_.wheel_target_period_ms);
                }
            }

            if (should_send) {
                auto payload = packWheelTarget(t.wire_seq, t.mode, t.enable,
                                               cfg_.wheel_target_timeout_ms,
                                               t.linear_mm_s,
                                               t.angular_mdeg_s,
                                               t.left_rpm,
                                               t.right_rpm,
                                               t.flags);
                bool ok = writeFrameFromTxThread(MOD_WHEEL, MSG_WHEEL_TARGET, payload);
                last_wheel_send = now;
                next_wheel = now + std::chrono::milliseconds(cfg_.wheel_target_period_ms);

                if (ok) {
                    std::lock_guard<std::mutex> st_lk(stats_mtx_);
                    stats_.wheel_target_tx_count++;
                    if (is_new_content) {
                        stats_.wheel_new_content_send_count++;
                        uint32_t delay = diffMs(localMs(), t.update_ms);
                        if (delay > stats_.settarget_to_write_max_delay_ms) {
                            stats_.settarget_to_write_max_delay_ms = delay;
                        }
                    } else {
                        stats_.wheel_periodic_send_count++;
                    }
                }
            }
        }

        {
            HeadTargetCache t;
            bool should_send = false;
            bool is_new_content = false;
            uint32_t now_ms = localMs();

            {
                std::lock_guard<std::mutex> lk(cache_mtx_);
                bool valid = head_target_.valid &&
                             !isTargetCacheExpired(head_target_.update_ms, now_ms, headTargetCacheExpireMs());
                bool has_new_content = valid && (head_target_.cache_version != head_target_.sent_version);
                bool min_interval_ok =
                    (now - last_head_send) >= std::chrono::milliseconds(cfg_.head_min_send_interval_ms);

                if (has_new_content && min_interval_ok) {
                    // Head 与 Wheel 使用独立 wire_seq，周期兜底不会伪装成新目标。
                    head_target_.wire_seq = nextNonZeroSeq(head_target_.wire_seq);
                    head_target_.sent_version = head_target_.cache_version;
                    t = head_target_;
                    should_send = true;
                    is_new_content = true;
                } else if (valid && !has_new_content && now >= next_head && head_target_.wire_seq != 0) {
                    t = head_target_;
                    should_send = true;
                }

                if (!should_send && now >= next_head) {
                    next_head = now + std::chrono::milliseconds(cfg_.head_target_period_ms);
                }
            }

            if (should_send) {
                std::array<float, 4> speed{{t.speed_limit, t.speed_limit, t.speed_limit, t.speed_limit}};
                auto payload = packHeadTargetFloat(t.wire_seq, HeadMode::POSITION, 0x0F,
                                                   cfg_.head_target_timeout_ms,
                                                   t.target_deg[0], t.target_deg[1],
                                                   t.target_deg[2], t.target_deg[3],
                                                   speed, 0);
                bool ok = writeFrameFromTxThread(MOD_HEAD, MSG_HEAD_TARGET_FLOAT, payload);
                last_head_send = now;
                next_head = now + std::chrono::milliseconds(cfg_.head_target_period_ms);

                if (ok) {
                    std::lock_guard<std::mutex> st_lk(stats_mtx_);
                    stats_.head_target_tx_count++;
                    if (is_new_content) {
                        stats_.head_new_content_send_count++;
                        uint32_t delay = diffMs(localMs(), t.update_ms);
                        if (delay > stats_.settarget_to_write_max_delay_ms) {
                            stats_.settarget_to_write_max_delay_ms = delay;
                        }
                    } else {
                        stats_.head_periodic_send_count++;
                    }
                }
            }
        }

        now = Clock::now();
        if (now >= next_heartbeat) {
            auto expected_ms = static_cast<uint32_t>(
                std::chrono::duration_cast<std::chrono::milliseconds>(now - next_heartbeat).count());
            {
                std::lock_guard<std::mutex> st_lk(stats_mtx_);
                if (expected_ms > stats_.tx_loop_max_jitter_ms) {
                    stats_.tx_loop_max_jitter_ms = expected_ms;
                }
            }

            sendHeartbeat(false);
            next_heartbeat = now + std::chrono::milliseconds(cfg_.heartbeat_period_ms);
        }

        auto next_time = next_heartbeat;
        if (next_head < next_time) next_time = next_head;
        if (next_wheel < next_time) next_time = next_wheel;

        {
            std::lock_guard<std::mutex> lk(cache_mtx_);
            // next_time 计算不检查过期，确保新目标能尽快触发唤醒
            if (wheel_target_.valid &&
                wheel_target_.cache_version != wheel_target_.sent_version) {
                auto wheel_min_next = last_wheel_send + std::chrono::milliseconds(cfg_.wheel_min_send_interval_ms);
                if (wheel_min_next < next_time) {
                    next_time = wheel_min_next;
                }
            }
            if (head_target_.valid &&
                head_target_.cache_version != head_target_.sent_version) {
                auto head_min_next = last_head_send + std::chrono::milliseconds(cfg_.head_min_send_interval_ms);
                if (head_min_next < next_time) {
                    next_time = head_min_next;
                }
            }
        }

        std::unique_lock<std::mutex> lk(tx_cv_mtx_);
        tx_cv_.wait_until(lk, next_time, [&]() {
            if (!running_.load()) {
                return true;
            }

            {
                std::lock_guard<std::mutex> q_lk(tx_queue_mtx_);
                if (!tx_queue_.empty()) {
                    return true;
                }
            }

            std::lock_guard<std::mutex> target_lk(cache_mtx_);
            // 过期检查在循环体中做，谓词只检查是否有新内容，避免因过期误判而错过 notify
            return (wheel_target_.valid &&
                    wheel_target_.cache_version != wheel_target_.sent_version) ||
                   (head_target_.valid &&
                    head_target_.cache_version != head_target_.sent_version);
        });
    }
}

// Watchdog 线程主循环：检测状态上报超时和串口错误，并按配置尝试重连。
void JqrUsbDataRefresh::watchdogLoop() {
    uint32_t last_reconnect_try = 0;

    while (running_.load()) {
        uint32_t now = localMs();

        bool need_reconnect = serial_need_reopen_.load();
        bool status_timed_out = false;

        {
            std::lock_guard<std::mutex> st_lk(stats_mtx_);
            if (stats_.last_status_rx_ms != 0 &&
                elapsed(now, stats_.last_status_rx_ms, cfg_.status_timeout_ms)) {
                need_reconnect = true;
                status_timed_out = true;
            }
        }

        if (status_timed_out) {
            mcu_online_.store(false);
            invalidateMedicineStatusCache();
            invalidateLightStatusCache();
        }

        if (cfg_.enable_reconnect && need_reconnect &&
            elapsed(now, last_reconnect_try, cfg_.reconnect_interval_ms)) {
            last_reconnect_try = now;
            bool reopened = false;

            {
                std::lock_guard<std::mutex> lk(serial_mtx_);
                serial_.close();
                reopened = openSerialLocked();
            }

            if (reopened) {
                serial_need_reopen_.store(false);
                mcu_online_.store(false);
                invalidateMedicineStatusCache();
                invalidateLightStatusCache();
                std::lock_guard<std::mutex> st_lk(stats_mtx_);
                stats_.reconnect_count++;
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
}

// 处理 RX 线程解析出的协议帧，更新 ACK、状态缓存、在线状态、统计和用户回调。
void JqrUsbDataRefresh::handleFrame(const JqrFrame& frame) {
    uint32_t now_ms = localMs();

    {
        std::lock_guard<std::mutex> st_lk(stats_mtx_);
        stats_.rx_frame_count++;
        stats_.last_rx_ms = now_ms;
    }

    if (frame.mod_id == MOD_SYSTEM && frame.msg_id == MSG_ACK) {
        JqrAck ack;
        if (decodeAck(frame.payload, ack)) {
            {
                std::lock_guard<std::mutex> st_lk(stats_mtx_);
                stats_.rx_ack_count++;
                if (ack.status != static_cast<uint8_t>(AckStatus::OK)) {
                    stats_.ack_error_count++;
                }
            }

            if (ack.req_mod == MOD_WHEEL && ack.req_msg == MSG_WHEEL_TARGET) {
                std::lock_guard<std::mutex> lk(cache_mtx_);
                last_wheel_target_ack_.seq = ack.seq;
                last_wheel_target_ack_.req_mod = ack.req_mod;
                last_wheel_target_ack_.req_msg = ack.req_msg;
                last_wheel_target_ack_.status = ack.status;
                last_wheel_target_ack_.detail = ack.detail;
                last_wheel_target_ack_.rx_ms = now_ms;
                last_wheel_target_ack_.count++;
                if (ack.status != static_cast<uint8_t>(AckStatus::OK)) {
                    last_wheel_target_ack_.error_count++;
                }
            } else if (ack.req_mod == MOD_HEAD && ack.req_msg == MSG_HEAD_TARGET_FLOAT) {
                std::lock_guard<std::mutex> lk(cache_mtx_);
                last_head_target_ack_.seq = ack.seq;
                last_head_target_ack_.req_mod = ack.req_mod;
                last_head_target_ack_.req_msg = ack.req_msg;
                last_head_target_ack_.status = ack.status;
                last_head_target_ack_.detail = ack.detail;
                last_head_target_ack_.rx_ms = now_ms;
                last_head_target_ack_.count++;
                if (ack.status != static_cast<uint8_t>(AckStatus::OK)) {
                    last_head_target_ack_.error_count++;
                }
            }

            std::lock_guard<std::mutex> lk(ack_mtx_);
            if (waiting_ack_ &&
                ack.seq == pending_seq_ &&
                ack.req_mod == pending_mod_ &&
                ack.req_msg == pending_msg_) {
                pending_ack_ = ack;
                ack_matched_ = true;
                ack_cv_.notify_all();
            }
        }
    } else if (frame.mod_id == MOD_SYSTEM && frame.msg_id == MSG_VERSION_RPT) {
        JqrVersion v;
        if (decodeVersion(frame.payload, v)) {
            {
                std::lock_guard<std::mutex> lk(cache_mtx_);
                version_ = v;
                has_version_ = true;
            }
            version_cv_.notify_all();
        }
    } else if (frame.mod_id == MOD_SYSTEM && frame.msg_id == MSG_SYSTEM_STATUS) {
        JqrSystemStatus s;
        if (decodeSystemStatus(frame.payload, s)) {
            s.update_ms_local = now_ms;
            {
                std::lock_guard<std::mutex> lk(cache_mtx_);
                system_status_ = s;
                has_system_status_ = true;
            }

            mcu_online_.store(s.usb_online != 0);
            std::lock_guard<std::mutex> st_lk(stats_mtx_);
            stats_.last_status_rx_ms = now_ms;
        }
    } else if (frame.mod_id == MOD_BMS && frame.msg_id == MSG_BMS_STATUS) {
        JqrBmsStatus b;
        if (decodeBmsStatus(frame.payload, b)) {
            b.update_ms_local = now_ms;
            std::lock_guard<std::mutex> lk(cache_mtx_);
            bms_status_ = b;
            has_bms_status_ = true;
        }
    } else if (frame.mod_id == MOD_AUX && frame.msg_id == MSG_MEDICINE_STATUS) {
        JqrMedicineStatus m;
        if (decodeMedicineStatus(frame.payload, m)) {
            m.update_ms_local = now_ms;
            {
                std::lock_guard<std::mutex> lk(cache_mtx_);
                medicine_status_ = m;
                has_medicine_status_ = true;
            }

            std::lock_guard<std::mutex> st_lk(stats_mtx_);
            stats_.last_status_rx_ms = now_ms;
        }
    } else if (frame.mod_id == MOD_LIGHT && frame.msg_id == MSG_LIGHT_STATUS) {
        JqrLightStatus l;
        if (decodeLightStatus(frame.payload, l)) {
            l.update_ms_local = now_ms;
            {
                std::lock_guard<std::mutex> lk(cache_mtx_);
                light_status_ = l;
                has_light_status_ = true;
            }

            std::lock_guard<std::mutex> st_lk(stats_mtx_);
            stats_.last_status_rx_ms = now_ms;
        }
    } else if (frame.mod_id == MOD_WHEEL && frame.msg_id == MSG_WHEEL_STATUS) {
        JqrWheelStatus w;
        if (decodeWheelStatus(frame.payload, w)) {
            w.update_ms_local = now_ms;
            {
                std::lock_guard<std::mutex> lk(cache_mtx_);
                wheel_status_ = w;
                has_wheel_status_ = true;
            }

            std::lock_guard<std::mutex> st_lk(stats_mtx_);
            stats_.last_status_rx_ms = now_ms;
        }
    } else if (frame.mod_id == MOD_HEAD && frame.msg_id == MSG_HEAD_STATUS_FLOAT) {
        JqrHeadStatus h;
        if (decodeHeadStatus(frame.payload, h)) {
            h.update_ms_local = now_ms;
            {
                std::lock_guard<std::mutex> lk(cache_mtx_);
                head_status_ = h;
                has_head_status_ = true;
                if (!head_target_.initialized) {
                    (void)initHeadTargetFromFeedbackLocked(now_ms);
                }
            }

            std::lock_guard<std::mutex> st_lk(stats_mtx_);
            stats_.last_status_rx_ms = now_ms;
        }
    } else if (frame.mod_id == MOD_SENSOR && frame.msg_id == MSG_SENSOR_STATUS) {
        JqrSensorStatusRaw s;
        if (decodeSensorStatusRaw(frame.payload, s)) {
            s.update_ms_local = now_ms;
            {
                std::lock_guard<std::mutex> lk(cache_mtx_);
                sensor_status_ = s;
                has_sensor_status_ = true;
            }

            std::lock_guard<std::mutex> st_lk(stats_mtx_);
            stats_.last_status_rx_ms = now_ms;
        }
    } else if (frame.mod_id == MOD_SENSOR && frame.msg_id == MSG_IMU_REPORT) {
        ImuRecvDataStruct imu;
        if (decodeImuReport(frame.payload, imu)) {
            {
                std::lock_guard<std::mutex> lk(cache_mtx_);
                imu_data_ = imu;
                has_imu_data_ = true;
            }

            std::lock_guard<std::mutex> st_lk(stats_mtx_);
            stats_.last_status_rx_ms = now_ms;
        }
    }

    FrameCallback cb;
    {
        std::lock_guard<std::mutex> lk(cb_mtx_);
        cb = frame_cb_;
    }
    if (cb) cb(frame);
}

} // namespace jqr
