#include "JqrSdkController.h"

#include <utility>

namespace jqr {

// 使用最常见的 device/baudrate 参数构造默认配置，再复用完整配置初始化入口。
bool JqrSdkController::init(const std::string& device, int baudrate) {
    JqrSdkConfig cfg;
    cfg.device = device;
    cfg.baudrate = baudrate;
    return init(cfg);
}

// 启动内部数据刷新对象，实际串口打开和线程启动逻辑在 JqrUsbDataRefresh::start 中完成。
bool JqrSdkController::init(const JqrSdkConfig& cfg) {
    return data_.start(cfg);
}

// 关闭内部数据刷新对象，阻塞等待后台线程退出并释放串口。
void JqrSdkController::close() {
    data_.stop();
}

// 返回 MCU 在线缓存状态，不直接访问串口 fd。
bool JqrSdkController::GetMcuConnectStatus() const {
    return data_.isOnline();
}

// 同步设置系统使能状态，返回值来自 MCU ACK 是否为 OK。
bool JqrSdkController::SetSystemEnable(bool enable) {
    return data_.setSystemEnable(enable);
}

// 同步清除故障，mask 指定要清除的故障位。
bool JqrSdkController::ClearFault(uint32_t mask) {
    return data_.clearFault(mask);
}

// 同步查询 MCU 版本，内部等待版本上报帧而不是普通 ACK。
bool JqrSdkController::GetVersion(JqrVersion& version) {
    return data_.getVersion(version);
}

// 更新头部目标缓存并唤醒 TX 线程；返回 true 不代表头部已经运动到位。
bool JqrSdkController::SetHeadTarget(float head_pitch_deg,
                                     float neck_pitch_deg,
                                     float neck_swing_deg,
                                     float head_horizontal_deg,
                                     float speed_limit_deg_s) {
    return data_.setHeadTarget(head_pitch_deg, neck_pitch_deg, neck_swing_deg,
                               head_horizontal_deg, speed_limit_deg_s);
}

// 单轴目标会先用最近 HeadStatus 初始化其他 3 个轴，再发送完整 4 轴 target。
bool JqrSdkController::SetHeadAxisTarget(HeadAxis axis,
                                         float target_deg,
                                         float speed_limit_deg_s) {
    return data_.setHeadAxisTarget(axis, target_deg, speed_limit_deg_s);
}

// 清除 SDK 侧头部目标缓存，并异步发送 Head STOP。
bool JqrSdkController::ClearHeadTarget() {
    return data_.clearHeadTarget();
}

// 异步发送 Head STOP，ACK 由 RX 线程缓存。
bool JqrSdkController::StopHead() {
    return data_.stopHead();
}

// 更新整机底盘速度目标缓存，发送和 ACK 接收由后台线程异步完成。
bool JqrSdkController::SetChassisVelocityMm(int32_t linear_mm_s, int32_t angular_mdeg_s) {
    return data_.setChassisVelocity(linear_mm_s, angular_mdeg_s);
}

// 兼容旧接口：单位同 SetChassisVelocityMm，建议新代码优先使用 SetChassisVelocityMm。
bool JqrSdkController::SetChassisVelocity(int32_t linear_mm_s, int32_t angular_mdeg_s) {
    return SetChassisVelocityMm(linear_mm_s, angular_mdeg_s);
}

// 发送轮组 STOP 目标并同步等待 ACK，用于明确停止轮组输出。
bool JqrSdkController::StopWheel() {
    return data_.stopWheel();
}

// 同步等待药盒命令ACK；机械动作是否完成由药盒状态帧持续反馈。
bool JqrSdkController::SetMedicineBox(MedicineCommand command) {
    return data_.setMedicineCommand(command);
}

// 返回本次药盒命令seq，供业务层与MedicineStatus.last_cmd_seq关联。
bool JqrSdkController::SetMedicineBox(MedicineCommand command, uint8_t& seq_out) {
    return data_.setMedicineCommand(command, seq_out);
}

bool JqrSdkController::SetLightScene(LightScene scene,
                                     LightAmbient ambient,
                                     bool restart_pattern) {
    return data_.setLightScene(scene, ambient, restart_pattern);
}

bool JqrSdkController::SetLightRgbw(uint16_t r_permille,
                                    uint16_t g_permille,
                                    uint16_t b_permille,
                                    uint16_t w_permille) {
    return data_.setLightRgbw(r_permille, g_permille, b_permille, w_permille);
}

// 获取系统状态缓存；false 表示尚未收到过有效系统状态。
bool JqrSdkController::GetSystemStatus(JqrSystemStatus& status) const {
    return data_.getSystemStatus(status);
}

// 获取轮组状态缓存；业务层可用 update_ms_local 判断状态新鲜度。
bool JqrSdkController::GetWheelStatus(JqrWheelStatus& status) const {
    return data_.getWheelStatus(status);
}

// 获取锂电池 BMS 状态缓存；pack_voltage_mV 即底盘母线电压。
bool JqrSdkController::GetBmsStatus(JqrBmsStatus& status) const {
    return data_.getBmsStatus(status);
}

// 获取药盒状态缓存，业务层应结合 update_ms_local 判断新鲜度。
bool JqrSdkController::GetMedicineStatus(JqrMedicineStatus& status) const {
    return data_.getMedicineStatus(status);
}

bool JqrSdkController::GetLightStatus(JqrLightStatus& status) const {
    return data_.getLightStatus(status);
}

// 获取头部状态缓存；业务层可用 position_deg/speed_deg_s 观察执行进度。
bool JqrSdkController::GetHeadStatus(JqrHeadStatus& status) const {
    return data_.getHeadStatus(status);
}

// 获取传感器原始状态缓存，当前不在 SDK 内进一步解释 payload。
bool JqrSdkController::GetSensorStatusRaw(JqrSensorStatusRaw& status) const {
    return data_.getSensorStatusRaw(status);
}

// 获取 IMU 专用上报缓存，字段顺序与 MCU ImuRecvDataStruct 一致。
bool JqrSdkController::GetImuData(ImuRecvDataStruct& imu) const {
    return data_.getImuData(imu);
}

// 获取最近一次轮组目标 ACK 缓存，用于判断异步目标是否被 MCU 接收。
bool JqrSdkController::GetLastWheelTargetAck(TargetAckStatus& ack) const {
    return data_.getLastWheelTargetAck(ack);
}

// 获取最近一次头部目标 ACK 缓存，用于判断异步目标是否被 MCU 接收。
bool JqrSdkController::GetLastHeadTargetAck(TargetAckStatus& ack) const {
    return data_.getLastHeadTargetAck(ack);
}

// 获取 SDK 收发、ACK、重连和调度抖动统计快照。
JqrSdkRuntimeStats JqrSdkController::GetStats() const {
    return data_.getStats();
}

// 注册原始帧回调，回调实际在 RX 线程中触发。
void JqrSdkController::SetFrameCallback(JqrUsbDataRefresh::FrameCallback cb) {
    data_.setFrameCallback(std::move(cb));
}

} // namespace jqr
