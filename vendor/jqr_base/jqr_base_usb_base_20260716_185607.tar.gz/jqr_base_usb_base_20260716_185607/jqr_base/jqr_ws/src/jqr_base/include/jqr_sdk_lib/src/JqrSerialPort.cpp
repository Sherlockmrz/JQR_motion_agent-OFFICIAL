#include "JqrSerialPort.h"

#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>

namespace jqr {

namespace {

// 将业务配置中的整数波特率转换为 termios 常量；不支持的波特率回退到 115200。
speed_t toBaud(int baudrate) {
    switch (baudrate) {
        case 9600: return B9600;
        case 19200: return B19200;
        case 38400: return B38400;
        case 57600: return B57600;
        case 115200: return B115200;
#ifdef B230400
        case 230400: return B230400;
#endif
#ifdef B460800
        case 460800: return B460800;
#endif
#ifdef B921600
        case 921600: return B921600;
#endif
        default: return B115200;
    }
}

} // namespace

// 析构时关闭 fd，防止调用方忘记 close 造成设备节点占用。
JqrSerialPort::~JqrSerialPort() {
    close();
}

// 打开 USB CDC ACM 设备并配置为 raw 串口模式，成功后拉高 DTR/RTS 并清空缓冲。
bool JqrSerialPort::open(const std::string& device, int baudrate) {
    close();

    fd_ = ::open(device.c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (fd_ < 0) {
        last_error_ = "open failed: " + std::string(std::strerror(errno));
        return false;
    }

    if (!configure(baudrate)) {
        close();
        return false;
    }

    /*
     * 很多 CDC ACM 设备在 Python pyserial 下能正常通信，
     * 是因为 pyserial 默认会拉起 DTR/RTS。
     * C++ termios 也做同样动作，避免打开后第一帧不稳定。
     */
    int modem_bits = TIOCM_DTR | TIOCM_RTS;
    (void)::ioctl(fd_, TIOCMBIS, &modem_bits);

    usleep(150 * 1000);
    tcflush(fd_, TCIOFLUSH);

    return true;
}

// 关闭当前 fd；如果 fd 已经无效则直接返回。
void JqrSerialPort::close() {
    if (fd_ >= 0) {
        ::close(fd_);
        fd_ = -1;
    }
}

// 判断 fd 是否有效，只代表本进程已打开设备，不代表 MCU 一定在线。
bool JqrSerialPort::isOpen() const {
    return fd_ >= 0;
}

// 配置 termios raw 模式、8N1、无硬件流控和短超时读取。
bool JqrSerialPort::configure(int baudrate) {
    termios tio{};
    if (tcgetattr(fd_, &tio) != 0) {
        last_error_ = "tcgetattr failed: " + std::string(std::strerror(errno));
        return false;
    }

    cfmakeraw(&tio);

    speed_t speed = toBaud(baudrate);
    cfsetispeed(&tio, speed);
    cfsetospeed(&tio, speed);

    tio.c_cflag |= (CLOCAL | CREAD);
    tio.c_cflag &= ~PARENB;
    tio.c_cflag &= ~CSTOPB;
    tio.c_cflag &= ~CSIZE;
    tio.c_cflag |= CS8;

#ifdef CRTSCTS
    tio.c_cflag &= ~CRTSCTS;
#endif

    tio.c_cc[VMIN] = 0;
    tio.c_cc[VTIME] = 1;

    if (tcsetattr(fd_, TCSANOW, &tio) != 0) {
        last_error_ = "tcsetattr failed: " + std::string(std::strerror(errno));
        return false;
    }

    return true;
}

// 非阻塞读取一段数据；没有数据时返回 0，真实错误时记录 last_error_ 并返回 -1。
int JqrSerialPort::readSome(uint8_t* buffer, size_t max_len) {
    if (fd_ < 0 || buffer == nullptr || max_len == 0) {
        return -1;
    }

    int n = ::read(fd_, buffer, max_len);
    if (n < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            return 0;
        }
        last_error_ = "read failed: " + std::string(std::strerror(errno));
        return -1;
    }
    return n;
}

// 循环写完整段数据；遇到 EAGAIN 短暂等待重试，其他错误立即返回 false。
bool JqrSerialPort::writeAll(const uint8_t* data, size_t len) {
    if (fd_ < 0 || data == nullptr) {
        return false;
    }

    size_t sent = 0;
    while (sent < len) {
        int n = ::write(fd_, data + sent, len - sent);
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                usleep(1000);
                continue;
            }
            last_error_ = "write failed: " + std::string(std::strerror(errno));
            return false;
        }
        if (n == 0) {
            usleep(1000);
            continue;
        }
        sent += static_cast<size_t>(n);
    }

    tcdrain(fd_);
    return true;
}

} // namespace jqr
