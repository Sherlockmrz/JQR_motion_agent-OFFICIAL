#!/bin/bash
data_name=$(date +"%Y%m%d_%H%M%S")
base_log_dir="/userdata/roslog/base"

mkdir -p "${base_log_dir}"

cd /app/jqr_ws/
source /opt/ros/humble/setup.bash
source install/setup.bash
export LD_LIBRARY_PATH=/app/jqr_ws/src/jqr_base/include/jqr_sdk_lib/lib/sdk_lib:$LD_LIBRARY_PATH

echo "正在启动 jqr_base，日志: ${base_log_dir}/base_${data_name}.log"
nohup ros2 run jqr_base jqr_base_node "${base_log_dir}" >>"${base_log_dir}/base_${data_name}.log" 2>&1 &
echo "jqr_base 已启动，PID: $!"
