# jqr_base USB 通信测试脚本使用说明

`scripts/base_comm_test.py` —— 按 base 软件（`jqr_base_node`）的 ROS2 话题/服务接口
发送控制指令并订阅反馈，用于验证整条通信链路：

```
上层 ROS2 客户端(本脚本) → base 软件(jqr_base_node) → SDK(JqrSdkController,0xFA帧)
                                          → USB /dev/ttyACM0 → MCU
反馈: MCU → USB → base → ROS2 话题 → 本脚本
```

脚本是**纯 ROS2 客户端，不直接操作串口**。它只负责发话题/调服务、收反馈，
真正的 USB 通信由 base 软件内部完成。

---

## 1. 测试环境

- 测试机：`sunrise@192.168.50.161`（S100, aarch64, ROS2 Humble）
- 工作空间：`/home/sunrise/jbase/jqr_ws/`
- 脚本随仓库一起，位于 `src/jqr_base/scripts/base_comm_test.py`

---

## 2. 前置条件

1. **base 节点必须先在运行**：
   ```bash
   source /opt/ros/humble/setup.bash
   source /home/sunrise/jbase/jqr_ws/install/setup.bash
   export LD_LIBRARY_PATH=/home/sunrise/jbase/jqr_ws/src/jqr_base/include/jqr_sdk_lib/lib/sdk_lib:$LD_LIBRARY_PATH
   ros2 launch jqr_base base_launch.py
   # 或: ros2 run jqr_base jqr_base_node
   ```
   > ⚠️ base 节点启动时会打开 `/dev/ttyACM0`。**若 MCU 未接，节点会 FATAL 退出**
   > （`SDK初始化失败 → Failed to initialize SDK controller`）。这是已知行为，
   > 也是明天联调要解决的第一步：先让 MCU 接上、`/dev/ttyACM0` 出现、base 能存活。

2. 测试脚本端（可与 base 同机，也可同网另一台，需同 `ROS_DOMAIN_ID`）：
   ```bash
   source /opt/ros/humble/setup.bash
   source /home/sunrise/jbase/jqr_ws/install/setup.bash   # 为了 import jqr_ros_msgs
   ```

---

## 3. 用法

```bash
cd /home/sunrise/jbase/jqr_ws/src/jqr_base/scripts
chmod +x base_comm_test.py   # 首次

# (a) 列接口 + 探测 base/话题是否在线（不发指令，最安全，先跑这个）
./base_comm_test.py check

# (b) 只监听全部反馈话题，看 base 是否在持续发布
./base_comm_test.py monitor --duration 10

# (c) 一键全自动冒烟（节点在线? 有反馈? 发底盘/头部/四轴指令）
./base_comm_test.py smoke

# (d) 单项指令
./base_comm_test.py cmd_vel --linear 0.1 --angular 0.0 --duration 3
./base_comm_test.py head_speed --pitch 0.0 --yaw 0.2 --duration 2
./base_comm_test.py four_motor --neck-yaw 0 --neck-roll 0 --neck-pitch 0 --head-pitch 0
./base_comm_test.py motor_control --med-switch 1 --med-speed 0    # 开药盒
./base_comm_test.py motor_control --med-switch 0                  # 关药盒

# (e) 服务调用
./base_comm_test.py service get_robot_tilt
./base_comm_test.py service set_robot_rise --bool true
./base_comm_test.py service set_screen_tilt --float 5.0
./base_comm_test.py service set_medicine_box_switch --bool true --speed 1
./base_comm_test.py service set_laser_pointer --bool true

# (f) 交互式菜单
./base_comm_test.py menu
```

不带 `ros2 run` 也能跑，因为它是普通 Python 脚本，只要 `rclpy` 和 `jqr_ros_msgs`
在环境里即可。

---

## 4. base 接口对照表（来源：`src/base_controller.cpp`）

### base 订阅（脚本向其发布）
| 话题 | 类型 | 含义 |
|------|------|------|
| `/cmd_vel` | `geometry_msgs/Twist` | 底盘：`linear.x`(m/s)、`angular.z`(rad/s)，限幅 ±0.5 / ±1.0 |
| `/motor_control` | `Float32MultiArray[5]` | `[屏幕俯仰,机身俯仰,机身升降,药盒开关,药盒速度]`，**当前固件只响应药盒** |
| `/head_motor_speed_control` | `Float32MultiArray[2]` | `[pitch速度, yaw速度]` rad/s |
| `/four_motor_position_control` | `Float32MultiArray[4]` | rad：`[脖子旋转,脖子摇摆,脖子俯仰,头部俯仰]` |

### base 发布（脚本订阅其反馈）
| 话题 | 类型 |
|------|------|
| `/odom` | `nav_msgs/Odometry` |
| `/imu` | `sensor_msgs/Imu` |
| `/ultra_sonic_front` `/ultra_sonic_back` | `sensor_msgs/Range` |
| `/battery_level` | `jqr_ros_msgs/BatteryLevel` |
| `/robot_state_update` | `Float32MultiArray[5]` 屏幕/机身俯仰/升降/药盒/电量 |
| `/head_motor_angle_feedback` | `Float32MultiArray[2]` rad |
| `/four_motor_position_feedback` | `Float32MultiArray[4]` rad |
| `/stall_flag` | `std_msgs/UInt8` 堵转标志 |

### base 服务（`jqr_ros_msgs/srv/*`）
`get_move_mode` `set_robot_tilt` `get_robot_tilt` `set_robot_rise` `get_robot_rise`
`set_screen_tilt` `get_screen_tilt` `set_medicine_box_switch` `get_medicine_box_state`
`set_laser_pointer` `get_laser_pointer_state`

---

## 5. 结果判读

- `check`：能看到 `base_controller 节点在线: 是` + 各话题“存在” → 接口注册正常。
- `monitor` / `smoke`：**收到反馈计数持续增长** → MCU→USB→base→话题 上行链路通。
  - 全程“无任何反馈” → base 没起来，或 base 已因 MCU 未连接退出。
- 指令类（`cmd_vel`/`head_speed`/`four_motor`）：发完后对应反馈话题数值变化
  （如 `odom` 速度、`head_motor_angle_feedback` 角度）→ 下行链路通。
- 服务类：返回 `result_number=1` 多为成功；**调用超时**通常表示 base 在阻塞等
  MCU 反馈（联调时重点看这里）。

退出码：`0` 正常 / `2` 未收到反馈或服务不可用（便于脚本化判定）。

---

## 6. 明天联调建议步骤

1. 接好 MCU，确认 `ls /dev/ttyACM*` 出现设备（必要时 `JQR_USB_DEVICE` 指定其它节点）。
2. 启动 base 节点，确认不再 FATAL 退出。
3. 脚本端先 `check`，再 `monitor`，确认上行反馈。
4. 用 `smoke` 跑一轮，再按单项指令逐个验证底盘/头颈/药盒方向与数值。
5. 头部四轴注意**校验每轴实际转动方向**（协议映射见 SdkController.cpp 注释）。

---

## 7. 已知行为 / 排错

| 现象 | 原因 | 处理 |
|------|------|------|
| base 启动即 `SDK初始化失败` 退出 | `/dev/ttyACM0` 不存在（MCU 未接） | 接 MCU 或用 `JQR_USB_DEVICE` 指定 |
| 脚本 `import jqr_ros_msgs` 失败 | 未 source install/setup.bash | 先 source，再跑 service 子命令 |
| `monitor` 全程无反馈 | base 未运行 | 先确认 `ros2 node list` 有 `base_controller` |
| 服务调用 10s 超时 | base 阻塞等 MCU 反馈 | 检查 MCU 链路、查看 base 日志 |
