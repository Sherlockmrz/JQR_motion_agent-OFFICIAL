# JQR Base 部署及使用说明

> **代码包**: jqr_base (new_base_wang 分支)  
> **目标平台**: Ubuntu 22.04 + ROS2 Humble  
> **硬件**: 地平线 Sunrise X3 / X5 (aarch64)

---

## 目录

- [1. 前置依赖](#1-前置依赖)
- [2. 部署步骤](#2-部署步骤)
- [3. 编译构建](#3-编译构建)
- [4. 运行 Base 节点](#4-运行-base-节点)
- [5. 测试验证](#5-测试验证)
- [6. 常见问题](#6-常见问题)
- [附录A: 接口清单](#附录a-接口清单)

---

## 1. 前置依赖

### 1.1 系统要求

```bash
# 操作系统
Ubuntu 22.04 (aarch64)

# ROS2 版本
ROS2 Humble

# 硬件连接
USB 串口: /dev/ttyACM0 (JQR MCU 通过 USB 连接)
```

### 1.2 安装 ROS2 依赖

```bash
# 更新软件源
sudo apt update

# 安装 ROS2 Humble 基础包（如果未安装）
sudo apt install -y \
  ros-humble-ros-base \
  ros-humble-geometry-msgs \
  ros-humble-nav-msgs \
  ros-humble-sensor-msgs \
  ros-humble-tf2 \
  ros-humble-tf2-ros

# 安装构建工具
sudo apt install -y \
  python3-colcon-common-extensions \
  python3-rosdep
```

### 1.3 配置串口权限

```bash
# 将当前用户加入 dialout 组（避免每次 sudo）
sudo usermod -aG dialout $USER

# 重新登录使权限生效，或临时生效
newgrp dialout

# 验证串口设备
ls -l /dev/ttyACM0
# 应显示: crw-rw---- 1 root dialout ...
```

---

## 2. 部署步骤

### 2.1 解压代码包

```bash
# 解压
tar xzf jqr_base_new_base_wang_*.tar.gz
cd jqr_base_new_base_wang_*/jqr_base

# 查看目录结构
ls -lh
# 应包含:
#   jqr_ws/                    # ROS2 工作空间
#   base_comm_test.py          # 测试脚本
#   VERSION.txt                # 版本信息
#   README*.md                 # 文档
```

### 2.2 Source ROS2 环境

```bash
# 加载 ROS2 环境
source /opt/ros/humble/setup.bash

# 验证
ros2 --version
# 输出: ros2 doctor version humble-20XX...
```

---

## 3. 编译构建

### 3.1 编译 jqr_ws

```bash
cd jqr_ws

# 安装依赖（首次部署）
rosdep install --from-paths src --ignore-src -r -y

# 编译（aarch64 平台约需 3-5 分钟）
colcon build --symlink-install

# 查看编译结果
ls install/
# 应包含: jqr_base/ jqr_ros_msgs/ rgb_controller/ setup.bash
```

### 3.2 Source 工作空间

```bash
# 在 jqr_ws 目录下
source install/setup.bash

# 验证节点是否可见
ros2 pkg list | grep jqr
# 输出:
#   jqr_base
#   jqr_ros_msgs
```

---

## 4. 运行 Base 节点

### 4.1 启动 Base Controller

```bash
# 终端 1: 启动 base 节点
cd jqr_ws
source install/setup.bash
ros2 launch jqr_base base_launch.py
```

**预期输出**:
```
[base_controller]: SDK初始化成功
[base_controller]: GPIO初始化成功
[base_controller]: JQR Base Controller initialized
```

**如果失败**:
- `Failed to open /dev/ttyACM0` → 检查 MCU 是否连接 + 串口权限
- `SDK初始化失败` → 检查动态库路径、MCU 固件版本

### 4.2 验证节点状态

```bash
# 终端 2: 检查节点
ros2 node list
# 输出: /base_controller

# 检查话题
ros2 topic list
# 应包含: /odom /imu /cmd_vel /robot_state_update ...

# 检查服务
ros2 service list | grep robot
# 应包含: /set_robot_tilt /get_robot_rise ...
```

---

## 5. 测试验证

### 5.1 使用测试脚本

测试脚本 `base_comm_test.py` 位于代码包根目录。

#### 5.1.1 检查接口

```bash
# 在 jqr_base/ 根目录
./base_comm_test.py check
```

输出显示所有话题/服务清单和在线状态。

#### 5.1.2 监听反馈

```bash
# 监听 10 秒，看 base 是否持续发布反馈
./base_comm_test.py monitor --duration 10
```

**判定标准**:
- ✅ 正常: 收到 odom/imu/robot_state_update 等话题
- ❌ 异常: 全程无反馈 → base 未启动或 MCU 未连接

#### 5.1.3 冒烟测试

```bash
# 全自动测试：发底盘速度、头部速度、四轴位置
./base_comm_test.py smoke
```

冒烟测试会:
1. 检查节点在线
2. 监听反馈 3s
3. 发送底盘速度 0.05 m/s
4. 发送头部 yaw 速度 0.1 rad/s
5. 发送四轴归中指令
6. 输出 PASS/FAIL 结论

### 5.2 手动指令测试

#### 底盘速度控制

```bash
# 前进 0.1 m/s，持续 2 秒
./base_comm_test.py cmd_vel --linear 0.1 --angular 0.0 --duration 2

# 原地旋转 0.3 rad/s
./base_comm_test.py cmd_vel --linear 0.0 --angular 0.3 --duration 2
```

#### 机身俯仰控制 (本次重点)

```bash
# 向上俯仰 5°（会自动先升起机身）
./base_comm_test.py service set_robot_tilt --float 5.0 --duration-units 50

# 回到水平
./base_comm_test.py service set_robot_tilt --float 0.0

# 查询当前俯仰角度
./base_comm_test.py service get_robot_tilt
```

#### 头部速度控制

```bash
# 头部 pitch 向上（速度 -0.1 rad/s，负值向上）
./base_comm_test.py head_speed --pitch -0.1 --yaw 0.0 --duration 2

# 头部 yaw 向左（速度 0.2 rad/s）
./base_comm_test.py head_speed --pitch 0.0 --yaw 0.2 --duration 2
```

#### 四轴位置控制

```bash
# 四轴归中
./base_comm_test.py four_motor \
  --neck-yaw 0 --neck-roll 0 --neck-pitch 0 --head-pitch 0

# 头部俯仰到 0.2 弧度（约 11.5°）
./base_comm_test.py four_motor \
  --neck-yaw 0 --neck-roll 0 --neck-pitch 0 --head-pitch 0.2
```

### 5.3 交互式菜单

```bash
# 启动交互菜单
./base_comm_test.py menu
```

菜单提供快捷操作：
1. 监听反馈 5s
2. 底盘前进 0.05m/s 2s
3. 底盘旋转 0.2rad/s 2s
4. 头部 yaw 速度 0.1rad/s
5. 四轴归中
6. 药盒开
7. 药盒关
8. 调服务 get_robot_tilt
9. 调服务 set_robot_rise

---

## 6. 常见问题

### 6.1 base 节点无法启动

**现象**: `[base_controller]: SDK初始化失败`

**排查**:
```bash
# 1. 检查串口设备
ls -l /dev/ttyACM0
# 若不存在 → MCU 未连接或驱动未加载

# 2. 检查串口权限
groups | grep dialout
# 若不在 dialout 组 → 执行 sudo usermod -aG dialout $USER

# 3. 检查动态库
ldd install/jqr_base/lib/jqr_base/jqr_base_node | grep "not found"
# 若有 not found → 重新编译或检查库路径
```

### 6.2 测试脚本报错 `未能 import jqr_ros_msgs`

**原因**: 未 source 工作空间环境

**解决**:
```bash
# 在 jqr_ws 目录下
source install/setup.bash

# 验证
python3 -c "from jqr_ros_msgs.srv import RobotTilt; print('OK')"
```

### 6.3 发指令无反馈

**排查**:
```bash
# 1. 确认 base 节点在运行
ros2 node list | grep base_controller

# 2. 监听反馈话题
ros2 topic echo /robot_state_update

# 3. 检查 MCU 连接状态（base 日志）
# 若出现 "Connection timeout between base and MCU" → 串口通信异常
```

### 6.4 机身俯仰失败 "Auto rise failed"

**原因**: 机身未升起时尝试俯仰，自动升起失败

**解决**:
```bash
# 手动先升起机身
./base_comm_test.py service set_robot_rise --bool true

# 等待 2-3 秒后再俯仰
./base_comm_test.py service set_robot_tilt --float 5.0
```

### 6.5 服务调用超时

**现象**: `调用超时（10s）`

**原因**: MCU 无响应或机械执行时间超长

**解决**:
```bash
# 增大 duration 参数（单位 0.1s）
./base_comm_test.py service set_robot_tilt \
  --float 5.0 --duration-units 100  # 10秒超时
```

---

## 附录A: 接口清单

### A.1 订阅话题 (base 接收指令)

| 话题 | 消息类型 | 说明 |
|-----|---------|------|
| `/cmd_vel` | `geometry_msgs/Twist` | 底盘速度: linear.x(m/s) + angular.z(rad/s) |
| `/motor_control` | `std_msgs/Float32MultiArray` | 5元素: [屏幕俯仰,机身俯仰,机身升降,药盒开关,药盒速度] |
| `/head_motor_speed_control` | `std_msgs/Float32MultiArray` | 2元素: [pitch速度, yaw速度] (rad/s) |
| `/four_motor_position_control` | `std_msgs/Float32MultiArray` | 4元素: [脖子yaw, 脖子roll, 脖子pitch, 头部pitch] (rad) |

### A.2 发布话题 (base 反馈状态)

| 话题 | 消息类型 | 频率 | 说明 |
|-----|---------|------|------|
| `/odom` | `nav_msgs/Odometry` | 50Hz | 里程计 |
| `/imu` | `sensor_msgs/Imu` | 100Hz | IMU 数据 |
| `/ultra_sonic_front` | `sensor_msgs/Range` | 10Hz | 前超声波 |
| `/ultra_sonic_back` | `sensor_msgs/Range` | 10Hz | 后超声波 |
| `/robot_state_update` | `std_msgs/Float32MultiArray` | 0.1Hz | 电机状态: [屏幕俯仰,机身俯仰,机身升降,药盒,电量] |
| `/head_motor_angle_feedback` | `std_msgs/Float32MultiArray` | 10Hz | 头部角度: [pitch, yaw] (rad) |
| `/four_motor_position_feedback` | `std_msgs/Float32MultiArray` | 50Hz | 四轴位置反馈 (rad) |
| `/stall_flag` | `std_msgs/UInt8` | 事件 | 堵转标志 |

### A.3 服务

| 服务 | 类型 | 说明 |
|-----|------|------|
| `/set_robot_tilt` | `RobotTilt` | 设置机身俯仰角度(°) |
| `/get_robot_tilt` | `RobotTiltState` | 查询机身俯仰状态 |
| `/set_robot_rise` | `RobotRise` | 设置机身升降 |
| `/get_robot_rise` | `RobotRiseState` | 查询机身升降状态 |
| `/set_screen_tilt` | `ScreenTilt` | 设置屏幕俯仰 |
| `/get_screen_tilt` | `ScreenTiltState` | 查询屏幕俯仰状态 |
| `/set_medicine_box_switch` | `MedicineBoxSwitch` | 药盒开关 |
| `/get_medicine_box_state` | `MedicineBoxState` | 查询药盒状态 |
| `/set_laser_pointer` | `LaserPointer` | 激光笔开关 |
| `/get_laser_pointer_state` | `LaserPointerState` | 查询激光笔状态 |
| `/get_move_mode` | `MoveMode` | 查询运动模式 |

---

## 附录B: 快速参考

### 一键启动脚本

创建 `start_base.sh`:

```bash
#!/bin/bash
cd "$(dirname "$0")/jqr_ws"
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch jqr_base base_launch.py
```

使用:
```bash
chmod +x start_base.sh
./start_base.sh
```

### 常用测试指令速查

```bash
# 冒烟测试
./base_comm_test.py smoke

# 底盘前进 10cm
./base_comm_test.py cmd_vel --linear 0.1 --duration 1

# 机身向上俯仰 3°
./base_comm_test.py service set_robot_tilt --float 3.0

# 头部向上看
./base_comm_test.py head_speed --pitch -0.15 --duration 1.5

# 交互菜单
./base_comm_test.py menu
```

---

**文档版本**: 1.0  
**最后更新**: 2026-06-25  
**维护者**: VLN Team
