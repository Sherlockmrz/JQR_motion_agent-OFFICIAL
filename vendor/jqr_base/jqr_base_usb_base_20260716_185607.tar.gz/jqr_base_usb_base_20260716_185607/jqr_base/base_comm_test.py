#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
base_comm_test.py — jqr_base USB 通信端到端测试客户端

用途
----
按 base 软件（jqr_base_node）暴露的 ROS2 话题/服务接口，发送对应控制指令并
订阅反馈话题，用来验证 "上层 ROS2 -> base 软件 -> USB(/dev/ttyACM0) -> MCU"
这条链路是否打通。

这是纯 ROS2 客户端，不直接碰串口。它发的指令由 base_controller 节点经
SDK(JqrSdkController, 0xFA 帧) 通过 USB 下发给 MCU；反馈走 MCU->USB->base->话题。

前置条件
--------
1. base 节点必须已在运行：  ros2 launch jqr_base base_launch.py
   （注意：base 节点启动时会打开 /dev/ttyACM0，若 MCU 未接，节点会 FATAL 退出，
    届时本脚本会因为收不到反馈而报 "未收到反馈"，这本身也是一种诊断结论。）
2. 与 base 节点在同一 ROS_DOMAIN_ID / 同一网络。
3. 已 source：
     source /opt/ros/humble/setup.bash
     source <ws>/install/setup.bash   # 为了拿到 jqr_ros_msgs

用法
----
  # 列出 base 接口、检查节点/话题是否在线
  ./base_comm_test.py check

  # 只监听全部反馈话题（不发指令），看 base 是否在持续发布
  ./base_comm_test.py monitor --duration 10

  # 跑一轮全自动冒烟测试（发指令 + 收反馈 + 判定）
  ./base_comm_test.py smoke

  # 单项指令测试（详见 -h）
  ./base_comm_test.py cmd_vel --linear 0.1 --angular 0.0 --duration 3
  ./base_comm_test.py head_speed --pitch 0.0 --yaw 0.2 --duration 2
  ./base_comm_test.py four_motor --neck-yaw 0 --neck-roll 0 --neck-pitch 0 --head-pitch 0
  ./base_comm_test.py motor_control --screen 0 --tilt 0 --rise 0 --med-switch 1 --med-speed 0
  ./base_comm_test.py service set_robot_rise --bool true
  ./base_comm_test.py service get_robot_tilt
  ./base_comm_test.py service set_screen_tilt --float 5.0
  ./base_comm_test.py service set_medicine_box_switch --bool true --speed 1
  ./base_comm_test.py service set_laser_pointer --bool true

  # 交互式菜单
  ./base_comm_test.py menu

安全提示
--------
cmd_vel / 升降 / 俯仰 / 头颈 等指令会让真机实际运动。真机联调时请先确保机器人
处于安全姿态、周围无障碍、可随时急停。默认速度/角度都取小值。
"""

import argparse
import sys
import threading
import time

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile

from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu, Range
from std_msgs.msg import Float32MultiArray, UInt8

# jqr 自定义消息/服务
try:
    from jqr_ros_msgs.msg import BatteryLevel
    from jqr_ros_msgs.srv import (
        MoveMode, RobotTilt, RobotTiltState, RobotRise, RobotRiseState,
        ScreenTilt, ScreenTiltState, MedicineBoxSwitch, MedicineBoxState,
        LaserPointer, LaserPointerState,
    )
    HAVE_JQR_MSGS = True
except Exception as e:  # pragma: no cover
    HAVE_JQR_MSGS = False
    _JQR_IMPORT_ERR = e


# ────────────────────────── 接口清单（与 base_controller.cpp 对齐）──────────────────────────
# base 订阅（我们发布）
PUB_TOPICS = {
    "cmd_vel":                    ("geometry_msgs/Twist",         "底盘速度：linear.x(m/s) + angular.z(rad/s)"),
    "motor_control":              ("std_msgs/Float32MultiArray",  "5元素: [屏幕俯仰,机身俯仰,机身升降,药盒开关,药盒速度] (当前仅响应药盒)"),
    "head_motor_speed_control":   ("std_msgs/Float32MultiArray",  "2元素: [pitch速度 rad/s, yaw速度 rad/s]"),
    "four_motor_position_control":("std_msgs/Float32MultiArray",  "4元素(rad): [脖子旋转,脖子摇摆,脖子俯仰,头部俯仰]"),
}
# base 发布（我们订阅）
SUB_TOPICS = {
    "odom":                          ("nav_msgs/Odometry",         Odometry),
    "imu":                           ("sensor_msgs/Imu",           Imu),
    "ultra_sonic_front":             ("sensor_msgs/Range",         Range),
    "ultra_sonic_back":              ("sensor_msgs/Range",         Range),
    "battery_level":                 ("jqr_ros_msgs/BatteryLevel", "BatteryLevel"),
    "robot_state_update":            ("std_msgs/Float32MultiArray", Float32MultiArray),
    "head_motor_angle_feedback":     ("std_msgs/Float32MultiArray", Float32MultiArray),
    "four_motor_position_feedback":  ("std_msgs/Float32MultiArray", Float32MultiArray),
    "stall_flag":                    ("std_msgs/UInt8",            UInt8),
}
# base 服务
SERVICES = {
    "get_move_mode":            "MoveMode",
    "set_robot_tilt":           "RobotTilt",
    "get_robot_tilt":           "RobotTiltState",
    "set_robot_rise":           "RobotRise",
    "get_robot_rise":           "RobotRiseState",
    "set_screen_tilt":          "ScreenTilt",
    "get_screen_tilt":          "ScreenTiltState",
    "set_medicine_box_switch":  "MedicineBoxSwitch",
    "get_medicine_box_state":   "MedicineBoxState",
    "set_laser_pointer":        "LaserPointer",
    "get_laser_pointer_state":  "LaserPointerState",
}


def _fmt_array(arr):
    return "[" + ", ".join(f"{v:.4f}" for v in arr) + "]"


class BaseCommTester(Node):
    def __init__(self):
        super().__init__("base_comm_test")
        qos = QoSProfile(depth=10)

        # 发布者
        self.pub_cmd_vel = self.create_publisher(Twist, "cmd_vel", qos)
        self.pub_motor_control = self.create_publisher(Float32MultiArray, "motor_control", qos)
        self.pub_head_speed = self.create_publisher(Float32MultiArray, "head_motor_speed_control", qos)
        self.pub_four_motor = self.create_publisher(Float32MultiArray, "four_motor_position_control", qos)

        # 反馈接收计数 + 最近值
        self._lock = threading.Lock()
        self.rx_count = {name: 0 for name in SUB_TOPICS}
        self.rx_last = {name: None for name in SUB_TOPICS}
        self._subs = []

    # ── 反馈订阅 ──
    def start_monitor(self):
        self._subs.append(self.create_subscription(
            Odometry, "odom", lambda m: self._on_rx("odom", m), 10))
        self._subs.append(self.create_subscription(
            Imu, "imu", lambda m: self._on_rx("imu", m), 10))
        self._subs.append(self.create_subscription(
            Range, "ultra_sonic_front", lambda m: self._on_rx("ultra_sonic_front", m), 10))
        self._subs.append(self.create_subscription(
            Range, "ultra_sonic_back", lambda m: self._on_rx("ultra_sonic_back", m), 10))
        self._subs.append(self.create_subscription(
            Float32MultiArray, "robot_state_update", lambda m: self._on_rx("robot_state_update", m), 10))
        self._subs.append(self.create_subscription(
            Float32MultiArray, "head_motor_angle_feedback", lambda m: self._on_rx("head_motor_angle_feedback", m), 10))
        self._subs.append(self.create_subscription(
            Float32MultiArray, "four_motor_position_feedback", lambda m: self._on_rx("four_motor_position_feedback", m), 10))
        self._subs.append(self.create_subscription(
            UInt8, "stall_flag", lambda m: self._on_rx("stall_flag", m), 10))
        if HAVE_JQR_MSGS:
            self._subs.append(self.create_subscription(
                BatteryLevel, "battery_level", lambda m: self._on_rx("battery_level", m), 10))

    def _on_rx(self, name, msg):
        with self._lock:
            self.rx_count[name] += 1
            self.rx_last[name] = self._summarize(name, msg)

    @staticmethod
    def _summarize(name, msg):
        if name == "odom":
            p = msg.pose.pose.position
            t = msg.twist.twist
            return f"pos=({p.x:.3f},{p.y:.3f}) v={t.linear.x:.3f} w={t.angular.z:.3f}"
        if name == "imu":
            a = msg.linear_acceleration
            g = msg.angular_velocity
            return f"acc=({a.x:.2f},{a.y:.2f},{a.z:.2f}) gyro=({g.x:.3f},{g.y:.3f},{g.z:.3f})"
        if name in ("ultra_sonic_front", "ultra_sonic_back"):
            return f"range={msg.range:.3f} m"
        if name == "stall_flag":
            return f"stall={msg.data}"
        if name == "battery_level":
            return f"battery={msg.battery_power_state:.1f}"
        if name in ("robot_state_update", "head_motor_angle_feedback", "four_motor_position_feedback"):
            return _fmt_array(list(msg.data))
        return str(msg)

    def snapshot(self):
        with self._lock:
            return dict(self.rx_count), dict(self.rx_last)

    # ── 指令发送 ──
    def send_cmd_vel(self, linear, angular):
        m = Twist()
        m.linear.x = float(linear)
        m.angular.z = float(angular)
        self.pub_cmd_vel.publish(m)

    def send_motor_control(self, screen, tilt, rise, med_switch, med_speed):
        m = Float32MultiArray()
        m.data = [float(screen), float(tilt), float(rise), float(med_switch), float(med_speed)]
        self.pub_motor_control.publish(m)

    def send_head_speed(self, pitch, yaw):
        m = Float32MultiArray()
        m.data = [float(pitch), float(yaw)]
        self.pub_head_speed.publish(m)

    def send_four_motor(self, neck_yaw, neck_roll, neck_pitch, head_pitch):
        m = Float32MultiArray()
        m.data = [float(neck_yaw), float(neck_roll), float(neck_pitch), float(head_pitch)]
        self.pub_four_motor.publish(m)


# ────────────────────────── 命令实现 ──────────────────────────
def _spin_bg(node):
    """后台 spin，便于一边发指令一边收反馈。"""
    ex = rclpy.executors.SingleThreadedExecutor()
    ex.add_node(node)
    t = threading.Thread(target=ex.spin, daemon=True)
    t.start()
    return ex


def cmd_check(node, args):
    print("=" * 70)
    print("base 接口清单（与 base_controller.cpp 对齐）")
    print("=" * 70)
    print("\n[base 订阅 — 本脚本向其发布指令]")
    for t, (ty, desc) in PUB_TOPICS.items():
        print(f"  /{t:<30} {ty:<28} {desc}")
    print("\n[base 发布 — 本脚本订阅其反馈]")
    for t, (ty, _) in SUB_TOPICS.items():
        print(f"  /{t:<30} {ty}")
    print("\n[base 服务]")
    for s, ty in SERVICES.items():
        print(f"  /{s:<30} jqr_ros_msgs/srv/{ty}")

    # 在线探测
    print("\n" + "=" * 70)
    print("在线探测")
    print("=" * 70)
    names = node.get_node_names()
    print(f"  base_controller 节点在线: {'是' if 'base_controller' in names else '否 (base 未启动?)'}")
    topics = dict(node.get_topic_names_and_types())
    for t in list(PUB_TOPICS) + list(SUB_TOPICS):
        present = f"/{t}" in topics
        print(f"  /{t:<30} {'存在' if present else '缺失'}")
    if not HAVE_JQR_MSGS:
        print(f"\n  [警告] 未能 import jqr_ros_msgs：{_JQR_IMPORT_ERR}")
        print("         请先 source install/setup.bash。服务测试将不可用。")


def cmd_monitor(node, args):
    node.start_monitor()
    _spin_bg(node)
    print(f"监听全部反馈话题 {args.duration}s ...（base 在持续发布则计数增长）\n")
    end = time.time() + args.duration
    while time.time() < end:
        time.sleep(1.0)
        cnt, last = node.snapshot()
        line = " | ".join(f"{n}:{c}" for n, c in cnt.items() if c > 0)
        print(f"[{int(end - time.time())}s] 收到计数: {line or '（无任何反馈）'}")
    print("\n最近一帧内容:")
    cnt, last = node.snapshot()
    any_rx = False
    for n in SUB_TOPICS:
        if cnt[n] > 0:
            any_rx = True
            print(f"  /{n:<30} x{cnt[n]:<5} {last[n]}")
    if not any_rx:
        print("  （全程未收到任何反馈 —— base 可能未启动，或已因 MCU 未连接而退出）")
    return 0 if any_rx else 2


def cmd_cmd_vel(node, args):
    node.start_monitor()
    _spin_bg(node)
    print(f"发送 cmd_vel: linear={args.linear} m/s angular={args.angular} rad/s，持续 {args.duration}s @10Hz")
    end = time.time() + args.duration
    while time.time() < end:
        node.send_cmd_vel(args.linear, args.angular)
        time.sleep(0.1)
    node.send_cmd_vel(0.0, 0.0)  # 停车
    print("已发送停车指令 (0,0)")
    time.sleep(0.5)
    _report_feedback(node, ["odom"])


def cmd_head_speed(node, args):
    node.start_monitor()
    _spin_bg(node)
    print(f"发送 head_motor_speed_control: pitch={args.pitch} yaw={args.yaw} rad/s，持续 {args.duration}s @10Hz")
    end = time.time() + args.duration
    while time.time() < end:
        node.send_head_speed(args.pitch, args.yaw)
        time.sleep(0.1)
    node.send_head_speed(0.0, 0.0)
    print("已发送头部停止 (0,0)")
    time.sleep(0.5)
    _report_feedback(node, ["head_motor_angle_feedback"])


def cmd_four_motor(node, args):
    node.start_monitor()
    _spin_bg(node)
    print(f"发送 four_motor_position_control(rad): neck_yaw={args.neck_yaw} "
          f"neck_roll={args.neck_roll} neck_pitch={args.neck_pitch} head_pitch={args.head_pitch}")
    for _ in range(5):
        node.send_four_motor(args.neck_yaw, args.neck_roll, args.neck_pitch, args.head_pitch)
        time.sleep(0.1)
    time.sleep(1.0)
    _report_feedback(node, ["four_motor_position_feedback"])


def cmd_motor_control(node, args):
    node.start_monitor()
    _spin_bg(node)
    print(f"发送 motor_control: screen={args.screen} tilt={args.tilt} rise={args.rise} "
          f"med_switch={args.med_switch} med_speed={args.med_speed}")
    for _ in range(3):
        node.send_motor_control(args.screen, args.tilt, args.rise, args.med_switch, args.med_speed)
        time.sleep(0.2)
    time.sleep(1.0)
    _report_feedback(node, ["robot_state_update"])


def _report_feedback(node, focus):
    cnt, last = node.snapshot()
    print("\n反馈结果:")
    got = False
    for n in focus:
        if cnt.get(n, 0) > 0:
            got = True
            print(f"  /{n}: x{cnt[n]}  {last[n]}")
        else:
            print(f"  /{n}: 未收到反馈")
    if not got:
        print("  [判定] 未收到关注反馈 —— 检查 base 是否在运行、MCU 是否连接。")


def cmd_service(node, args):
    if not HAVE_JQR_MSGS:
        print(f"[错误] 无法 import jqr_ros_msgs：{_JQR_IMPORT_ERR}")
        print("       请 source install/setup.bash 后重试。")
        return 1
    name = args.name
    if name not in SERVICES:
        print(f"[错误] 未知服务 '{name}'。可用: {', '.join(SERVICES)}")
        return 1

    srv_type = {
        "MoveMode": MoveMode, "RobotTilt": RobotTilt, "RobotTiltState": RobotTiltState,
        "RobotRise": RobotRise, "RobotRiseState": RobotRiseState,
        "ScreenTilt": ScreenTilt, "ScreenTiltState": ScreenTiltState,
        "MedicineBoxSwitch": MedicineBoxSwitch, "MedicineBoxState": MedicineBoxState,
        "LaserPointer": LaserPointer, "LaserPointerState": LaserPointerState,
    }[SERVICES[name]]

    cli = node.create_client(srv_type, name)
    print(f"等待服务 /{name} ...")
    if not cli.wait_for_service(timeout_sec=5.0):
        print(f"[判定] 服务 /{name} 不可用 —— base 未启动或未注册该服务。")
        return 2

    req = srv_type.Request()
    # 按服务类型填请求字段
    bv = (str(args.bool).lower() in ("1", "true", "yes", "on")) if args.bool is not None else False
    if name == "set_robot_tilt":
        req.robot_tilt = float(args.float or 0.0); req.duration = int(args.duration_units or 0)
    elif name == "set_robot_rise":
        req.robot_rise = bv; req.duration = int(args.duration_units or 0)
    elif name == "set_screen_tilt":
        req.screen_tilt = float(args.float or 0.0); req.duration = int(args.duration_units or 0)
    elif name == "set_medicine_box_switch":
        req.medicine_box_switch = bv; req.speed_stage = int(args.speed or 1)
    elif name == "set_laser_pointer":
        req.laser_pointer = bv
    # get_* 与 get_move_mode 请求为空

    _spin_bg(node)
    print(f"调用 /{name} ...")
    fut = cli.call_async(req)
    t0 = time.time()
    while not fut.done() and time.time() - t0 < 10.0:
        time.sleep(0.05)
    if not fut.done():
        print(f"[判定] /{name} 调用超时（10s）。base 可能阻塞等待 MCU 反馈。")
        return 2
    resp = fut.result()
    print(f"[成功] /{name} 返回:")
    for field in resp.get_fields_and_field_types():
        val = getattr(resp, field)
        # 解包 std_msgs 包装
        if hasattr(val, "data"):
            val = val.data
        print(f"    {field} = {val}")
    return 0


def cmd_smoke(node, args):
    """全自动冒烟：先看反馈是否在发，再逐项发指令。"""
    node.start_monitor()
    _spin_bg(node)
    print("=" * 70)
    print("冒烟测试开始")
    print("=" * 70)

    names = node.get_node_names()
    base_up = "base_controller" in names
    print(f"[1] base_controller 节点在线: {'是' if base_up else '否'}")

    print("[2] 监听反馈 3s ...")
    time.sleep(3.0)
    cnt, last = node.snapshot()
    fb_topics = [n for n in SUB_TOPICS if cnt[n] > 0]
    print(f"    收到反馈的话题: {fb_topics or '无'}")
    for n in fb_topics:
        print(f"      /{n}: x{cnt[n]}  {last[n]}")

    print("[3] 发送底盘速度 (0.05 m/s, 1.5s) 后停车 ...")
    end = time.time() + 1.5
    while time.time() < end:
        node.send_cmd_vel(0.05, 0.0); time.sleep(0.1)
    node.send_cmd_vel(0.0, 0.0)

    print("[4] 发送头部速度 yaw=0.1 rad/s (1s) 后停止 ...")
    end = time.time() + 1.0
    while time.time() < end:
        node.send_head_speed(0.0, 0.1); time.sleep(0.1)
    node.send_head_speed(0.0, 0.0)

    print("[5] 发送四轴位置 全 0（归中）...")
    for _ in range(5):
        node.send_four_motor(0.0, 0.0, 0.0, 0.0); time.sleep(0.1)

    time.sleep(1.0)
    cnt2, last2 = node.snapshot()
    print("\n" + "=" * 70)
    print("冒烟测试结论")
    print("=" * 70)
    any_fb = any(cnt2[n] > 0 for n in SUB_TOPICS)
    print(f"  base 节点在线 : {'PASS' if base_up else 'FAIL'}")
    print(f"  收到反馈      : {'PASS' if any_fb else 'FAIL (无任何反馈)'}")
    for n in SUB_TOPICS:
        if cnt2[n] > 0:
            print(f"    /{n}: x{cnt2[n]}  {last2[n]}")
    if not any_fb:
        print("\n  [诊断] 全程无反馈。最可能：base 因 MCU 未连接而 FATAL 退出，")
        print("         或 base 未启动。先在 base 端确认 /dev/ttyACM0 存在且节点存活。")
        return 2
    return 0


def cmd_menu(node, args):
    node.start_monitor()
    _spin_bg(node)
    menu = """
========== jqr_base 通信测试 交互菜单 ==========
  1) 监听反馈 5s
  2) 底盘前进 0.05m/s 2s 后停车
  3) 底盘原地旋转 0.2rad/s 2s 后停车
  4) 头部 yaw 速度 0.1rad/s 2s
  5) 四轴归中 (全0)
  6) 药盒开 (motor_control)
  7) 药盒关 (motor_control)
  8) 调服务 get_robot_tilt
  9) 调服务 set_robot_rise true
  0) 退出
请选择: """
    while True:
        try:
            ch = input(menu).strip()
        except (EOFError, KeyboardInterrupt):
            print(); break
        if ch == "0":
            break
        elif ch == "1":
            time.sleep(5.0); _report_feedback(node, list(SUB_TOPICS))
        elif ch == "2":
            for _ in range(20): node.send_cmd_vel(0.05, 0.0); time.sleep(0.1)
            node.send_cmd_vel(0.0, 0.0); _report_feedback(node, ["odom"])
        elif ch == "3":
            for _ in range(20): node.send_cmd_vel(0.0, 0.2); time.sleep(0.1)
            node.send_cmd_vel(0.0, 0.0); _report_feedback(node, ["odom"])
        elif ch == "4":
            for _ in range(20): node.send_head_speed(0.0, 0.1); time.sleep(0.1)
            node.send_head_speed(0.0, 0.0); _report_feedback(node, ["head_motor_angle_feedback"])
        elif ch == "5":
            for _ in range(5): node.send_four_motor(0.0, 0.0, 0.0, 0.0); time.sleep(0.1)
            _report_feedback(node, ["four_motor_position_feedback"])
        elif ch == "6":
            node.send_motor_control(0, 0, 0, 1, 0); _report_feedback(node, ["robot_state_update"])
        elif ch == "7":
            node.send_motor_control(0, 0, 0, 0, 0); _report_feedback(node, ["robot_state_update"])
        elif ch == "8":
            a = argparse.Namespace(name="get_robot_tilt", bool=None, float=None,
                                   duration_units=0, speed=1)
            cmd_service(node, a)
        elif ch == "9":
            a = argparse.Namespace(name="set_robot_rise", bool="true", float=None,
                                   duration_units=0, speed=1)
            cmd_service(node, a)
        else:
            print("无效选择")


def build_parser():
    p = argparse.ArgumentParser(
        description="jqr_base USB 通信端到端测试客户端",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__)
    sub = p.add_subparsers(dest="command", required=True)

    sub.add_parser("check", help="列出接口并探测 base 是否在线")

    mp = sub.add_parser("monitor", help="只监听反馈话题")
    mp.add_argument("--duration", type=float, default=10.0)

    sub.add_parser("smoke", help="全自动冒烟测试")
    sub.add_parser("menu", help="交互式菜单")

    cv = sub.add_parser("cmd_vel", help="发布底盘速度")
    cv.add_argument("--linear", type=float, default=0.0)
    cv.add_argument("--angular", type=float, default=0.0)
    cv.add_argument("--duration", type=float, default=2.0)

    hs = sub.add_parser("head_speed", help="发布头部速度")
    hs.add_argument("--pitch", type=float, default=0.0)
    hs.add_argument("--yaw", type=float, default=0.0)
    hs.add_argument("--duration", type=float, default=2.0)

    fm = sub.add_parser("four_motor", help="发布四轴位置(rad)")
    fm.add_argument("--neck-yaw", type=float, default=0.0)
    fm.add_argument("--neck-roll", type=float, default=0.0)
    fm.add_argument("--neck-pitch", type=float, default=0.0)
    fm.add_argument("--head-pitch", type=float, default=0.0)

    mc = sub.add_parser("motor_control", help="发布 motor_control 5元素")
    mc.add_argument("--screen", type=float, default=0.0)
    mc.add_argument("--tilt", type=float, default=0.0)
    mc.add_argument("--rise", type=float, default=0.0)
    mc.add_argument("--med-switch", type=float, default=0.0)
    mc.add_argument("--med-speed", type=float, default=0.0)

    sv = sub.add_parser("service", help="调用 base 服务")
    sv.add_argument("name", help="服务名，如 get_robot_tilt / set_robot_rise")
    sv.add_argument("--bool", default=None, help="bool 入参 (true/false)")
    sv.add_argument("--float", type=float, default=None, help="float 入参 (角度等)")
    sv.add_argument("--duration-units", type=int, default=0, help="duration，单位0.1s")
    sv.add_argument("--speed", type=int, default=1, help="药盒 speed_stage 1慢 2快")

    return p


DISPATCH = {
    "check": cmd_check, "monitor": cmd_monitor, "smoke": cmd_smoke, "menu": cmd_menu,
    "cmd_vel": cmd_cmd_vel, "head_speed": cmd_head_speed, "four_motor": cmd_four_motor,
    "motor_control": cmd_motor_control, "service": cmd_service,
}


def main():
    args = build_parser().parse_args()
    rclpy.init()
    node = BaseCommTester()
    rc = 0
    try:
        rc = DISPATCH[args.command](node, args) or 0
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
    sys.exit(rc)


if __name__ == "__main__":
    main()
