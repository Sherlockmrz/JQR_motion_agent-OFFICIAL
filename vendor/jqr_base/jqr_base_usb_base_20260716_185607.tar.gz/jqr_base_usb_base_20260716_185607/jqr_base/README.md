# JQR Base 代码包

**分支**: new_base_wang  
**功能**: 机器人底层控制节点 + USB 通信 + 测试脚本  
**平台**: Ubuntu 22.04 + ROS2 Humble (aarch64)

---

## 快速开始

### 1. 解压部署

```bash
tar xzf jqr_base_*.tar.gz
cd jqr_base_*/jqr_base
```

### 2. 编译

```bash
cd jqr_ws
source /opt/ros/humble/setup.bash
colcon build --symlink-install
source install/setup.bash
```

### 3. 启动 Base 节点

```bash
# 确保 /dev/ttyACM0 存在且有权限
ros2 launch jqr_base base_launch.py
```

### 4. 测试验证

```bash
# 返回上级目录
cd ..

# 运行冒烟测试
./base_comm_test.py smoke

# 测试机身俯仰（向上 5°）
./base_comm_test.py service set_robot_tilt --float 5.0
```

---

## 核心功能

### 俯仰电机控制（本次重点）

```bash
# 机身俯仰向上 5° (自动先升起机身)
./base_comm_test.py service set_robot_tilt --float 5.0 --duration-units 50

# 回到水平
./base_comm_test.py service set_robot_tilt --float 0.0

# 查询当前角度
./base_comm_test.py service get_robot_tilt
```

**说明**:
- 单位: **度 (°)**
- 范围: 约 -5° ~ +5°
- 正值向上，负值向下
- duration-units: 超时时间，单位 0.1 秒 (不传则默认 5 秒)

### 其他控制

```bash
# 底盘速度
./base_comm_test.py cmd_vel --linear 0.1 --angular 0.0 --duration 2

# 头部速度 (pitch 负值向上)
./base_comm_test.py head_speed --pitch -0.1 --yaw 0.0 --duration 2

# 四轴位置
./base_comm_test.py four_motor --neck-yaw 0 --neck-roll 0 --neck-pitch 0 --head-pitch 0.2

# 交互菜单
./base_comm_test.py menu
```

---

## 文档

- **`DEPLOY.md`**: 完整的部署、编译、测试、故障排查文档
- **`VERSION.txt`**: 打包版本信息
- **`README_base_comm_test.md`**: 测试脚本详细说明

---

## 接口清单

### 话题

| 话题 | 类型 | 说明 |
|-----|------|------|
| `/cmd_vel` | Twist | 底盘速度控制 |
| `/odom` | Odometry | 里程计反馈 (50Hz) |
| `/imu` | Imu | IMU 数据 (100Hz) |
| `/robot_state_update` | Float32MultiArray | 电机状态反馈 |
| `/head_motor_angle_feedback` | Float32MultiArray | 头部角度反馈 |

### 服务

| 服务 | 说明 |
|-----|------|
| `/set_robot_tilt` | 机身俯仰控制 ⭐ |
| `/set_robot_rise` | 机身升降 |
| `/set_screen_tilt` | 屏幕俯仰 |
| `/set_medicine_box_switch` | 药盒开关 |
| `/set_laser_pointer` | 激光笔 |

---

## 故障排查

### base 节点无法启动

```bash
# 检查串口
ls -l /dev/ttyACM0

# 检查权限
sudo usermod -aG dialout $USER
newgrp dialout
```

### 测试脚本报错

```bash
# 确保 source 了工作空间
cd jqr_ws
source install/setup.bash
```

### 发指令无反馈

```bash
# 检查节点状态
ros2 node list | grep base_controller

# 监听话题
ros2 topic echo /robot_state_update
```

---

## 联系支持

- **团队**: VLN Group
- **仓库**: HWC_SIRD/VLN_Group/Jbase (code.iflytek.com)
- **详细文档**: 参见 `DEPLOY.md`

---

**打包时间**: 见 `VERSION.txt`  
**ROS2 版本**: Humble  
**目标硬件**: Sunrise X3/X5 (aarch64)
