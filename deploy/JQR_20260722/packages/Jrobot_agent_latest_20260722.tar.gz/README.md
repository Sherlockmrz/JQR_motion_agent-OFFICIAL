# Jrobot_agent

#### 介绍

{以下是 Gitee 平台说明，您可以替换此简介 Gitee 是 OSCHINA 推出的基于 Git 的代码托管平台。专为开发者提供稳定、高效、安全的云端软件开发协作平台 无论是个人、团队、或是企业，都能够用 Gitee 实现代码托管、项目管理、协作开发。}

#### 软件版本

v1.0.0
演示版本agent

v1.0.1
1.agent增加usb串口断连检测及自动重连功能

v1.0.2
1.agent增加多重找物功能
2.agent增加话题获取及控制电机电池状态功能

v1.0.3
1.agent增加rgb灯控制及状态获取功能

v1.0.4
1.agent增加迎宾点导航功能

v1.0.5
rgb灯交互接口适配
增加静态找人功能

v1.0.6
优化找物流程

v1.0.7
增加删除人脸功能

v1.0.8
优化串口消息解析，支持无延迟接收处理多个消息指令

#### 安装教程

将代码部署至s100上的某一位置（如/home/sunrise/motion_agent，s100 用户名  密码均为sunrise） 
前置项：将rk.rules文件 ，放置在s100 的 /etc/udev/rules.d/ 目录下
在代码目录终端，运行下列指令:
sudo service udev reload
sudo service udev restart
sudo udevadm control --reload-rules && sudo udevadm trigger
sudo apt install ros-humble-nav2-common
source /opt/ros/humble/setup.bash
colcon build
sudo chmod +x start_agent.sh


#### 使用说明

./start_agent.sh

